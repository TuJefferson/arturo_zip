/*
Navicat MySQL Data Transfer

Source Server         : local_host
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : its_on_the_way

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2020-04-10 02:36:51
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for orders_status_type
-- ----------------------------
DROP TABLE IF EXISTS `orders_status_type`;
CREATE TABLE `orders_status_type` (
  `id` bigint(20) NOT NULL,
  `status_name` varchar(255) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of orders_status_type
-- ----------------------------
INSERT INTO `orders_status_type` VALUES ('0', 'Entregada a repartidor');
INSERT INTO `orders_status_type` VALUES ('1', 'Sin aprobar');
INSERT INTO `orders_status_type` VALUES ('2', 'Aprobada,');
INSERT INTO `orders_status_type` VALUES ('4', 'Entregada cliente');

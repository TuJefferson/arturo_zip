/*
Navicat MySQL Data Transfer

Source Server         : local_host
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : its_on_the_way

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2020-04-07 08:47:58
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for payments_platforms
-- ----------------------------
DROP TABLE IF EXISTS `payments_platforms`;
CREATE TABLE `payments_platforms` (
  `id` bigint(20) NOT NULL,
  `platform_payment` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ----------------------------
-- Records of payments_platforms
-- ----------------------------
INSERT INTO `payments_platforms` VALUES ('1', 'transferencia bancaria');
INSERT INTO `payments_platforms` VALUES ('2', 'zelle');
INSERT INTO `payments_platforms` VALUES ('3', 'pago movil');

/*
Navicat MySQL Data Transfer

Source Server         : local_host
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : its_on_the_way

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2020-03-10 14:08:20
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for address
-- ----------------------------
DROP TABLE IF EXISTS `address`;
CREATE TABLE `address` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `st_id` bigint(20) unsigned DEFAULT NULL,
  `mun_id` bigint(20) unsigned DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `address_st_id_foreign` (`st_id`),
  KEY `address_mun_id_foreign` (`mun_id`),
  CONSTRAINT `address_mun_id_foreign` FOREIGN KEY (`mun_id`) REFERENCES `municipios` (`id`),
  CONSTRAINT `address_st_id_foreign` FOREIGN KEY (`st_id`) REFERENCES `states` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of address
-- ----------------------------
INSERT INTO `address` VALUES ('1', '5', '2', 'Est magni voluptatibus praesentium officiis dicta molestias quas ratione. Consequatur quo eligendi quos sed quia laborum.', null, null, null);
INSERT INTO `address` VALUES ('2', '4', '2', 'Id voluptatem hic atque harum nobis praesentium. Magni porro magni porro. Minus similique ab labore minima non. Atque et aut reprehenderit.', null, null, null);
INSERT INTO `address` VALUES ('3', '6', '2', 'Distinctio et inventore inventore accusamus. Possimus quisquam sint velit harum et saepe. Illum ullam soluta alias nobis dolor. Veritatis quia at veritatis perferendis minus est.', null, null, null);
INSERT INTO `address` VALUES ('4', '19', '2', 'Quisquam ea quae ipsum et. Quia sit ea cumque. Itaque ex odio molestiae minus.', null, null, null);
INSERT INTO `address` VALUES ('5', '9', '2', 'Ea ut saepe sequi nihil eaque magnam unde. Eius consequuntur nesciunt dolores nam illo cupiditate laudantium. Nam et officia a ullam. Rerum voluptatem corrupti sit repellendus.', null, null, null);
INSERT INTO `address` VALUES ('6', '18', '1', 'Fuga sint vero in inventore possimus qui sed cum. Fuga cum dolorem beatae similique. Sed aliquid perferendis ratione consequatur.', null, null, null);
INSERT INTO `address` VALUES ('7', '19', '2', 'Quia aspernatur est impedit laboriosam nostrum et laudantium. Deserunt quos sit explicabo cumque laborum earum rerum. Odit incidunt quos odio.', null, null, null);
INSERT INTO `address` VALUES ('8', '23', '1', 'Occaecati eveniet quia praesentium veniam. Voluptatem et sunt natus atque consequatur animi consequatur incidunt. Repellat numquam eum est alias beatae nesciunt excepturi.', null, null, null);
INSERT INTO `address` VALUES ('9', '4', '1', 'Magni fugiat aperiam est recusandae. Sit recusandae officiis autem sunt dolorem doloribus. Suscipit deleniti molestias inventore saepe aut. Eius aut eos explicabo iure.', null, null, null);
INSERT INTO `address` VALUES ('10', '13', '1', 'quam', null, null, null);
INSERT INTO `address` VALUES ('11', '11', '2', 'illum', null, null, null);
INSERT INTO `address` VALUES ('12', '21', '2', 'similique', null, null, null);
INSERT INTO `address` VALUES ('13', '15', '1', 'eos', null, null, null);
INSERT INTO `address` VALUES ('14', '15', '1', 'est', null, null, null);
INSERT INTO `address` VALUES ('15', '14', '1', 'totam', null, null, null);
INSERT INTO `address` VALUES ('16', '24', '2', 'libero', null, null, null);
INSERT INTO `address` VALUES ('17', '6', '1', 'nihil', null, null, null);
INSERT INTO `address` VALUES ('18', '5', '2', 'nobis', null, null, null);
INSERT INTO `address` VALUES ('19', '8', '1', 'est', null, null, null);
INSERT INTO `address` VALUES ('20', '14', '1', 'aut', null, null, null);
INSERT INTO `address` VALUES ('21', '22', '2', 'repellendus', null, null, null);
INSERT INTO `address` VALUES ('22', '19', '2', 'aut', null, null, null);
INSERT INTO `address` VALUES ('23', '14', '2', 'eum', null, null, null);
INSERT INTO `address` VALUES ('24', '11', '1', 'voluptates', null, null, null);
INSERT INTO `address` VALUES ('25', '22', '1', 'ut', null, null, null);
INSERT INTO `address` VALUES ('26', '10', '1', 'eligendi', null, null, null);
INSERT INTO `address` VALUES ('27', '21', '2', 'reprehenderit', null, null, null);
INSERT INTO `address` VALUES ('28', '6', '2', 'velit', null, null, null);
INSERT INTO `address` VALUES ('29', '22', '1', 'fugiat', null, null, null);
INSERT INTO `address` VALUES ('30', '17', '1', 'in', null, null, null);
INSERT INTO `address` VALUES ('31', '7', '2', 'enim', null, null, null);
INSERT INTO `address` VALUES ('32', '10', '1', 'dolorem', null, null, null);
INSERT INTO `address` VALUES ('33', '2', '1', 'facilis', null, null, null);
INSERT INTO `address` VALUES ('34', '11', '1', 'sunt', null, null, null);
INSERT INTO `address` VALUES ('35', '6', '2', 'magnam', null, null, null);
INSERT INTO `address` VALUES ('36', '13', '2', 'porro', null, null, null);
INSERT INTO `address` VALUES ('37', '1', '1', 'at', null, null, null);
INSERT INTO `address` VALUES ('38', '11', '1', 'voluptates', null, null, null);
INSERT INTO `address` VALUES ('39', '23', '1', 'beatae', null, null, null);
INSERT INTO `address` VALUES ('40', '6', '2', 'eligendi', null, null, null);
INSERT INTO `address` VALUES ('41', '8', '1', 'nemo', null, null, null);
INSERT INTO `address` VALUES ('42', '13', '1', 'ipsam', null, null, null);
INSERT INTO `address` VALUES ('43', '5', '1', 'tempore', null, null, null);
INSERT INTO `address` VALUES ('44', '14', '1', 'velit', null, null, null);
INSERT INTO `address` VALUES ('45', '9', '1', 'consequuntur', null, null, null);
INSERT INTO `address` VALUES ('46', '24', '1', 'soluta', null, null, null);
INSERT INTO `address` VALUES ('47', '15', '2', 'quae', null, null, null);
INSERT INTO `address` VALUES ('48', '20', '2', 'sapiente', null, null, null);
INSERT INTO `address` VALUES ('49', '10', '1', 'sit', null, null, null);

-- ----------------------------
-- Table structure for admins
-- ----------------------------
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ad_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ad_last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ad_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ad_user_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ad_rs_id` bigint(20) unsigned DEFAULT NULL,
  `ad_intents` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ad_blocked` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ad_pass_exp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admins_ad_email_unique` (`ad_email`),
  UNIQUE KEY `admins_ad_user_name_unique` (`ad_user_name`),
  KEY `admins_ad_rs_id_foreign` (`ad_rs_id`),
  CONSTRAINT `admins_ad_rs_id_foreign` FOREIGN KEY (`ad_rs_id`) REFERENCES `roles_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of admins
-- ----------------------------

-- ----------------------------
-- Table structure for categories
-- ----------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of categories
-- ----------------------------
INSERT INTO `categories` VALUES ('1', 'tasca', null, null, null);
INSERT INTO `categories` VALUES ('2', 'restaurant', null, null, null);
INSERT INTO `categories` VALUES ('3', 'bistro', null, null, null);

-- ----------------------------
-- Table structure for clients
-- ----------------------------
DROP TABLE IF EXISTS `clients`;
CREATE TABLE `clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cl_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_user` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_dni` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_phone_1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_phone_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cl_rs_id` bigint(20) unsigned DEFAULT NULL,
  `cl_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_verified` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_intents` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cl_blocked` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cl_pass_exp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clients_cl_user_unique` (`cl_user`),
  UNIQUE KEY `clients_cl_email_unique` (`cl_email`),
  KEY `clients_cl_rs_id_foreign` (`cl_rs_id`),
  CONSTRAINT `clients_cl_rs_id_foreign` FOREIGN KEY (`cl_rs_id`) REFERENCES `roles_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of clients
-- ----------------------------
INSERT INTO `clients` VALUES ('16', 'Alanna Russel', 'Mante', 'officia', '7', '+1-814-289-3124', '997-301-7446 x34035', null, 'onolan@yahoo.com', null, '$2y$10$8RKeBOfXf1Gx/4M0scxO8ez068TjfgUKIDOuyGnjuKztHWUkx/Ye.', null, null, null, null, null, null, null);
INSERT INTO `clients` VALUES ('17', 'Polly Crist', 'Jenkins', 'fugiat', '4', '602.966.0989 x120', '+14614982326', null, 'madeline.mcglynn@gmail.com', null, '$2y$10$q7C44ms956PW.SBZsb9IAOKydY8iTjsA.IxTAu44zHLFKmAy9b/h6', null, null, null, null, null, null, null);
INSERT INTO `clients` VALUES ('18', 'Sid Watsica', 'Langworth', 'ut', '0', '(319) 491-8174 x80922', '739.909.0750 x860', null, 'fdaugherty@hotmail.com', null, '$2y$10$R0qvLM6H8h/AqwjzaCBI9uwGcGAZ0R68iIWxNRJom9424l/vQeXPq', null, null, null, null, null, null, null);
INSERT INTO `clients` VALUES ('19', 'Prof. Emile Kuhn', 'Huels', 'quos', '2', '445.371.1682 x98281', '592.434.0103 x3912', null, 'rkub@sipes.com', null, '$2y$10$u70ZPmWgEBzkDhteFsA6..9PLmqh/90GSldGes4cclJ3P0GunKIo.', null, null, null, null, null, null, null);
INSERT INTO `clients` VALUES ('20', 'Mrs. Sarah Halvorson II', 'Thompson', 'mollitia', '4', '967.778.8606 x56214', '917-752-5298 x66064', null, 'hodkiewicz.fleta@yahoo.com', null, '$2y$10$ZMfEfSG.oNrd9GOWiJKfMuXREEIg/ax7WHYNJBILgRt/8wgGsh4/.', null, null, null, null, null, null, null);
INSERT INTO `clients` VALUES ('21', 'Prof. Kayli DuBuque', 'Jakubowski', 'dignissimos', '2', '+1-340-289-0455', '248-548-5305 x6251', null, 'zmiller@gmail.com', null, '$2y$10$azgwJPvxdLUyMv8KuD8xVuz89BgckDTjySPF2dTl00zKZRR9GJMw6', null, null, null, null, null, null, null);
INSERT INTO `clients` VALUES ('22', 'Marisa Jerde', 'Rolfson', 'ratione', '9', '858-352-8101', '(731) 690-2310', null, 'considine.martina@hotmail.com', null, '$2y$10$LsjNgItGAlO32DUoRiqBD.usKOYTFZ9Fa09wqPE0NhkznKX5.xhSG', null, null, null, null, null, null, null);
INSERT INTO `clients` VALUES ('23', 'Manuel Crist', 'Kemmer', 'assumenda', '3', '1-896-874-6917', '+1.878.374.4717', null, 'pfannerstill.adam@mosciski.com', null, '$2y$10$eH3gGumZgLpN0SV1fe8qSOhRNnJqjbMmr0cRH1odFh7zcFybADreO', null, null, null, null, null, null, null);
INSERT INTO `clients` VALUES ('24', 'Caterina Casper', 'Wisoky', 'et', '7', '239.874.9966 x628', '1-261-869-3986', null, 'mary.schneider@zboncak.com', null, '$2y$10$74vxQ2SdzTI0tubGNRSdqe87/mFxTcAOKaRjxboMZNgzbNeAGzYtS', null, null, null, null, null, null, null);
INSERT INTO `clients` VALUES ('25', 'Anne Fadel', 'Heathcote', 'vel', '2', '(998) 203-8710', '1-563-638-7693', null, 'cortney12@wiegand.com', null, '$2y$10$iXFroYhqy6knevzv/3mfyOoy4sF5gBXBqXoWkiy9DIFmvGRWGoUWS', null, null, null, null, null, null, null);

-- ----------------------------
-- Table structure for clients_address
-- ----------------------------
DROP TABLE IF EXISTS `clients_address`;
CREATE TABLE `clients_address` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ca_cl_id` bigint(20) unsigned DEFAULT NULL,
  `ca_address_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clients_address_ca_cl_id_foreign` (`ca_cl_id`),
  KEY `clients_address_ca_address_id_foreign` (`ca_address_id`),
  CONSTRAINT `clients_address_ca_address_id_foreign` FOREIGN KEY (`ca_address_id`) REFERENCES `address` (`id`),
  CONSTRAINT `clients_address_ca_cl_id_foreign` FOREIGN KEY (`ca_cl_id`) REFERENCES `clients` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of clients_address
-- ----------------------------
INSERT INTO `clients_address` VALUES ('1', '16', '1', null, null, null);

-- ----------------------------
-- Table structure for curriencies
-- ----------------------------
DROP TABLE IF EXISTS `curriencies`;
CREATE TABLE `curriencies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cur_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cur_value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of curriencies
-- ----------------------------

-- ----------------------------
-- Table structure for delivery_man
-- ----------------------------
DROP TABLE IF EXISTS `delivery_man`;
CREATE TABLE `delivery_man` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dm_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_user` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_phone_1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_phone_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dm_rs_id` bigint(20) unsigned DEFAULT NULL,
  `dm_rate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dm_intents` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dm_blocked` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dm_pass_exp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `delivery_man_dm_user_unique` (`dm_user`),
  UNIQUE KEY `delivery_man_dm_email_unique` (`dm_email`),
  KEY `delivery_man_dm_rs_id_foreign` (`dm_rs_id`),
  CONSTRAINT `delivery_man_dm_rs_id_foreign` FOREIGN KEY (`dm_rs_id`) REFERENCES `roles_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of delivery_man
-- ----------------------------
INSERT INTO `delivery_man` VALUES ('7', 'Mr. Coty Greenfelder PhD', 'Botsford', 'consectetur', 'gwill@hintz.com', '$2y$10$DlrVgIliKqdze9fExYWhwu09H5g/gQLyY/UdKyGyFomyjfJC/J0B.', '+1-510-536-6224', '(359) 357-6482 x68672', null, null, null, null, null, null, null, null, null, 'default.jpg');
INSERT INTO `delivery_man` VALUES ('8', 'Ona Greenholt DVM', 'Harber', 'atque', 'otto.barton@stoltenberg.info', '$2y$10$DW0xd4dpMQqlcJqT1nUhiuVPtskfJ9SwmO2crJjmBYsalZJhqVPGK', '(652) 979-7653 x629', '(695) 766-1392', null, null, null, null, null, null, null, null, null, 'default.jpg');
INSERT INTO `delivery_man` VALUES ('9', 'Neal Glover', 'Kunde', 'sed', 'alek92@sawayn.com', '$2y$10$sJ309.Y0HHlnIU6VKXLl2.y331KpPnRW9wujIsVIYzzUe8FWBoQta', '785.608.0039', '(608) 525-6392 x8632', null, null, null, null, null, null, null, null, null, 'default.jpg');
INSERT INTO `delivery_man` VALUES ('10', 'Chasity Gulgowski V', 'Sauer', 'et', 'annabel.schaefer@hotmail.com', '$2y$10$qPNXrDYdIuabixUMiW7/s.rtUInbDYuOcIYgqPuMfUFfENiEMjF12', '+1.303.283.4763', '1-202-539-8694', null, null, null, null, null, null, null, null, null, 'default.jpg');
INSERT INTO `delivery_man` VALUES ('11', 'Irma Prosacco', 'Borer', 'dolores', 'candace15@gmail.com', '$2y$10$1wj4JiPSoFHtKDEd90ESTu12MFkyBcbuFzC.ujqF6L6tPhjgpcJOW', '+1-685-714-0745', '1-842-953-4660 x519', null, null, null, null, null, null, null, null, null, 'default.jpg');
INSERT INTO `delivery_man` VALUES ('12', 'Elsa Schimmel DVM', 'O\'Connell', 'rerum', 'jazmyne58@yahoo.com', '$2y$10$wCrhCg1V0g1Qf3jfWgpi8eE46qOvuv95SGJOxGZ5ZbeKD5v9iCjOu', '220-894-4575 x13553', '1-519-566-7887 x981', null, null, null, null, null, null, null, null, null, 'default.jpg');
INSERT INTO `delivery_man` VALUES ('13', 'Cordia Kirlin', 'Carter', 'veniam', 'bertrand26@smith.info', '$2y$10$P5NPJibzLabbE4Q3bI9gHurzfvoSNIBgtUCfYPrnY15Ujm0PoReyW', '382-851-3793', '545.343.8129', null, null, null, null, null, null, null, null, null, 'default.jpg');
INSERT INTO `delivery_man` VALUES ('14', 'Katharina Nienow DDS', 'Robel', 'incidunt', 'bradtke.heath@gmail.com', '$2y$10$qe60toURw6gUVt8p1jbrEepYM3ke4xoN3O.sjR.MOhtzSK1Jiz0Jm', '771.777.0339 x16532', '323.506.8688 x67923', null, null, null, null, null, null, null, null, null, 'default.jpg');
INSERT INTO `delivery_man` VALUES ('15', 'Mrs. Herta Herzog', 'Deckow', 'nisi', 'larson.harvey@kirlin.com', '$2y$10$0GXmxdOskz8gGBnpsxv0tO63XlUuVjWumYFI19tK49hH7hNzpLLba', '(832) 221-5419 x6482', '+1.741.962.7893', null, null, null, null, null, null, null, null, null, 'default.jpg');
INSERT INTO `delivery_man` VALUES ('16', 'Raleigh Satterfield', 'Mayer', 'labore', 'samantha.lehner@berge.org', '$2y$10$JQ/X3rysbM5LRquGxruif.swcYVUbRm9gDmOIQkvI3YqaLfWuw9dW', '+1-565-391-7048', '+1-885-563-1732', null, null, null, null, null, null, null, null, null, 'default.jpg');

-- ----------------------------
-- Table structure for migrations
-- ----------------------------
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of migrations
-- ----------------------------
INSERT INTO `migrations` VALUES ('1', '2010_02_15_173332_roles_permissions', '1');
INSERT INTO `migrations` VALUES ('2', '2010_03_15_173530_roles_users', '1');
INSERT INTO `migrations` VALUES ('3', '2010_12_14_152344_states', '1');
INSERT INTO `migrations` VALUES ('4', '2010_12_14_152345_municipios', '1');
INSERT INTO `migrations` VALUES ('5', '2010_12_14_152346_address', '1');
INSERT INTO `migrations` VALUES ('6', '2010_12_14_153708_admins', '1');
INSERT INTO `migrations` VALUES ('7', '2010_12_15_155728_categories', '1');
INSERT INTO `migrations` VALUES ('8', '2010_12_15_160800_currencies', '1');
INSERT INTO `migrations` VALUES ('9', '2013_02_14_152612_partners', '1');
INSERT INTO `migrations` VALUES ('10', '2013_02_14_152637_delivery_man', '1');
INSERT INTO `migrations` VALUES ('11', '2014_10_12_000000_create_clients_table', '1');
INSERT INTO `migrations` VALUES ('12', '2014_10_12_000000_create_users_table', '1');
INSERT INTO `migrations` VALUES ('13', '2014_10_12_100000_create_password_resets_table', '1');
INSERT INTO `migrations` VALUES ('14', '2015_01_14_152445_clients_address', '1');
INSERT INTO `migrations` VALUES ('15', '2020_02_14_152501_products', '1');
INSERT INTO `migrations` VALUES ('16', '2020_02_14_152652_prod_extras', '1');
INSERT INTO `migrations` VALUES ('17', '2020_02_14_152653_rates', '1');
INSERT INTO `migrations` VALUES ('18', '2020_02_14_152716_orders', '1');
INSERT INTO `migrations` VALUES ('19', '2020_02_14_152804_rate_list', '1');

-- ----------------------------
-- Table structure for municipios
-- ----------------------------
DROP TABLE IF EXISTS `municipios`;
CREATE TABLE `municipios` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `states_id` bigint(20) unsigned NOT NULL,
  `mun_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `municipios_states_id_foreign` (`states_id`),
  CONSTRAINT `municipios_states_id_foreign` FOREIGN KEY (`states_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2681 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of municipios
-- ----------------------------
INSERT INTO `municipios` VALUES ('1', '1', 'Alto Orinoco', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('2', '1', 'Atabapo', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('3', '1', 'Atures', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('4', '1', 'Autana', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('5', '1', 'Manapiare', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('6', '1', 'Maroa', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('7', '1', 'Río Negro', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('8', '2', 'Anaco', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('9', '2', 'Aragua', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('10', '2', 'Manuel Ezequiel Bruzual', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('11', '2', 'Diego Bautista Urbaneja', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('12', '2', 'Fernando Peñalver', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('13', '2', 'Francisco Del Carmen Carvajal', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('14', '2', 'General Sir Arthur McGregor', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('15', '2', 'Guanta', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('16', '2', 'Independencia', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('17', '2', 'José Gregorio Monagas', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('18', '2', 'Juan Antonio Sotillo', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('19', '2', 'Juan Manuel Cajigal', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('20', '2', 'Libertad', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('21', '2', 'Francisco de Miranda', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('22', '2', 'Pedro María Freites', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('23', '2', 'Píritu', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('24', '2', 'San José de Guanipa', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('25', '2', 'San Juan de Capistrano', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('26', '2', 'Santa Ana', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('27', '2', 'Simón Bolívar', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('28', '2', 'Simón Rodríguez', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('29', '3', 'Achaguas', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('30', '3', 'Biruaca', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('31', '3', 'Muñóz', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('32', '3', 'Páez', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('33', '3', 'Pedro Camejo', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('34', '3', 'Rómulo Gallegos', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('35', '3', 'San Fernando', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('36', '4', 'Atanasio Girardot', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('37', '4', 'Bolívar', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('38', '4', 'Camatagua', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('39', '4', 'Francisco Linares Alcántara', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('40', '4', 'José Ángel Lamas', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('41', '4', 'José Félix Ribas', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('42', '4', 'José Rafael Revenga', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('43', '4', 'Libertador', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('44', '4', 'Mario Briceño Iragorry', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('45', '4', 'Ocumare de la Costa de Oro', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('46', '4', 'San Casimiro', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('47', '4', 'San Sebastián', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('48', '4', 'Santiago Mariño', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('49', '4', 'Santos Michelena', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('50', '4', 'Sucre', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('51', '4', 'Tovar', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('52', '4', 'Urdaneta', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('53', '4', 'Zamora', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('54', '5', 'Alberto Arvelo Torrealba', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('55', '5', 'Andrés Eloy Blanco', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('56', '5', 'Antonio José de Sucre', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('57', '5', 'Arismendi', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('58', '5', 'Barinas', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('59', '5', 'Bolívar', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('60', '5', 'Cruz Paredes', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('61', '5', 'Ezequiel Zamora', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('62', '5', 'Obispos', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('63', '5', 'Pedraza', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('64', '5', 'Rojas', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('65', '5', 'Sosa', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('66', '6', 'Caroní', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('67', '6', 'Cedeño', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('68', '6', 'El Callao', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('69', '6', 'Gran Sabana', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('70', '6', 'Heres', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('71', '6', 'Piar', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('72', '6', 'Angostura (Raúl Leoni)', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('73', '6', 'Roscio', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('74', '6', 'Sifontes', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('75', '6', 'Sucre', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('76', '6', 'Padre Pedro Chien', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('77', '7', 'Bejuma', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('78', '7', 'Carlos Arvelo', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('79', '7', 'Diego Ibarra', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('80', '7', 'Guacara', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('81', '7', 'Juan José Mora', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('82', '7', 'Libertador', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('83', '7', 'Los Guayos', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('84', '7', 'Miranda', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('85', '7', 'Montalbán', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('86', '7', 'Naguanagua', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('87', '7', 'Puerto Cabello', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('88', '7', 'San Diego', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('89', '7', 'San Joaquín', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('90', '7', 'Valencia', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('91', '8', 'Anzoátegui', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('92', '8', 'Tinaquillo', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('93', '8', 'Girardot', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('94', '8', 'Lima Blanco', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('95', '8', 'Pao de San Juan Bautista', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('96', '8', 'Ricaurte', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('97', '8', 'Rómulo Gallegos', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('98', '8', 'San Carlos', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('99', '8', 'Tinaco', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('100', '9', 'Antonio Díaz', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('101', '9', 'Casacoima', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('102', '9', 'Pedernales', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('103', '9', 'Tucupita', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('104', '10', 'Acosta', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('105', '10', 'Bolívar', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('106', '10', 'Buchivacoa', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('107', '10', 'Cacique Manaure', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('108', '10', 'Carirubana', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('109', '10', 'Colina', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('110', '10', 'Dabajuro', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('111', '10', 'Democracia', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('112', '10', 'Falcón', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('113', '10', 'Federación', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('114', '10', 'Jacura', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('115', '10', 'José Laurencio Silva', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('116', '10', 'Los Taques', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('117', '10', 'Mauroa', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('118', '10', 'Miranda', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('119', '10', 'Monseñor Iturriza', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('120', '10', 'Palmasola', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('121', '10', 'Petit', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('122', '10', 'Píritu', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('123', '10', 'San Francisco', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('124', '10', 'Sucre', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('125', '10', 'Tocópero', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('126', '10', 'Unión', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('127', '10', 'Urumaco', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('128', '10', 'Zamora', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('129', '11', 'Camaguán', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('130', '11', 'Chaguaramas', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('131', '11', 'El Socorro', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('132', '11', 'José Félix Ribas', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('133', '11', 'José Tadeo Monagas', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('134', '11', 'Juan Germán Roscio', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('135', '11', 'Julián Mellado', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('136', '11', 'Las Mercedes', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('137', '11', 'Leonardo Infante', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('138', '11', 'Pedro Zaraza', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('139', '11', 'Ortíz', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('140', '11', 'San Gerónimo de Guayabal', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('141', '11', 'San José de Guaribe', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('142', '11', 'Santa María de Ipire', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('143', '11', 'Sebastián Francisco de Miranda', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('144', '12', 'Andrés Eloy Blanco', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('145', '12', 'Crespo', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('146', '12', 'Iribarren', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('147', '12', 'Jiménez', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('148', '12', 'Morán', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('149', '12', 'Palavecino', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('150', '12', 'Simón Planas', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('151', '12', 'Torres', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('152', '12', 'Urdaneta', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('153', '13', 'Alberto Adriani', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('154', '13', 'Andrés Bello', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('155', '13', 'Antonio Pinto Salinas', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('156', '13', 'Aricagua', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('157', '13', 'Arzobispo Chacón', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('158', '13', 'Campo Elías', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('159', '13', 'Caracciolo Parra Olmedo', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('160', '13', 'Cardenal Quintero', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('161', '13', 'Guaraque', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('162', '13', 'Julio César Salas', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('163', '13', 'Justo Briceño', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('164', '13', 'Libertador', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('165', '13', 'Miranda', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('166', '13', 'Obispo Ramos de Lora', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('167', '13', 'Padre Noguera', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('168', '13', 'Pueblo Llano', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('169', '13', 'Rangel', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('170', '13', 'Rivas Dávila', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('171', '13', 'Santos Marquina', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('172', '13', 'Sucre', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('173', '13', 'Tovar', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('174', '13', 'Tulio Febres Cordero', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('175', '13', 'Zea', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('176', '14', 'Acevedo', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('177', '14', 'Andrés Bello', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('178', '14', 'Baruta', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('179', '14', 'Brión', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('180', '14', 'Buroz', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('181', '14', 'Carrizal', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('182', '14', 'Chacao', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('183', '14', 'Cristóbal Rojas', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('184', '14', 'El Hatillo', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('185', '14', 'Guaicaipuro', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('186', '14', 'Independencia', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('187', '14', 'Lander', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('188', '14', 'Los Salias', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('189', '14', 'Páez', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('190', '14', 'Paz Castillo', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('191', '14', 'Pedro Gual', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('192', '14', 'Plaza', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('193', '14', 'Simón Bolívar', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('194', '14', 'Sucre', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('195', '14', 'Urdaneta', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('196', '14', 'Zamora', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('197', '15', 'Acosta', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('198', '15', 'Aguasay', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('199', '15', 'Bolívar', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('200', '15', 'Caripe', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('201', '15', 'Cedeño', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('202', '15', 'Ezequiel Zamora', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('203', '15', 'Libertador', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('204', '15', 'Maturín', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('205', '15', 'Piar', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('206', '15', 'Punceres', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('207', '15', 'Santa Bárbara', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('208', '15', 'Sotillo', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('209', '15', 'Uracoa', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('210', '16', 'Antolin del Campo', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('211', '16', 'Arismendi', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('212', '16', 'García', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('213', '16', 'Gómez', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('214', '16', 'Maneiro', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('215', '16', 'Marcano', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('216', '16', 'Mariño', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('217', '16', 'Península de Macanao', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('218', '16', 'Tubores', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('219', '16', 'Villalba', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('220', '16', 'Díaz', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('221', '17', 'Agua Blanca', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('222', '17', 'Araure', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('223', '17', 'Esteller', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('224', '17', 'Guanare', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('225', '17', 'Guanarito', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('226', '17', 'Monseñor José Vicente de Unda', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('227', '17', 'Ospino', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('228', '17', 'Páez', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('229', '17', 'Papelón', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('230', '17', 'San Genaro de Boconoíto', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('231', '17', 'San Rafael de Onoto', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('232', '17', 'Santa Rosalía', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('233', '17', 'Sucre', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('234', '17', 'Turén', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('235', '18', 'Andrés Eloy Blanco', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('236', '18', 'Andrés Mata', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('237', '18', 'Arismendi', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('238', '18', 'Benítez', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('239', '18', 'Bermúdez', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('240', '18', 'Bolívar', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('241', '18', 'Cajigal', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('242', '18', 'Cruz Salmerón Acosta', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('243', '18', 'Libertador', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('244', '18', 'Mariño', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('245', '18', 'Mejía', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('246', '18', 'Montes', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('247', '18', 'Ribero', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('248', '18', 'Sucre', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('249', '18', 'Valdéz', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('250', '19', 'Andrés Bello', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('251', '19', 'Antonio Rómulo Costa', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('252', '19', 'Ayacucho', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('253', '19', 'Bolívar', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('254', '19', 'Cárdenas', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('255', '19', 'Córdoba', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('256', '19', 'Fernández Feo', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('257', '19', 'Francisco de Miranda', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('258', '19', 'García de Hevia', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('259', '19', 'Guásimos', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('260', '19', 'Independencia', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('261', '19', 'Jáuregui', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('262', '19', 'José María Vargas', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('263', '19', 'Junín', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('264', '19', 'Libertad', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('265', '19', 'Libertador', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('266', '19', 'Lobatera', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('267', '19', 'Michelena', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('268', '19', 'Panamericano', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('269', '19', 'Pedro María Ureña', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('270', '19', 'Rafael Urdaneta', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('271', '19', 'Samuel Darío Maldonado', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('272', '19', 'San Cristóbal', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('273', '19', 'Seboruco', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('274', '19', 'Simón Rodríguez', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('275', '19', 'Sucre', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('276', '19', 'Torbes', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('277', '19', 'Uribante', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('278', '19', 'San Judas Tadeo', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('279', '20', 'Andrés Bello', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('280', '20', 'Boconó', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('281', '20', 'Bolívar', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('282', '20', 'Candelaria', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('283', '20', 'Carache', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('284', '20', 'Escuque', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('285', '20', 'José Felipe Márquez Cañizalez', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('286', '20', 'Juan Vicente Campos Elías', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('287', '20', 'La Ceiba', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('288', '20', 'Miranda', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('289', '20', 'Monte Carmelo', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('290', '20', 'Motatán', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('291', '20', 'Pampán', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('292', '20', 'Pampanito', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('293', '20', 'Rafael Rangel', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('294', '20', 'San Rafael de Carvajal', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('295', '20', 'Sucre', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('296', '20', 'Trujillo', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('297', '20', 'Urdaneta', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('298', '20', 'Valera', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('299', '21', 'Vargas', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('300', '22', 'Arístides Bastidas', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('301', '22', 'Bolívar', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('302', '22', 'Bruzual', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('303', '22', 'Cocorote', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('304', '22', 'Independencia', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('305', '22', 'José Antonio Páez', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('306', '22', 'La Trinidad', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('307', '22', 'Manuel Monge', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('308', '22', 'Nirgua', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('309', '22', 'Peña', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('310', '22', 'San Felipe', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('311', '22', 'Sucre', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('312', '22', 'Urachiche', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('313', '22', 'José Joaquín Veroes', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('314', '23', 'Almirante Padilla', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('315', '23', 'Baralt', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('316', '23', 'Cabimas', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('317', '23', 'Catatumbo', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('318', '23', 'Colón', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('319', '23', 'Francisco Javier Pulgar', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('320', '23', 'Páez', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('321', '23', 'Jesús Enrique Losada', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('322', '23', 'Jesús María Semprún', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('323', '23', 'La Cañada de Urdaneta', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('324', '23', 'Lagunillas', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('325', '23', 'Machiques de Perijá', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('326', '23', 'Mara', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('327', '23', 'Maracaibo', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('328', '23', 'Miranda', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('329', '23', 'Rosario de Perijá', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('330', '23', 'San Francisco', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('331', '23', 'Santa Rita', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('332', '23', 'Simón Bolívar', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('333', '23', 'Sucre', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('334', '23', 'Valmore Rodríguez', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('335', '24', 'Libertador', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `municipios` VALUES ('336', '1', 'Alto Orinoco', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('337', '1', 'Atabapo', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('338', '1', 'Atures', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('339', '1', 'Autana', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('340', '1', 'Manapiare', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('341', '1', 'Maroa', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('342', '1', 'Río Negro', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('343', '2', 'Anaco', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('344', '2', 'Aragua', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('345', '2', 'Manuel Ezequiel Bruzual', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('346', '2', 'Diego Bautista Urbaneja', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('347', '2', 'Fernando Peñalver', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('348', '2', 'Francisco Del Carmen Carvajal', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('349', '2', 'General Sir Arthur McGregor', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('350', '2', 'Guanta', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('351', '2', 'Independencia', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('352', '2', 'José Gregorio Monagas', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('353', '2', 'Juan Antonio Sotillo', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('354', '2', 'Juan Manuel Cajigal', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('355', '2', 'Libertad', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('356', '2', 'Francisco de Miranda', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('357', '2', 'Pedro María Freites', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('358', '2', 'Píritu', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('359', '2', 'San José de Guanipa', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('360', '2', 'San Juan de Capistrano', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('361', '2', 'Santa Ana', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('362', '2', 'Simón Bolívar', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('363', '2', 'Simón Rodríguez', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('364', '3', 'Achaguas', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('365', '3', 'Biruaca', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('366', '3', 'Muñóz', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('367', '3', 'Páez', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('368', '3', 'Pedro Camejo', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('369', '3', 'Rómulo Gallegos', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('370', '3', 'San Fernando', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('371', '4', 'Atanasio Girardot', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('372', '4', 'Bolívar', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('373', '4', 'Camatagua', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('374', '4', 'Francisco Linares Alcántara', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('375', '4', 'José Ángel Lamas', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('376', '4', 'José Félix Ribas', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('377', '4', 'José Rafael Revenga', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('378', '4', 'Libertador', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('379', '4', 'Mario Briceño Iragorry', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('380', '4', 'Ocumare de la Costa de Oro', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('381', '4', 'San Casimiro', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('382', '4', 'San Sebastián', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('383', '4', 'Santiago Mariño', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('384', '4', 'Santos Michelena', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('385', '4', 'Sucre', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('386', '4', 'Tovar', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('387', '4', 'Urdaneta', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('388', '4', 'Zamora', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('389', '5', 'Alberto Arvelo Torrealba', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('390', '5', 'Andrés Eloy Blanco', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('391', '5', 'Antonio José de Sucre', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('392', '5', 'Arismendi', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('393', '5', 'Barinas', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('394', '5', 'Bolívar', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('395', '5', 'Cruz Paredes', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('396', '5', 'Ezequiel Zamora', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('397', '5', 'Obispos', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('398', '5', 'Pedraza', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('399', '5', 'Rojas', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('400', '5', 'Sosa', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('401', '6', 'Caroní', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('402', '6', 'Cedeño', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('403', '6', 'El Callao', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('404', '6', 'Gran Sabana', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('405', '6', 'Heres', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('406', '6', 'Piar', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('407', '6', 'Angostura (Raúl Leoni)', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('408', '6', 'Roscio', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('409', '6', 'Sifontes', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('410', '6', 'Sucre', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('411', '6', 'Padre Pedro Chien', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('412', '7', 'Bejuma', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('413', '7', 'Carlos Arvelo', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('414', '7', 'Diego Ibarra', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('415', '7', 'Guacara', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('416', '7', 'Juan José Mora', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('417', '7', 'Libertador', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('418', '7', 'Los Guayos', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('419', '7', 'Miranda', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('420', '7', 'Montalbán', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('421', '7', 'Naguanagua', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('422', '7', 'Puerto Cabello', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('423', '7', 'San Diego', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('424', '7', 'San Joaquín', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('425', '7', 'Valencia', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('426', '8', 'Anzoátegui', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('427', '8', 'Tinaquillo', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('428', '8', 'Girardot', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('429', '8', 'Lima Blanco', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('430', '8', 'Pao de San Juan Bautista', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('431', '8', 'Ricaurte', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('432', '8', 'Rómulo Gallegos', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('433', '8', 'San Carlos', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('434', '8', 'Tinaco', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('435', '9', 'Antonio Díaz', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('436', '9', 'Casacoima', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('437', '9', 'Pedernales', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('438', '9', 'Tucupita', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('439', '10', 'Acosta', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('440', '10', 'Bolívar', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('441', '10', 'Buchivacoa', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('442', '10', 'Cacique Manaure', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('443', '10', 'Carirubana', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('444', '10', 'Colina', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('445', '10', 'Dabajuro', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('446', '10', 'Democracia', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('447', '10', 'Falcón', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('448', '10', 'Federación', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('449', '10', 'Jacura', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('450', '10', 'José Laurencio Silva', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('451', '10', 'Los Taques', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('452', '10', 'Mauroa', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('453', '10', 'Miranda', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('454', '10', 'Monseñor Iturriza', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('455', '10', 'Palmasola', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('456', '10', 'Petit', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('457', '10', 'Píritu', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('458', '10', 'San Francisco', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('459', '10', 'Sucre', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('460', '10', 'Tocópero', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('461', '10', 'Unión', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('462', '10', 'Urumaco', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('463', '10', 'Zamora', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('464', '11', 'Camaguán', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('465', '11', 'Chaguaramas', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('466', '11', 'El Socorro', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('467', '11', 'José Félix Ribas', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('468', '11', 'José Tadeo Monagas', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('469', '11', 'Juan Germán Roscio', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('470', '11', 'Julián Mellado', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('471', '11', 'Las Mercedes', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('472', '11', 'Leonardo Infante', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('473', '11', 'Pedro Zaraza', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('474', '11', 'Ortíz', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('475', '11', 'San Gerónimo de Guayabal', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('476', '11', 'San José de Guaribe', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('477', '11', 'Santa María de Ipire', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('478', '11', 'Sebastián Francisco de Miranda', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('479', '12', 'Andrés Eloy Blanco', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('480', '12', 'Crespo', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('481', '12', 'Iribarren', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('482', '12', 'Jiménez', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('483', '12', 'Morán', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('484', '12', 'Palavecino', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('485', '12', 'Simón Planas', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('486', '12', 'Torres', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('487', '12', 'Urdaneta', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('488', '13', 'Alberto Adriani', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('489', '13', 'Andrés Bello', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('490', '13', 'Antonio Pinto Salinas', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('491', '13', 'Aricagua', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('492', '13', 'Arzobispo Chacón', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('493', '13', 'Campo Elías', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('494', '13', 'Caracciolo Parra Olmedo', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('495', '13', 'Cardenal Quintero', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('496', '13', 'Guaraque', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('497', '13', 'Julio César Salas', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('498', '13', 'Justo Briceño', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('499', '13', 'Libertador', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('500', '13', 'Miranda', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('501', '13', 'Obispo Ramos de Lora', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('502', '13', 'Padre Noguera', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('503', '13', 'Pueblo Llano', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('504', '13', 'Rangel', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('505', '13', 'Rivas Dávila', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('506', '13', 'Santos Marquina', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('507', '13', 'Sucre', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('508', '13', 'Tovar', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('509', '13', 'Tulio Febres Cordero', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('510', '13', 'Zea', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('511', '14', 'Acevedo', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('512', '14', 'Andrés Bello', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('513', '14', 'Baruta', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('514', '14', 'Brión', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('515', '14', 'Buroz', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('516', '14', 'Carrizal', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('517', '14', 'Chacao', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('518', '14', 'Cristóbal Rojas', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('519', '14', 'El Hatillo', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('520', '14', 'Guaicaipuro', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('521', '14', 'Independencia', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('522', '14', 'Lander', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('523', '14', 'Los Salias', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('524', '14', 'Páez', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('525', '14', 'Paz Castillo', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('526', '14', 'Pedro Gual', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('527', '14', 'Plaza', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('528', '14', 'Simón Bolívar', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('529', '14', 'Sucre', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('530', '14', 'Urdaneta', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('531', '14', 'Zamora', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('532', '15', 'Acosta', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('533', '15', 'Aguasay', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('534', '15', 'Bolívar', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('535', '15', 'Caripe', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('536', '15', 'Cedeño', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('537', '15', 'Ezequiel Zamora', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('538', '15', 'Libertador', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('539', '15', 'Maturín', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('540', '15', 'Piar', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('541', '15', 'Punceres', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('542', '15', 'Santa Bárbara', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('543', '15', 'Sotillo', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('544', '15', 'Uracoa', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('545', '16', 'Antolin del Campo', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('546', '16', 'Arismendi', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('547', '16', 'García', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('548', '16', 'Gómez', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('549', '16', 'Maneiro', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('550', '16', 'Marcano', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('551', '16', 'Mariño', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('552', '16', 'Península de Macanao', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('553', '16', 'Tubores', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('554', '16', 'Villalba', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('555', '16', 'Díaz', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('556', '17', 'Agua Blanca', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('557', '17', 'Araure', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('558', '17', 'Esteller', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('559', '17', 'Guanare', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('560', '17', 'Guanarito', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('561', '17', 'Monseñor José Vicente de Unda', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('562', '17', 'Ospino', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('563', '17', 'Páez', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('564', '17', 'Papelón', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('565', '17', 'San Genaro de Boconoíto', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('566', '17', 'San Rafael de Onoto', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('567', '17', 'Santa Rosalía', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('568', '17', 'Sucre', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('569', '17', 'Turén', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('570', '18', 'Andrés Eloy Blanco', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('571', '18', 'Andrés Mata', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('572', '18', 'Arismendi', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('573', '18', 'Benítez', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('574', '18', 'Bermúdez', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('575', '18', 'Bolívar', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('576', '18', 'Cajigal', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('577', '18', 'Cruz Salmerón Acosta', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('578', '18', 'Libertador', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('579', '18', 'Mariño', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('580', '18', 'Mejía', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('581', '18', 'Montes', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('582', '18', 'Ribero', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('583', '18', 'Sucre', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('584', '18', 'Valdéz', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('585', '19', 'Andrés Bello', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('586', '19', 'Antonio Rómulo Costa', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('587', '19', 'Ayacucho', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('588', '19', 'Bolívar', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('589', '19', 'Cárdenas', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('590', '19', 'Córdoba', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('591', '19', 'Fernández Feo', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('592', '19', 'Francisco de Miranda', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('593', '19', 'García de Hevia', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('594', '19', 'Guásimos', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('595', '19', 'Independencia', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('596', '19', 'Jáuregui', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('597', '19', 'José María Vargas', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('598', '19', 'Junín', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('599', '19', 'Libertad', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('600', '19', 'Libertador', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('601', '19', 'Lobatera', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('602', '19', 'Michelena', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('603', '19', 'Panamericano', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('604', '19', 'Pedro María Ureña', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('605', '19', 'Rafael Urdaneta', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('606', '19', 'Samuel Darío Maldonado', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('607', '19', 'San Cristóbal', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('608', '19', 'Seboruco', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('609', '19', 'Simón Rodríguez', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('610', '19', 'Sucre', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('611', '19', 'Torbes', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('612', '19', 'Uribante', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('613', '19', 'San Judas Tadeo', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('614', '20', 'Andrés Bello', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('615', '20', 'Boconó', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('616', '20', 'Bolívar', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('617', '20', 'Candelaria', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('618', '20', 'Carache', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('619', '20', 'Escuque', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('620', '20', 'José Felipe Márquez Cañizalez', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('621', '20', 'Juan Vicente Campos Elías', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('622', '20', 'La Ceiba', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('623', '20', 'Miranda', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('624', '20', 'Monte Carmelo', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('625', '20', 'Motatán', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('626', '20', 'Pampán', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('627', '20', 'Pampanito', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('628', '20', 'Rafael Rangel', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('629', '20', 'San Rafael de Carvajal', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('630', '20', 'Sucre', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('631', '20', 'Trujillo', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('632', '20', 'Urdaneta', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('633', '20', 'Valera', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('634', '21', 'Vargas', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('635', '22', 'Arístides Bastidas', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('636', '22', 'Bolívar', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('637', '22', 'Bruzual', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('638', '22', 'Cocorote', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('639', '22', 'Independencia', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('640', '22', 'José Antonio Páez', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('641', '22', 'La Trinidad', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('642', '22', 'Manuel Monge', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('643', '22', 'Nirgua', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('644', '22', 'Peña', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('645', '22', 'San Felipe', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('646', '22', 'Sucre', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('647', '22', 'Urachiche', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('648', '22', 'José Joaquín Veroes', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('649', '23', 'Almirante Padilla', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('650', '23', 'Baralt', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('651', '23', 'Cabimas', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('652', '23', 'Catatumbo', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('653', '23', 'Colón', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('654', '23', 'Francisco Javier Pulgar', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('655', '23', 'Páez', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('656', '23', 'Jesús Enrique Losada', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('657', '23', 'Jesús María Semprún', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('658', '23', 'La Cañada de Urdaneta', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('659', '23', 'Lagunillas', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('660', '23', 'Machiques de Perijá', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('661', '23', 'Mara', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('662', '23', 'Maracaibo', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('663', '23', 'Miranda', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('664', '23', 'Rosario de Perijá', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('665', '23', 'San Francisco', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('666', '23', 'Santa Rita', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('667', '23', 'Simón Bolívar', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('668', '23', 'Sucre', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('669', '23', 'Valmore Rodríguez', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('670', '24', 'Libertador', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `municipios` VALUES ('671', '1', 'Alto Orinoco', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('672', '1', 'Atabapo', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('673', '1', 'Atures', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('674', '1', 'Autana', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('675', '1', 'Manapiare', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('676', '1', 'Maroa', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('677', '1', 'Río Negro', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('678', '2', 'Anaco', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('679', '2', 'Aragua', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('680', '2', 'Manuel Ezequiel Bruzual', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('681', '2', 'Diego Bautista Urbaneja', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('682', '2', 'Fernando Peñalver', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('683', '2', 'Francisco Del Carmen Carvajal', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('684', '2', 'General Sir Arthur McGregor', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('685', '2', 'Guanta', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('686', '2', 'Independencia', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('687', '2', 'José Gregorio Monagas', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('688', '2', 'Juan Antonio Sotillo', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('689', '2', 'Juan Manuel Cajigal', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('690', '2', 'Libertad', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('691', '2', 'Francisco de Miranda', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('692', '2', 'Pedro María Freites', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('693', '2', 'Píritu', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('694', '2', 'San José de Guanipa', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('695', '2', 'San Juan de Capistrano', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('696', '2', 'Santa Ana', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('697', '2', 'Simón Bolívar', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('698', '2', 'Simón Rodríguez', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('699', '3', 'Achaguas', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('700', '3', 'Biruaca', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('701', '3', 'Muñóz', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('702', '3', 'Páez', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('703', '3', 'Pedro Camejo', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('704', '3', 'Rómulo Gallegos', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('705', '3', 'San Fernando', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('706', '4', 'Atanasio Girardot', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('707', '4', 'Bolívar', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('708', '4', 'Camatagua', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('709', '4', 'Francisco Linares Alcántara', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('710', '4', 'José Ángel Lamas', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('711', '4', 'José Félix Ribas', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('712', '4', 'José Rafael Revenga', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('713', '4', 'Libertador', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('714', '4', 'Mario Briceño Iragorry', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('715', '4', 'Ocumare de la Costa de Oro', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('716', '4', 'San Casimiro', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('717', '4', 'San Sebastián', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('718', '4', 'Santiago Mariño', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('719', '4', 'Santos Michelena', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('720', '4', 'Sucre', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('721', '4', 'Tovar', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('722', '4', 'Urdaneta', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('723', '4', 'Zamora', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('724', '5', 'Alberto Arvelo Torrealba', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('725', '5', 'Andrés Eloy Blanco', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('726', '5', 'Antonio José de Sucre', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('727', '5', 'Arismendi', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('728', '5', 'Barinas', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('729', '5', 'Bolívar', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('730', '5', 'Cruz Paredes', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('731', '5', 'Ezequiel Zamora', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('732', '5', 'Obispos', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('733', '5', 'Pedraza', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('734', '5', 'Rojas', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('735', '5', 'Sosa', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('736', '6', 'Caroní', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('737', '6', 'Cedeño', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('738', '6', 'El Callao', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('739', '6', 'Gran Sabana', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('740', '6', 'Heres', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('741', '6', 'Piar', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('742', '6', 'Angostura (Raúl Leoni)', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('743', '6', 'Roscio', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('744', '6', 'Sifontes', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('745', '6', 'Sucre', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('746', '6', 'Padre Pedro Chien', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('747', '7', 'Bejuma', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('748', '7', 'Carlos Arvelo', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('749', '7', 'Diego Ibarra', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('750', '7', 'Guacara', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('751', '7', 'Juan José Mora', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('752', '7', 'Libertador', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('753', '7', 'Los Guayos', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('754', '7', 'Miranda', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('755', '7', 'Montalbán', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('756', '7', 'Naguanagua', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('757', '7', 'Puerto Cabello', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('758', '7', 'San Diego', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('759', '7', 'San Joaquín', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('760', '7', 'Valencia', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('761', '8', 'Anzoátegui', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('762', '8', 'Tinaquillo', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('763', '8', 'Girardot', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('764', '8', 'Lima Blanco', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('765', '8', 'Pao de San Juan Bautista', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('766', '8', 'Ricaurte', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('767', '8', 'Rómulo Gallegos', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('768', '8', 'San Carlos', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('769', '8', 'Tinaco', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('770', '9', 'Antonio Díaz', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('771', '9', 'Casacoima', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('772', '9', 'Pedernales', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('773', '9', 'Tucupita', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('774', '10', 'Acosta', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('775', '10', 'Bolívar', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('776', '10', 'Buchivacoa', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('777', '10', 'Cacique Manaure', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('778', '10', 'Carirubana', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('779', '10', 'Colina', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('780', '10', 'Dabajuro', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('781', '10', 'Democracia', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('782', '10', 'Falcón', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('783', '10', 'Federación', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('784', '10', 'Jacura', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('785', '10', 'José Laurencio Silva', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('786', '10', 'Los Taques', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('787', '10', 'Mauroa', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('788', '10', 'Miranda', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('789', '10', 'Monseñor Iturriza', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('790', '10', 'Palmasola', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('791', '10', 'Petit', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('792', '10', 'Píritu', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('793', '10', 'San Francisco', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('794', '10', 'Sucre', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('795', '10', 'Tocópero', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('796', '10', 'Unión', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('797', '10', 'Urumaco', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('798', '10', 'Zamora', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('799', '11', 'Camaguán', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('800', '11', 'Chaguaramas', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('801', '11', 'El Socorro', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('802', '11', 'José Félix Ribas', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('803', '11', 'José Tadeo Monagas', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('804', '11', 'Juan Germán Roscio', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('805', '11', 'Julián Mellado', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('806', '11', 'Las Mercedes', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('807', '11', 'Leonardo Infante', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('808', '11', 'Pedro Zaraza', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('809', '11', 'Ortíz', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('810', '11', 'San Gerónimo de Guayabal', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('811', '11', 'San José de Guaribe', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('812', '11', 'Santa María de Ipire', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('813', '11', 'Sebastián Francisco de Miranda', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('814', '12', 'Andrés Eloy Blanco', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('815', '12', 'Crespo', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('816', '12', 'Iribarren', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('817', '12', 'Jiménez', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('818', '12', 'Morán', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('819', '12', 'Palavecino', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('820', '12', 'Simón Planas', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('821', '12', 'Torres', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('822', '12', 'Urdaneta', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('823', '13', 'Alberto Adriani', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('824', '13', 'Andrés Bello', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('825', '13', 'Antonio Pinto Salinas', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('826', '13', 'Aricagua', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('827', '13', 'Arzobispo Chacón', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('828', '13', 'Campo Elías', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('829', '13', 'Caracciolo Parra Olmedo', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('830', '13', 'Cardenal Quintero', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('831', '13', 'Guaraque', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('832', '13', 'Julio César Salas', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('833', '13', 'Justo Briceño', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('834', '13', 'Libertador', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('835', '13', 'Miranda', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('836', '13', 'Obispo Ramos de Lora', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('837', '13', 'Padre Noguera', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('838', '13', 'Pueblo Llano', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('839', '13', 'Rangel', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('840', '13', 'Rivas Dávila', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('841', '13', 'Santos Marquina', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('842', '13', 'Sucre', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('843', '13', 'Tovar', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('844', '13', 'Tulio Febres Cordero', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('845', '13', 'Zea', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('846', '14', 'Acevedo', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('847', '14', 'Andrés Bello', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('848', '14', 'Baruta', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('849', '14', 'Brión', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('850', '14', 'Buroz', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('851', '14', 'Carrizal', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('852', '14', 'Chacao', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('853', '14', 'Cristóbal Rojas', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('854', '14', 'El Hatillo', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('855', '14', 'Guaicaipuro', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('856', '14', 'Independencia', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('857', '14', 'Lander', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('858', '14', 'Los Salias', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('859', '14', 'Páez', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('860', '14', 'Paz Castillo', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('861', '14', 'Pedro Gual', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('862', '14', 'Plaza', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('863', '14', 'Simón Bolívar', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('864', '14', 'Sucre', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('865', '14', 'Urdaneta', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('866', '14', 'Zamora', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('867', '15', 'Acosta', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('868', '15', 'Aguasay', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('869', '15', 'Bolívar', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('870', '15', 'Caripe', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('871', '15', 'Cedeño', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('872', '15', 'Ezequiel Zamora', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('873', '15', 'Libertador', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('874', '15', 'Maturín', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('875', '15', 'Piar', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('876', '15', 'Punceres', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('877', '15', 'Santa Bárbara', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('878', '15', 'Sotillo', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('879', '15', 'Uracoa', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('880', '16', 'Antolin del Campo', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('881', '16', 'Arismendi', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('882', '16', 'García', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('883', '16', 'Gómez', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('884', '16', 'Maneiro', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('885', '16', 'Marcano', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('886', '16', 'Mariño', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('887', '16', 'Península de Macanao', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('888', '16', 'Tubores', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('889', '16', 'Villalba', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('890', '16', 'Díaz', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('891', '17', 'Agua Blanca', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('892', '17', 'Araure', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('893', '17', 'Esteller', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('894', '17', 'Guanare', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('895', '17', 'Guanarito', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('896', '17', 'Monseñor José Vicente de Unda', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('897', '17', 'Ospino', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('898', '17', 'Páez', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('899', '17', 'Papelón', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('900', '17', 'San Genaro de Boconoíto', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('901', '17', 'San Rafael de Onoto', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('902', '17', 'Santa Rosalía', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('903', '17', 'Sucre', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('904', '17', 'Turén', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('905', '18', 'Andrés Eloy Blanco', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('906', '18', 'Andrés Mata', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('907', '18', 'Arismendi', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('908', '18', 'Benítez', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('909', '18', 'Bermúdez', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('910', '18', 'Bolívar', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('911', '18', 'Cajigal', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('912', '18', 'Cruz Salmerón Acosta', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('913', '18', 'Libertador', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('914', '18', 'Mariño', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('915', '18', 'Mejía', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('916', '18', 'Montes', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('917', '18', 'Ribero', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('918', '18', 'Sucre', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('919', '18', 'Valdéz', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('920', '19', 'Andrés Bello', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('921', '19', 'Antonio Rómulo Costa', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('922', '19', 'Ayacucho', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('923', '19', 'Bolívar', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('924', '19', 'Cárdenas', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('925', '19', 'Córdoba', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('926', '19', 'Fernández Feo', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('927', '19', 'Francisco de Miranda', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('928', '19', 'García de Hevia', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('929', '19', 'Guásimos', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('930', '19', 'Independencia', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('931', '19', 'Jáuregui', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('932', '19', 'José María Vargas', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('933', '19', 'Junín', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('934', '19', 'Libertad', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('935', '19', 'Libertador', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('936', '19', 'Lobatera', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('937', '19', 'Michelena', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('938', '19', 'Panamericano', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('939', '19', 'Pedro María Ureña', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('940', '19', 'Rafael Urdaneta', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('941', '19', 'Samuel Darío Maldonado', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('942', '19', 'San Cristóbal', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('943', '19', 'Seboruco', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('944', '19', 'Simón Rodríguez', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('945', '19', 'Sucre', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('946', '19', 'Torbes', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('947', '19', 'Uribante', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('948', '19', 'San Judas Tadeo', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('949', '20', 'Andrés Bello', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('950', '20', 'Boconó', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('951', '20', 'Bolívar', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('952', '20', 'Candelaria', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('953', '20', 'Carache', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('954', '20', 'Escuque', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('955', '20', 'José Felipe Márquez Cañizalez', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('956', '20', 'Juan Vicente Campos Elías', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('957', '20', 'La Ceiba', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('958', '20', 'Miranda', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('959', '20', 'Monte Carmelo', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('960', '20', 'Motatán', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('961', '20', 'Pampán', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('962', '20', 'Pampanito', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('963', '20', 'Rafael Rangel', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('964', '20', 'San Rafael de Carvajal', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('965', '20', 'Sucre', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('966', '20', 'Trujillo', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('967', '20', 'Urdaneta', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('968', '20', 'Valera', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('969', '21', 'Vargas', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('970', '22', 'Arístides Bastidas', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('971', '22', 'Bolívar', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('972', '22', 'Bruzual', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('973', '22', 'Cocorote', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('974', '22', 'Independencia', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('975', '22', 'José Antonio Páez', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('976', '22', 'La Trinidad', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('977', '22', 'Manuel Monge', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('978', '22', 'Nirgua', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('979', '22', 'Peña', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('980', '22', 'San Felipe', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('981', '22', 'Sucre', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('982', '22', 'Urachiche', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('983', '22', 'José Joaquín Veroes', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('984', '23', 'Almirante Padilla', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('985', '23', 'Baralt', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('986', '23', 'Cabimas', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('987', '23', 'Catatumbo', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('988', '23', 'Colón', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('989', '23', 'Francisco Javier Pulgar', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('990', '23', 'Páez', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('991', '23', 'Jesús Enrique Losada', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('992', '23', 'Jesús María Semprún', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('993', '23', 'La Cañada de Urdaneta', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('994', '23', 'Lagunillas', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('995', '23', 'Machiques de Perijá', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('996', '23', 'Mara', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('997', '23', 'Maracaibo', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('998', '23', 'Miranda', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('999', '23', 'Rosario de Perijá', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('1000', '23', 'San Francisco', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('1001', '23', 'Santa Rita', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('1002', '23', 'Simón Bolívar', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('1003', '23', 'Sucre', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('1004', '23', 'Valmore Rodríguez', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('1005', '24', 'Libertador', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `municipios` VALUES ('1006', '1', 'Alto Orinoco', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1007', '1', 'Atabapo', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1008', '1', 'Atures', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1009', '1', 'Autana', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1010', '1', 'Manapiare', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1011', '1', 'Maroa', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1012', '1', 'Río Negro', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1013', '2', 'Anaco', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1014', '2', 'Aragua', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1015', '2', 'Manuel Ezequiel Bruzual', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1016', '2', 'Diego Bautista Urbaneja', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1017', '2', 'Fernando Peñalver', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1018', '2', 'Francisco Del Carmen Carvajal', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1019', '2', 'General Sir Arthur McGregor', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1020', '2', 'Guanta', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1021', '2', 'Independencia', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1022', '2', 'José Gregorio Monagas', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1023', '2', 'Juan Antonio Sotillo', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1024', '2', 'Juan Manuel Cajigal', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1025', '2', 'Libertad', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1026', '2', 'Francisco de Miranda', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1027', '2', 'Pedro María Freites', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1028', '2', 'Píritu', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1029', '2', 'San José de Guanipa', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1030', '2', 'San Juan de Capistrano', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1031', '2', 'Santa Ana', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1032', '2', 'Simón Bolívar', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1033', '2', 'Simón Rodríguez', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1034', '3', 'Achaguas', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1035', '3', 'Biruaca', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1036', '3', 'Muñóz', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1037', '3', 'Páez', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1038', '3', 'Pedro Camejo', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1039', '3', 'Rómulo Gallegos', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1040', '3', 'San Fernando', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1041', '4', 'Atanasio Girardot', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1042', '4', 'Bolívar', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1043', '4', 'Camatagua', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1044', '4', 'Francisco Linares Alcántara', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1045', '4', 'José Ángel Lamas', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1046', '4', 'José Félix Ribas', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1047', '4', 'José Rafael Revenga', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1048', '4', 'Libertador', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1049', '4', 'Mario Briceño Iragorry', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1050', '4', 'Ocumare de la Costa de Oro', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1051', '4', 'San Casimiro', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1052', '4', 'San Sebastián', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1053', '4', 'Santiago Mariño', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1054', '4', 'Santos Michelena', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1055', '4', 'Sucre', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1056', '4', 'Tovar', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1057', '4', 'Urdaneta', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1058', '4', 'Zamora', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1059', '5', 'Alberto Arvelo Torrealba', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1060', '5', 'Andrés Eloy Blanco', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1061', '5', 'Antonio José de Sucre', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1062', '5', 'Arismendi', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1063', '5', 'Barinas', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1064', '5', 'Bolívar', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1065', '5', 'Cruz Paredes', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1066', '5', 'Ezequiel Zamora', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1067', '5', 'Obispos', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1068', '5', 'Pedraza', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1069', '5', 'Rojas', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1070', '5', 'Sosa', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1071', '6', 'Caroní', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1072', '6', 'Cedeño', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1073', '6', 'El Callao', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1074', '6', 'Gran Sabana', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1075', '6', 'Heres', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1076', '6', 'Piar', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1077', '6', 'Angostura (Raúl Leoni)', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1078', '6', 'Roscio', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1079', '6', 'Sifontes', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1080', '6', 'Sucre', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1081', '6', 'Padre Pedro Chien', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1082', '7', 'Bejuma', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1083', '7', 'Carlos Arvelo', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1084', '7', 'Diego Ibarra', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1085', '7', 'Guacara', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1086', '7', 'Juan José Mora', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1087', '7', 'Libertador', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1088', '7', 'Los Guayos', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1089', '7', 'Miranda', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1090', '7', 'Montalbán', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1091', '7', 'Naguanagua', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1092', '7', 'Puerto Cabello', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1093', '7', 'San Diego', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1094', '7', 'San Joaquín', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1095', '7', 'Valencia', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1096', '8', 'Anzoátegui', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1097', '8', 'Tinaquillo', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1098', '8', 'Girardot', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1099', '8', 'Lima Blanco', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1100', '8', 'Pao de San Juan Bautista', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1101', '8', 'Ricaurte', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1102', '8', 'Rómulo Gallegos', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1103', '8', 'San Carlos', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1104', '8', 'Tinaco', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1105', '9', 'Antonio Díaz', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1106', '9', 'Casacoima', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1107', '9', 'Pedernales', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1108', '9', 'Tucupita', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1109', '10', 'Acosta', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1110', '10', 'Bolívar', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1111', '10', 'Buchivacoa', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1112', '10', 'Cacique Manaure', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1113', '10', 'Carirubana', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1114', '10', 'Colina', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1115', '10', 'Dabajuro', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1116', '10', 'Democracia', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1117', '10', 'Falcón', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1118', '10', 'Federación', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1119', '10', 'Jacura', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1120', '10', 'José Laurencio Silva', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1121', '10', 'Los Taques', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1122', '10', 'Mauroa', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1123', '10', 'Miranda', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1124', '10', 'Monseñor Iturriza', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1125', '10', 'Palmasola', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1126', '10', 'Petit', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1127', '10', 'Píritu', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1128', '10', 'San Francisco', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1129', '10', 'Sucre', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1130', '10', 'Tocópero', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1131', '10', 'Unión', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1132', '10', 'Urumaco', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1133', '10', 'Zamora', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1134', '11', 'Camaguán', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1135', '11', 'Chaguaramas', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1136', '11', 'El Socorro', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1137', '11', 'José Félix Ribas', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1138', '11', 'José Tadeo Monagas', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1139', '11', 'Juan Germán Roscio', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1140', '11', 'Julián Mellado', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1141', '11', 'Las Mercedes', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1142', '11', 'Leonardo Infante', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1143', '11', 'Pedro Zaraza', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1144', '11', 'Ortíz', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1145', '11', 'San Gerónimo de Guayabal', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1146', '11', 'San José de Guaribe', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1147', '11', 'Santa María de Ipire', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1148', '11', 'Sebastián Francisco de Miranda', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1149', '12', 'Andrés Eloy Blanco', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1150', '12', 'Crespo', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1151', '12', 'Iribarren', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1152', '12', 'Jiménez', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1153', '12', 'Morán', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1154', '12', 'Palavecino', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1155', '12', 'Simón Planas', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1156', '12', 'Torres', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1157', '12', 'Urdaneta', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1158', '13', 'Alberto Adriani', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1159', '13', 'Andrés Bello', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1160', '13', 'Antonio Pinto Salinas', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1161', '13', 'Aricagua', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1162', '13', 'Arzobispo Chacón', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1163', '13', 'Campo Elías', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1164', '13', 'Caracciolo Parra Olmedo', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1165', '13', 'Cardenal Quintero', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1166', '13', 'Guaraque', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1167', '13', 'Julio César Salas', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1168', '13', 'Justo Briceño', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1169', '13', 'Libertador', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1170', '13', 'Miranda', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1171', '13', 'Obispo Ramos de Lora', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1172', '13', 'Padre Noguera', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1173', '13', 'Pueblo Llano', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1174', '13', 'Rangel', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1175', '13', 'Rivas Dávila', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1176', '13', 'Santos Marquina', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1177', '13', 'Sucre', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1178', '13', 'Tovar', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1179', '13', 'Tulio Febres Cordero', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1180', '13', 'Zea', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1181', '14', 'Acevedo', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1182', '14', 'Andrés Bello', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1183', '14', 'Baruta', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1184', '14', 'Brión', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1185', '14', 'Buroz', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1186', '14', 'Carrizal', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1187', '14', 'Chacao', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1188', '14', 'Cristóbal Rojas', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1189', '14', 'El Hatillo', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1190', '14', 'Guaicaipuro', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1191', '14', 'Independencia', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1192', '14', 'Lander', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1193', '14', 'Los Salias', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1194', '14', 'Páez', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1195', '14', 'Paz Castillo', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1196', '14', 'Pedro Gual', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1197', '14', 'Plaza', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1198', '14', 'Simón Bolívar', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1199', '14', 'Sucre', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1200', '14', 'Urdaneta', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1201', '14', 'Zamora', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1202', '15', 'Acosta', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1203', '15', 'Aguasay', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1204', '15', 'Bolívar', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1205', '15', 'Caripe', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1206', '15', 'Cedeño', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1207', '15', 'Ezequiel Zamora', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1208', '15', 'Libertador', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1209', '15', 'Maturín', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1210', '15', 'Piar', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1211', '15', 'Punceres', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1212', '15', 'Santa Bárbara', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1213', '15', 'Sotillo', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1214', '15', 'Uracoa', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1215', '16', 'Antolin del Campo', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1216', '16', 'Arismendi', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1217', '16', 'García', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1218', '16', 'Gómez', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1219', '16', 'Maneiro', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1220', '16', 'Marcano', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1221', '16', 'Mariño', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1222', '16', 'Península de Macanao', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1223', '16', 'Tubores', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1224', '16', 'Villalba', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1225', '16', 'Díaz', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1226', '17', 'Agua Blanca', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1227', '17', 'Araure', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1228', '17', 'Esteller', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1229', '17', 'Guanare', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1230', '17', 'Guanarito', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1231', '17', 'Monseñor José Vicente de Unda', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1232', '17', 'Ospino', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1233', '17', 'Páez', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1234', '17', 'Papelón', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1235', '17', 'San Genaro de Boconoíto', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1236', '17', 'San Rafael de Onoto', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1237', '17', 'Santa Rosalía', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1238', '17', 'Sucre', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1239', '17', 'Turén', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1240', '18', 'Andrés Eloy Blanco', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1241', '18', 'Andrés Mata', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1242', '18', 'Arismendi', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1243', '18', 'Benítez', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1244', '18', 'Bermúdez', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1245', '18', 'Bolívar', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1246', '18', 'Cajigal', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1247', '18', 'Cruz Salmerón Acosta', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1248', '18', 'Libertador', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1249', '18', 'Mariño', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1250', '18', 'Mejía', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1251', '18', 'Montes', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1252', '18', 'Ribero', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1253', '18', 'Sucre', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1254', '18', 'Valdéz', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1255', '19', 'Andrés Bello', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1256', '19', 'Antonio Rómulo Costa', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1257', '19', 'Ayacucho', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1258', '19', 'Bolívar', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1259', '19', 'Cárdenas', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1260', '19', 'Córdoba', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1261', '19', 'Fernández Feo', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1262', '19', 'Francisco de Miranda', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1263', '19', 'García de Hevia', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1264', '19', 'Guásimos', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1265', '19', 'Independencia', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1266', '19', 'Jáuregui', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1267', '19', 'José María Vargas', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1268', '19', 'Junín', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1269', '19', 'Libertad', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1270', '19', 'Libertador', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1271', '19', 'Lobatera', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1272', '19', 'Michelena', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1273', '19', 'Panamericano', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1274', '19', 'Pedro María Ureña', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1275', '19', 'Rafael Urdaneta', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1276', '19', 'Samuel Darío Maldonado', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1277', '19', 'San Cristóbal', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1278', '19', 'Seboruco', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1279', '19', 'Simón Rodríguez', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1280', '19', 'Sucre', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1281', '19', 'Torbes', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1282', '19', 'Uribante', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1283', '19', 'San Judas Tadeo', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1284', '20', 'Andrés Bello', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1285', '20', 'Boconó', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1286', '20', 'Bolívar', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1287', '20', 'Candelaria', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1288', '20', 'Carache', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1289', '20', 'Escuque', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1290', '20', 'José Felipe Márquez Cañizalez', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1291', '20', 'Juan Vicente Campos Elías', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1292', '20', 'La Ceiba', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1293', '20', 'Miranda', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1294', '20', 'Monte Carmelo', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1295', '20', 'Motatán', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1296', '20', 'Pampán', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1297', '20', 'Pampanito', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1298', '20', 'Rafael Rangel', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1299', '20', 'San Rafael de Carvajal', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1300', '20', 'Sucre', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1301', '20', 'Trujillo', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1302', '20', 'Urdaneta', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1303', '20', 'Valera', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1304', '21', 'Vargas', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1305', '22', 'Arístides Bastidas', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1306', '22', 'Bolívar', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1307', '22', 'Bruzual', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1308', '22', 'Cocorote', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1309', '22', 'Independencia', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1310', '22', 'José Antonio Páez', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1311', '22', 'La Trinidad', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1312', '22', 'Manuel Monge', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1313', '22', 'Nirgua', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1314', '22', 'Peña', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1315', '22', 'San Felipe', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1316', '22', 'Sucre', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1317', '22', 'Urachiche', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1318', '22', 'José Joaquín Veroes', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1319', '23', 'Almirante Padilla', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1320', '23', 'Baralt', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1321', '23', 'Cabimas', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1322', '23', 'Catatumbo', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1323', '23', 'Colón', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1324', '23', 'Francisco Javier Pulgar', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1325', '23', 'Páez', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1326', '23', 'Jesús Enrique Losada', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1327', '23', 'Jesús María Semprún', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1328', '23', 'La Cañada de Urdaneta', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1329', '23', 'Lagunillas', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1330', '23', 'Machiques de Perijá', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1331', '23', 'Mara', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1332', '23', 'Maracaibo', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1333', '23', 'Miranda', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1334', '23', 'Rosario de Perijá', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1335', '23', 'San Francisco', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1336', '23', 'Santa Rita', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1337', '23', 'Simón Bolívar', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1338', '23', 'Sucre', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1339', '23', 'Valmore Rodríguez', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1340', '24', 'Libertador', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `municipios` VALUES ('1341', '1', 'Alto Orinoco', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1342', '1', 'Atabapo', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1343', '1', 'Atures', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1344', '1', 'Autana', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1345', '1', 'Manapiare', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1346', '1', 'Maroa', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1347', '1', 'Río Negro', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1348', '2', 'Anaco', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1349', '2', 'Aragua', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1350', '2', 'Manuel Ezequiel Bruzual', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1351', '2', 'Diego Bautista Urbaneja', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1352', '2', 'Fernando Peñalver', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1353', '2', 'Francisco Del Carmen Carvajal', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1354', '2', 'General Sir Arthur McGregor', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1355', '2', 'Guanta', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1356', '2', 'Independencia', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1357', '2', 'José Gregorio Monagas', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1358', '2', 'Juan Antonio Sotillo', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1359', '2', 'Juan Manuel Cajigal', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1360', '2', 'Libertad', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1361', '2', 'Francisco de Miranda', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1362', '2', 'Pedro María Freites', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1363', '2', 'Píritu', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1364', '2', 'San José de Guanipa', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1365', '2', 'San Juan de Capistrano', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1366', '2', 'Santa Ana', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1367', '2', 'Simón Bolívar', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1368', '2', 'Simón Rodríguez', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1369', '3', 'Achaguas', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1370', '3', 'Biruaca', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1371', '3', 'Muñóz', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1372', '3', 'Páez', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1373', '3', 'Pedro Camejo', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1374', '3', 'Rómulo Gallegos', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1375', '3', 'San Fernando', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1376', '4', 'Atanasio Girardot', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1377', '4', 'Bolívar', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1378', '4', 'Camatagua', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1379', '4', 'Francisco Linares Alcántara', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1380', '4', 'José Ángel Lamas', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1381', '4', 'José Félix Ribas', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1382', '4', 'José Rafael Revenga', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1383', '4', 'Libertador', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1384', '4', 'Mario Briceño Iragorry', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1385', '4', 'Ocumare de la Costa de Oro', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1386', '4', 'San Casimiro', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1387', '4', 'San Sebastián', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1388', '4', 'Santiago Mariño', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1389', '4', 'Santos Michelena', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1390', '4', 'Sucre', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1391', '4', 'Tovar', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1392', '4', 'Urdaneta', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1393', '4', 'Zamora', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1394', '5', 'Alberto Arvelo Torrealba', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1395', '5', 'Andrés Eloy Blanco', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1396', '5', 'Antonio José de Sucre', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1397', '5', 'Arismendi', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1398', '5', 'Barinas', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1399', '5', 'Bolívar', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1400', '5', 'Cruz Paredes', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1401', '5', 'Ezequiel Zamora', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1402', '5', 'Obispos', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1403', '5', 'Pedraza', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1404', '5', 'Rojas', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1405', '5', 'Sosa', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1406', '6', 'Caroní', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1407', '6', 'Cedeño', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1408', '6', 'El Callao', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1409', '6', 'Gran Sabana', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1410', '6', 'Heres', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1411', '6', 'Piar', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1412', '6', 'Angostura (Raúl Leoni)', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1413', '6', 'Roscio', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1414', '6', 'Sifontes', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1415', '6', 'Sucre', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1416', '6', 'Padre Pedro Chien', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1417', '7', 'Bejuma', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1418', '7', 'Carlos Arvelo', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1419', '7', 'Diego Ibarra', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1420', '7', 'Guacara', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1421', '7', 'Juan José Mora', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1422', '7', 'Libertador', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1423', '7', 'Los Guayos', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1424', '7', 'Miranda', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1425', '7', 'Montalbán', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1426', '7', 'Naguanagua', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1427', '7', 'Puerto Cabello', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1428', '7', 'San Diego', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1429', '7', 'San Joaquín', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1430', '7', 'Valencia', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1431', '8', 'Anzoátegui', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1432', '8', 'Tinaquillo', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1433', '8', 'Girardot', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1434', '8', 'Lima Blanco', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1435', '8', 'Pao de San Juan Bautista', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1436', '8', 'Ricaurte', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1437', '8', 'Rómulo Gallegos', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1438', '8', 'San Carlos', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1439', '8', 'Tinaco', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1440', '9', 'Antonio Díaz', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1441', '9', 'Casacoima', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1442', '9', 'Pedernales', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1443', '9', 'Tucupita', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1444', '10', 'Acosta', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1445', '10', 'Bolívar', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1446', '10', 'Buchivacoa', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1447', '10', 'Cacique Manaure', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1448', '10', 'Carirubana', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1449', '10', 'Colina', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1450', '10', 'Dabajuro', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1451', '10', 'Democracia', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1452', '10', 'Falcón', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1453', '10', 'Federación', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1454', '10', 'Jacura', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1455', '10', 'José Laurencio Silva', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1456', '10', 'Los Taques', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1457', '10', 'Mauroa', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1458', '10', 'Miranda', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1459', '10', 'Monseñor Iturriza', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1460', '10', 'Palmasola', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1461', '10', 'Petit', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1462', '10', 'Píritu', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1463', '10', 'San Francisco', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1464', '10', 'Sucre', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1465', '10', 'Tocópero', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1466', '10', 'Unión', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1467', '10', 'Urumaco', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1468', '10', 'Zamora', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1469', '11', 'Camaguán', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1470', '11', 'Chaguaramas', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1471', '11', 'El Socorro', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1472', '11', 'José Félix Ribas', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1473', '11', 'José Tadeo Monagas', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1474', '11', 'Juan Germán Roscio', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1475', '11', 'Julián Mellado', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1476', '11', 'Las Mercedes', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1477', '11', 'Leonardo Infante', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1478', '11', 'Pedro Zaraza', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1479', '11', 'Ortíz', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1480', '11', 'San Gerónimo de Guayabal', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1481', '11', 'San José de Guaribe', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1482', '11', 'Santa María de Ipire', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1483', '11', 'Sebastián Francisco de Miranda', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1484', '12', 'Andrés Eloy Blanco', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1485', '12', 'Crespo', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1486', '12', 'Iribarren', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1487', '12', 'Jiménez', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1488', '12', 'Morán', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1489', '12', 'Palavecino', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1490', '12', 'Simón Planas', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1491', '12', 'Torres', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1492', '12', 'Urdaneta', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1493', '13', 'Alberto Adriani', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1494', '13', 'Andrés Bello', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1495', '13', 'Antonio Pinto Salinas', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1496', '13', 'Aricagua', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1497', '13', 'Arzobispo Chacón', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1498', '13', 'Campo Elías', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1499', '13', 'Caracciolo Parra Olmedo', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1500', '13', 'Cardenal Quintero', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1501', '13', 'Guaraque', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1502', '13', 'Julio César Salas', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1503', '13', 'Justo Briceño', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1504', '13', 'Libertador', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1505', '13', 'Miranda', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1506', '13', 'Obispo Ramos de Lora', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1507', '13', 'Padre Noguera', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1508', '13', 'Pueblo Llano', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1509', '13', 'Rangel', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1510', '13', 'Rivas Dávila', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1511', '13', 'Santos Marquina', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1512', '13', 'Sucre', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1513', '13', 'Tovar', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1514', '13', 'Tulio Febres Cordero', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1515', '13', 'Zea', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1516', '14', 'Acevedo', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1517', '14', 'Andrés Bello', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1518', '14', 'Baruta', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1519', '14', 'Brión', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1520', '14', 'Buroz', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1521', '14', 'Carrizal', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1522', '14', 'Chacao', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1523', '14', 'Cristóbal Rojas', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1524', '14', 'El Hatillo', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1525', '14', 'Guaicaipuro', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1526', '14', 'Independencia', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1527', '14', 'Lander', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1528', '14', 'Los Salias', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1529', '14', 'Páez', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1530', '14', 'Paz Castillo', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1531', '14', 'Pedro Gual', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1532', '14', 'Plaza', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1533', '14', 'Simón Bolívar', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1534', '14', 'Sucre', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1535', '14', 'Urdaneta', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1536', '14', 'Zamora', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1537', '15', 'Acosta', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1538', '15', 'Aguasay', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1539', '15', 'Bolívar', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1540', '15', 'Caripe', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1541', '15', 'Cedeño', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1542', '15', 'Ezequiel Zamora', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1543', '15', 'Libertador', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1544', '15', 'Maturín', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1545', '15', 'Piar', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1546', '15', 'Punceres', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1547', '15', 'Santa Bárbara', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1548', '15', 'Sotillo', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1549', '15', 'Uracoa', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1550', '16', 'Antolin del Campo', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1551', '16', 'Arismendi', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1552', '16', 'García', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1553', '16', 'Gómez', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1554', '16', 'Maneiro', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1555', '16', 'Marcano', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1556', '16', 'Mariño', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1557', '16', 'Península de Macanao', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1558', '16', 'Tubores', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1559', '16', 'Villalba', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1560', '16', 'Díaz', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1561', '17', 'Agua Blanca', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1562', '17', 'Araure', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1563', '17', 'Esteller', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1564', '17', 'Guanare', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1565', '17', 'Guanarito', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1566', '17', 'Monseñor José Vicente de Unda', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1567', '17', 'Ospino', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1568', '17', 'Páez', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1569', '17', 'Papelón', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1570', '17', 'San Genaro de Boconoíto', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1571', '17', 'San Rafael de Onoto', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1572', '17', 'Santa Rosalía', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1573', '17', 'Sucre', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1574', '17', 'Turén', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1575', '18', 'Andrés Eloy Blanco', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1576', '18', 'Andrés Mata', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1577', '18', 'Arismendi', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1578', '18', 'Benítez', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1579', '18', 'Bermúdez', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1580', '18', 'Bolívar', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1581', '18', 'Cajigal', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1582', '18', 'Cruz Salmerón Acosta', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1583', '18', 'Libertador', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1584', '18', 'Mariño', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1585', '18', 'Mejía', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1586', '18', 'Montes', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1587', '18', 'Ribero', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1588', '18', 'Sucre', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1589', '18', 'Valdéz', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1590', '19', 'Andrés Bello', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1591', '19', 'Antonio Rómulo Costa', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1592', '19', 'Ayacucho', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1593', '19', 'Bolívar', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1594', '19', 'Cárdenas', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1595', '19', 'Córdoba', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1596', '19', 'Fernández Feo', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1597', '19', 'Francisco de Miranda', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1598', '19', 'García de Hevia', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1599', '19', 'Guásimos', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1600', '19', 'Independencia', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1601', '19', 'Jáuregui', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1602', '19', 'José María Vargas', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1603', '19', 'Junín', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1604', '19', 'Libertad', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1605', '19', 'Libertador', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1606', '19', 'Lobatera', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1607', '19', 'Michelena', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1608', '19', 'Panamericano', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1609', '19', 'Pedro María Ureña', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1610', '19', 'Rafael Urdaneta', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1611', '19', 'Samuel Darío Maldonado', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1612', '19', 'San Cristóbal', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1613', '19', 'Seboruco', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1614', '19', 'Simón Rodríguez', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1615', '19', 'Sucre', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1616', '19', 'Torbes', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1617', '19', 'Uribante', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1618', '19', 'San Judas Tadeo', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1619', '20', 'Andrés Bello', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1620', '20', 'Boconó', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1621', '20', 'Bolívar', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1622', '20', 'Candelaria', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1623', '20', 'Carache', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1624', '20', 'Escuque', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1625', '20', 'José Felipe Márquez Cañizalez', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1626', '20', 'Juan Vicente Campos Elías', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1627', '20', 'La Ceiba', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1628', '20', 'Miranda', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1629', '20', 'Monte Carmelo', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1630', '20', 'Motatán', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1631', '20', 'Pampán', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1632', '20', 'Pampanito', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1633', '20', 'Rafael Rangel', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1634', '20', 'San Rafael de Carvajal', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1635', '20', 'Sucre', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1636', '20', 'Trujillo', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1637', '20', 'Urdaneta', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1638', '20', 'Valera', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1639', '21', 'Vargas', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1640', '22', 'Arístides Bastidas', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1641', '22', 'Bolívar', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1642', '22', 'Bruzual', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1643', '22', 'Cocorote', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1644', '22', 'Independencia', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1645', '22', 'José Antonio Páez', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1646', '22', 'La Trinidad', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1647', '22', 'Manuel Monge', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1648', '22', 'Nirgua', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1649', '22', 'Peña', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1650', '22', 'San Felipe', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1651', '22', 'Sucre', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1652', '22', 'Urachiche', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1653', '22', 'José Joaquín Veroes', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1654', '23', 'Almirante Padilla', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1655', '23', 'Baralt', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1656', '23', 'Cabimas', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1657', '23', 'Catatumbo', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1658', '23', 'Colón', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1659', '23', 'Francisco Javier Pulgar', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1660', '23', 'Páez', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1661', '23', 'Jesús Enrique Losada', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1662', '23', 'Jesús María Semprún', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1663', '23', 'La Cañada de Urdaneta', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1664', '23', 'Lagunillas', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1665', '23', 'Machiques de Perijá', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1666', '23', 'Mara', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1667', '23', 'Maracaibo', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1668', '23', 'Miranda', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1669', '23', 'Rosario de Perijá', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1670', '23', 'San Francisco', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1671', '23', 'Santa Rita', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1672', '23', 'Simón Bolívar', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1673', '23', 'Sucre', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1674', '23', 'Valmore Rodríguez', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1675', '24', 'Libertador', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `municipios` VALUES ('1676', '1', 'Alto Orinoco', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1677', '1', 'Atabapo', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1678', '1', 'Atures', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1679', '1', 'Autana', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1680', '1', 'Manapiare', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1681', '1', 'Maroa', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1682', '1', 'Río Negro', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1683', '2', 'Anaco', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1684', '2', 'Aragua', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1685', '2', 'Manuel Ezequiel Bruzual', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1686', '2', 'Diego Bautista Urbaneja', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1687', '2', 'Fernando Peñalver', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1688', '2', 'Francisco Del Carmen Carvajal', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1689', '2', 'General Sir Arthur McGregor', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1690', '2', 'Guanta', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1691', '2', 'Independencia', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1692', '2', 'José Gregorio Monagas', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1693', '2', 'Juan Antonio Sotillo', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1694', '2', 'Juan Manuel Cajigal', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1695', '2', 'Libertad', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1696', '2', 'Francisco de Miranda', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1697', '2', 'Pedro María Freites', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1698', '2', 'Píritu', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1699', '2', 'San José de Guanipa', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1700', '2', 'San Juan de Capistrano', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1701', '2', 'Santa Ana', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1702', '2', 'Simón Bolívar', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1703', '2', 'Simón Rodríguez', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1704', '3', 'Achaguas', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1705', '3', 'Biruaca', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1706', '3', 'Muñóz', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1707', '3', 'Páez', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1708', '3', 'Pedro Camejo', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1709', '3', 'Rómulo Gallegos', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1710', '3', 'San Fernando', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1711', '4', 'Atanasio Girardot', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1712', '4', 'Bolívar', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1713', '4', 'Camatagua', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1714', '4', 'Francisco Linares Alcántara', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1715', '4', 'José Ángel Lamas', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1716', '4', 'José Félix Ribas', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1717', '4', 'José Rafael Revenga', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1718', '4', 'Libertador', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1719', '4', 'Mario Briceño Iragorry', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1720', '4', 'Ocumare de la Costa de Oro', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1721', '4', 'San Casimiro', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1722', '4', 'San Sebastián', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1723', '4', 'Santiago Mariño', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1724', '4', 'Santos Michelena', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1725', '4', 'Sucre', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1726', '4', 'Tovar', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1727', '4', 'Urdaneta', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1728', '4', 'Zamora', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1729', '5', 'Alberto Arvelo Torrealba', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1730', '5', 'Andrés Eloy Blanco', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1731', '5', 'Antonio José de Sucre', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1732', '5', 'Arismendi', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1733', '5', 'Barinas', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1734', '5', 'Bolívar', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1735', '5', 'Cruz Paredes', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1736', '5', 'Ezequiel Zamora', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1737', '5', 'Obispos', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1738', '5', 'Pedraza', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1739', '5', 'Rojas', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1740', '5', 'Sosa', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1741', '6', 'Caroní', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1742', '6', 'Cedeño', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1743', '6', 'El Callao', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1744', '6', 'Gran Sabana', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1745', '6', 'Heres', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1746', '6', 'Piar', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1747', '6', 'Angostura (Raúl Leoni)', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1748', '6', 'Roscio', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1749', '6', 'Sifontes', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1750', '6', 'Sucre', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1751', '6', 'Padre Pedro Chien', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1752', '7', 'Bejuma', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1753', '7', 'Carlos Arvelo', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1754', '7', 'Diego Ibarra', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1755', '7', 'Guacara', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1756', '7', 'Juan José Mora', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1757', '7', 'Libertador', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1758', '7', 'Los Guayos', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1759', '7', 'Miranda', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1760', '7', 'Montalbán', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1761', '7', 'Naguanagua', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1762', '7', 'Puerto Cabello', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1763', '7', 'San Diego', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1764', '7', 'San Joaquín', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1765', '7', 'Valencia', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1766', '8', 'Anzoátegui', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1767', '8', 'Tinaquillo', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1768', '8', 'Girardot', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1769', '8', 'Lima Blanco', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1770', '8', 'Pao de San Juan Bautista', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1771', '8', 'Ricaurte', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1772', '8', 'Rómulo Gallegos', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1773', '8', 'San Carlos', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1774', '8', 'Tinaco', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1775', '9', 'Antonio Díaz', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1776', '9', 'Casacoima', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1777', '9', 'Pedernales', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1778', '9', 'Tucupita', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1779', '10', 'Acosta', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1780', '10', 'Bolívar', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1781', '10', 'Buchivacoa', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1782', '10', 'Cacique Manaure', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1783', '10', 'Carirubana', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1784', '10', 'Colina', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1785', '10', 'Dabajuro', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1786', '10', 'Democracia', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1787', '10', 'Falcón', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1788', '10', 'Federación', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1789', '10', 'Jacura', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1790', '10', 'José Laurencio Silva', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1791', '10', 'Los Taques', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1792', '10', 'Mauroa', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1793', '10', 'Miranda', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1794', '10', 'Monseñor Iturriza', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1795', '10', 'Palmasola', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1796', '10', 'Petit', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1797', '10', 'Píritu', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1798', '10', 'San Francisco', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1799', '10', 'Sucre', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1800', '10', 'Tocópero', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1801', '10', 'Unión', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1802', '10', 'Urumaco', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1803', '10', 'Zamora', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1804', '11', 'Camaguán', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1805', '11', 'Chaguaramas', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1806', '11', 'El Socorro', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1807', '11', 'José Félix Ribas', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1808', '11', 'José Tadeo Monagas', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1809', '11', 'Juan Germán Roscio', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1810', '11', 'Julián Mellado', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1811', '11', 'Las Mercedes', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1812', '11', 'Leonardo Infante', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1813', '11', 'Pedro Zaraza', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1814', '11', 'Ortíz', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1815', '11', 'San Gerónimo de Guayabal', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1816', '11', 'San José de Guaribe', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1817', '11', 'Santa María de Ipire', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1818', '11', 'Sebastián Francisco de Miranda', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1819', '12', 'Andrés Eloy Blanco', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1820', '12', 'Crespo', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1821', '12', 'Iribarren', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1822', '12', 'Jiménez', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1823', '12', 'Morán', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1824', '12', 'Palavecino', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1825', '12', 'Simón Planas', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1826', '12', 'Torres', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1827', '12', 'Urdaneta', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1828', '13', 'Alberto Adriani', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1829', '13', 'Andrés Bello', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1830', '13', 'Antonio Pinto Salinas', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1831', '13', 'Aricagua', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1832', '13', 'Arzobispo Chacón', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1833', '13', 'Campo Elías', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1834', '13', 'Caracciolo Parra Olmedo', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1835', '13', 'Cardenal Quintero', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1836', '13', 'Guaraque', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1837', '13', 'Julio César Salas', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1838', '13', 'Justo Briceño', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1839', '13', 'Libertador', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1840', '13', 'Miranda', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1841', '13', 'Obispo Ramos de Lora', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1842', '13', 'Padre Noguera', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1843', '13', 'Pueblo Llano', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1844', '13', 'Rangel', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1845', '13', 'Rivas Dávila', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1846', '13', 'Santos Marquina', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1847', '13', 'Sucre', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1848', '13', 'Tovar', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1849', '13', 'Tulio Febres Cordero', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1850', '13', 'Zea', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1851', '14', 'Acevedo', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1852', '14', 'Andrés Bello', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1853', '14', 'Baruta', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1854', '14', 'Brión', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1855', '14', 'Buroz', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1856', '14', 'Carrizal', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1857', '14', 'Chacao', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1858', '14', 'Cristóbal Rojas', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1859', '14', 'El Hatillo', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1860', '14', 'Guaicaipuro', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1861', '14', 'Independencia', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1862', '14', 'Lander', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1863', '14', 'Los Salias', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1864', '14', 'Páez', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1865', '14', 'Paz Castillo', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1866', '14', 'Pedro Gual', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1867', '14', 'Plaza', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1868', '14', 'Simón Bolívar', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1869', '14', 'Sucre', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1870', '14', 'Urdaneta', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1871', '14', 'Zamora', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1872', '15', 'Acosta', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1873', '15', 'Aguasay', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1874', '15', 'Bolívar', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1875', '15', 'Caripe', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1876', '15', 'Cedeño', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1877', '15', 'Ezequiel Zamora', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1878', '15', 'Libertador', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1879', '15', 'Maturín', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1880', '15', 'Piar', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1881', '15', 'Punceres', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1882', '15', 'Santa Bárbara', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1883', '15', 'Sotillo', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1884', '15', 'Uracoa', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1885', '16', 'Antolin del Campo', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1886', '16', 'Arismendi', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1887', '16', 'García', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1888', '16', 'Gómez', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1889', '16', 'Maneiro', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1890', '16', 'Marcano', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1891', '16', 'Mariño', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1892', '16', 'Península de Macanao', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1893', '16', 'Tubores', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1894', '16', 'Villalba', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1895', '16', 'Díaz', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1896', '17', 'Agua Blanca', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1897', '17', 'Araure', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1898', '17', 'Esteller', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1899', '17', 'Guanare', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1900', '17', 'Guanarito', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1901', '17', 'Monseñor José Vicente de Unda', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1902', '17', 'Ospino', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1903', '17', 'Páez', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1904', '17', 'Papelón', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1905', '17', 'San Genaro de Boconoíto', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1906', '17', 'San Rafael de Onoto', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1907', '17', 'Santa Rosalía', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1908', '17', 'Sucre', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1909', '17', 'Turén', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1910', '18', 'Andrés Eloy Blanco', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1911', '18', 'Andrés Mata', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1912', '18', 'Arismendi', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1913', '18', 'Benítez', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1914', '18', 'Bermúdez', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1915', '18', 'Bolívar', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1916', '18', 'Cajigal', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1917', '18', 'Cruz Salmerón Acosta', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1918', '18', 'Libertador', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1919', '18', 'Mariño', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1920', '18', 'Mejía', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1921', '18', 'Montes', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1922', '18', 'Ribero', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1923', '18', 'Sucre', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1924', '18', 'Valdéz', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1925', '19', 'Andrés Bello', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1926', '19', 'Antonio Rómulo Costa', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1927', '19', 'Ayacucho', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1928', '19', 'Bolívar', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1929', '19', 'Cárdenas', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1930', '19', 'Córdoba', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1931', '19', 'Fernández Feo', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1932', '19', 'Francisco de Miranda', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1933', '19', 'García de Hevia', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1934', '19', 'Guásimos', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1935', '19', 'Independencia', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1936', '19', 'Jáuregui', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1937', '19', 'José María Vargas', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1938', '19', 'Junín', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1939', '19', 'Libertad', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1940', '19', 'Libertador', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1941', '19', 'Lobatera', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1942', '19', 'Michelena', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1943', '19', 'Panamericano', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1944', '19', 'Pedro María Ureña', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1945', '19', 'Rafael Urdaneta', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1946', '19', 'Samuel Darío Maldonado', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1947', '19', 'San Cristóbal', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1948', '19', 'Seboruco', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1949', '19', 'Simón Rodríguez', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1950', '19', 'Sucre', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1951', '19', 'Torbes', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1952', '19', 'Uribante', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1953', '19', 'San Judas Tadeo', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1954', '20', 'Andrés Bello', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1955', '20', 'Boconó', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1956', '20', 'Bolívar', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1957', '20', 'Candelaria', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1958', '20', 'Carache', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1959', '20', 'Escuque', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1960', '20', 'José Felipe Márquez Cañizalez', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1961', '20', 'Juan Vicente Campos Elías', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1962', '20', 'La Ceiba', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1963', '20', 'Miranda', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1964', '20', 'Monte Carmelo', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1965', '20', 'Motatán', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1966', '20', 'Pampán', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1967', '20', 'Pampanito', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1968', '20', 'Rafael Rangel', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1969', '20', 'San Rafael de Carvajal', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1970', '20', 'Sucre', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1971', '20', 'Trujillo', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1972', '20', 'Urdaneta', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1973', '20', 'Valera', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1974', '21', 'Vargas', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1975', '22', 'Arístides Bastidas', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1976', '22', 'Bolívar', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1977', '22', 'Bruzual', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1978', '22', 'Cocorote', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1979', '22', 'Independencia', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1980', '22', 'José Antonio Páez', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1981', '22', 'La Trinidad', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1982', '22', 'Manuel Monge', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1983', '22', 'Nirgua', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1984', '22', 'Peña', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1985', '22', 'San Felipe', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1986', '22', 'Sucre', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1987', '22', 'Urachiche', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1988', '22', 'José Joaquín Veroes', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1989', '23', 'Almirante Padilla', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1990', '23', 'Baralt', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1991', '23', 'Cabimas', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1992', '23', 'Catatumbo', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1993', '23', 'Colón', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1994', '23', 'Francisco Javier Pulgar', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1995', '23', 'Páez', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1996', '23', 'Jesús Enrique Losada', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1997', '23', 'Jesús María Semprún', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1998', '23', 'La Cañada de Urdaneta', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('1999', '23', 'Lagunillas', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('2000', '23', 'Machiques de Perijá', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('2001', '23', 'Mara', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('2002', '23', 'Maracaibo', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('2003', '23', 'Miranda', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('2004', '23', 'Rosario de Perijá', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('2005', '23', 'San Francisco', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('2006', '23', 'Santa Rita', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('2007', '23', 'Simón Bolívar', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('2008', '23', 'Sucre', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('2009', '23', 'Valmore Rodríguez', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('2010', '24', 'Libertador', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `municipios` VALUES ('2011', '1', 'Alto Orinoco', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2012', '1', 'Atabapo', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2013', '1', 'Atures', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2014', '1', 'Autana', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2015', '1', 'Manapiare', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2016', '1', 'Maroa', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2017', '1', 'Río Negro', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2018', '2', 'Anaco', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2019', '2', 'Aragua', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2020', '2', 'Manuel Ezequiel Bruzual', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2021', '2', 'Diego Bautista Urbaneja', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2022', '2', 'Fernando Peñalver', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2023', '2', 'Francisco Del Carmen Carvajal', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2024', '2', 'General Sir Arthur McGregor', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2025', '2', 'Guanta', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2026', '2', 'Independencia', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2027', '2', 'José Gregorio Monagas', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2028', '2', 'Juan Antonio Sotillo', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2029', '2', 'Juan Manuel Cajigal', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2030', '2', 'Libertad', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2031', '2', 'Francisco de Miranda', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2032', '2', 'Pedro María Freites', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2033', '2', 'Píritu', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2034', '2', 'San José de Guanipa', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2035', '2', 'San Juan de Capistrano', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2036', '2', 'Santa Ana', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2037', '2', 'Simón Bolívar', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2038', '2', 'Simón Rodríguez', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2039', '3', 'Achaguas', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2040', '3', 'Biruaca', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2041', '3', 'Muñóz', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2042', '3', 'Páez', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2043', '3', 'Pedro Camejo', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2044', '3', 'Rómulo Gallegos', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2045', '3', 'San Fernando', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2046', '4', 'Atanasio Girardot', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2047', '4', 'Bolívar', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2048', '4', 'Camatagua', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2049', '4', 'Francisco Linares Alcántara', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2050', '4', 'José Ángel Lamas', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2051', '4', 'José Félix Ribas', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2052', '4', 'José Rafael Revenga', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2053', '4', 'Libertador', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2054', '4', 'Mario Briceño Iragorry', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2055', '4', 'Ocumare de la Costa de Oro', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2056', '4', 'San Casimiro', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2057', '4', 'San Sebastián', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2058', '4', 'Santiago Mariño', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2059', '4', 'Santos Michelena', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2060', '4', 'Sucre', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2061', '4', 'Tovar', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2062', '4', 'Urdaneta', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2063', '4', 'Zamora', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2064', '5', 'Alberto Arvelo Torrealba', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2065', '5', 'Andrés Eloy Blanco', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2066', '5', 'Antonio José de Sucre', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2067', '5', 'Arismendi', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2068', '5', 'Barinas', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2069', '5', 'Bolívar', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2070', '5', 'Cruz Paredes', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2071', '5', 'Ezequiel Zamora', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2072', '5', 'Obispos', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2073', '5', 'Pedraza', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2074', '5', 'Rojas', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2075', '5', 'Sosa', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2076', '6', 'Caroní', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2077', '6', 'Cedeño', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2078', '6', 'El Callao', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2079', '6', 'Gran Sabana', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2080', '6', 'Heres', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2081', '6', 'Piar', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2082', '6', 'Angostura (Raúl Leoni)', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2083', '6', 'Roscio', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2084', '6', 'Sifontes', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2085', '6', 'Sucre', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2086', '6', 'Padre Pedro Chien', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2087', '7', 'Bejuma', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2088', '7', 'Carlos Arvelo', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2089', '7', 'Diego Ibarra', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2090', '7', 'Guacara', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2091', '7', 'Juan José Mora', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2092', '7', 'Libertador', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2093', '7', 'Los Guayos', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2094', '7', 'Miranda', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2095', '7', 'Montalbán', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2096', '7', 'Naguanagua', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2097', '7', 'Puerto Cabello', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2098', '7', 'San Diego', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2099', '7', 'San Joaquín', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2100', '7', 'Valencia', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2101', '8', 'Anzoátegui', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2102', '8', 'Tinaquillo', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2103', '8', 'Girardot', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2104', '8', 'Lima Blanco', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2105', '8', 'Pao de San Juan Bautista', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2106', '8', 'Ricaurte', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2107', '8', 'Rómulo Gallegos', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2108', '8', 'San Carlos', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2109', '8', 'Tinaco', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2110', '9', 'Antonio Díaz', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2111', '9', 'Casacoima', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2112', '9', 'Pedernales', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2113', '9', 'Tucupita', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2114', '10', 'Acosta', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2115', '10', 'Bolívar', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2116', '10', 'Buchivacoa', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2117', '10', 'Cacique Manaure', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2118', '10', 'Carirubana', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2119', '10', 'Colina', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2120', '10', 'Dabajuro', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2121', '10', 'Democracia', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2122', '10', 'Falcón', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2123', '10', 'Federación', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2124', '10', 'Jacura', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2125', '10', 'José Laurencio Silva', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2126', '10', 'Los Taques', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2127', '10', 'Mauroa', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2128', '10', 'Miranda', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2129', '10', 'Monseñor Iturriza', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2130', '10', 'Palmasola', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2131', '10', 'Petit', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2132', '10', 'Píritu', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2133', '10', 'San Francisco', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2134', '10', 'Sucre', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2135', '10', 'Tocópero', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2136', '10', 'Unión', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2137', '10', 'Urumaco', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2138', '10', 'Zamora', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2139', '11', 'Camaguán', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2140', '11', 'Chaguaramas', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2141', '11', 'El Socorro', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2142', '11', 'José Félix Ribas', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2143', '11', 'José Tadeo Monagas', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2144', '11', 'Juan Germán Roscio', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2145', '11', 'Julián Mellado', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2146', '11', 'Las Mercedes', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2147', '11', 'Leonardo Infante', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2148', '11', 'Pedro Zaraza', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2149', '11', 'Ortíz', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2150', '11', 'San Gerónimo de Guayabal', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2151', '11', 'San José de Guaribe', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2152', '11', 'Santa María de Ipire', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2153', '11', 'Sebastián Francisco de Miranda', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2154', '12', 'Andrés Eloy Blanco', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2155', '12', 'Crespo', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2156', '12', 'Iribarren', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2157', '12', 'Jiménez', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2158', '12', 'Morán', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2159', '12', 'Palavecino', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2160', '12', 'Simón Planas', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2161', '12', 'Torres', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2162', '12', 'Urdaneta', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2163', '13', 'Alberto Adriani', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2164', '13', 'Andrés Bello', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2165', '13', 'Antonio Pinto Salinas', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2166', '13', 'Aricagua', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2167', '13', 'Arzobispo Chacón', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2168', '13', 'Campo Elías', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2169', '13', 'Caracciolo Parra Olmedo', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2170', '13', 'Cardenal Quintero', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2171', '13', 'Guaraque', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2172', '13', 'Julio César Salas', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2173', '13', 'Justo Briceño', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2174', '13', 'Libertador', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2175', '13', 'Miranda', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2176', '13', 'Obispo Ramos de Lora', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2177', '13', 'Padre Noguera', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2178', '13', 'Pueblo Llano', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2179', '13', 'Rangel', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2180', '13', 'Rivas Dávila', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2181', '13', 'Santos Marquina', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2182', '13', 'Sucre', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2183', '13', 'Tovar', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2184', '13', 'Tulio Febres Cordero', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2185', '13', 'Zea', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2186', '14', 'Acevedo', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2187', '14', 'Andrés Bello', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2188', '14', 'Baruta', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2189', '14', 'Brión', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2190', '14', 'Buroz', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2191', '14', 'Carrizal', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2192', '14', 'Chacao', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2193', '14', 'Cristóbal Rojas', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2194', '14', 'El Hatillo', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2195', '14', 'Guaicaipuro', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2196', '14', 'Independencia', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2197', '14', 'Lander', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2198', '14', 'Los Salias', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2199', '14', 'Páez', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2200', '14', 'Paz Castillo', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2201', '14', 'Pedro Gual', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2202', '14', 'Plaza', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2203', '14', 'Simón Bolívar', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2204', '14', 'Sucre', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2205', '14', 'Urdaneta', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2206', '14', 'Zamora', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2207', '15', 'Acosta', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2208', '15', 'Aguasay', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2209', '15', 'Bolívar', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2210', '15', 'Caripe', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2211', '15', 'Cedeño', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2212', '15', 'Ezequiel Zamora', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2213', '15', 'Libertador', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2214', '15', 'Maturín', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2215', '15', 'Piar', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2216', '15', 'Punceres', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2217', '15', 'Santa Bárbara', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2218', '15', 'Sotillo', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2219', '15', 'Uracoa', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2220', '16', 'Antolin del Campo', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2221', '16', 'Arismendi', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2222', '16', 'García', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2223', '16', 'Gómez', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2224', '16', 'Maneiro', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2225', '16', 'Marcano', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2226', '16', 'Mariño', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2227', '16', 'Península de Macanao', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2228', '16', 'Tubores', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2229', '16', 'Villalba', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2230', '16', 'Díaz', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2231', '17', 'Agua Blanca', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2232', '17', 'Araure', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2233', '17', 'Esteller', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2234', '17', 'Guanare', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2235', '17', 'Guanarito', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2236', '17', 'Monseñor José Vicente de Unda', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2237', '17', 'Ospino', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2238', '17', 'Páez', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2239', '17', 'Papelón', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2240', '17', 'San Genaro de Boconoíto', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2241', '17', 'San Rafael de Onoto', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2242', '17', 'Santa Rosalía', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2243', '17', 'Sucre', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2244', '17', 'Turén', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2245', '18', 'Andrés Eloy Blanco', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2246', '18', 'Andrés Mata', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2247', '18', 'Arismendi', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2248', '18', 'Benítez', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2249', '18', 'Bermúdez', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2250', '18', 'Bolívar', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2251', '18', 'Cajigal', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2252', '18', 'Cruz Salmerón Acosta', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2253', '18', 'Libertador', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2254', '18', 'Mariño', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2255', '18', 'Mejía', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2256', '18', 'Montes', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2257', '18', 'Ribero', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2258', '18', 'Sucre', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2259', '18', 'Valdéz', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2260', '19', 'Andrés Bello', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2261', '19', 'Antonio Rómulo Costa', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2262', '19', 'Ayacucho', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2263', '19', 'Bolívar', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2264', '19', 'Cárdenas', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2265', '19', 'Córdoba', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2266', '19', 'Fernández Feo', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2267', '19', 'Francisco de Miranda', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2268', '19', 'García de Hevia', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2269', '19', 'Guásimos', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2270', '19', 'Independencia', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2271', '19', 'Jáuregui', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2272', '19', 'José María Vargas', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2273', '19', 'Junín', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2274', '19', 'Libertad', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2275', '19', 'Libertador', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2276', '19', 'Lobatera', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2277', '19', 'Michelena', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2278', '19', 'Panamericano', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2279', '19', 'Pedro María Ureña', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2280', '19', 'Rafael Urdaneta', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2281', '19', 'Samuel Darío Maldonado', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2282', '19', 'San Cristóbal', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2283', '19', 'Seboruco', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2284', '19', 'Simón Rodríguez', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2285', '19', 'Sucre', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2286', '19', 'Torbes', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2287', '19', 'Uribante', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2288', '19', 'San Judas Tadeo', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2289', '20', 'Andrés Bello', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2290', '20', 'Boconó', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2291', '20', 'Bolívar', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2292', '20', 'Candelaria', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2293', '20', 'Carache', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2294', '20', 'Escuque', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2295', '20', 'José Felipe Márquez Cañizalez', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2296', '20', 'Juan Vicente Campos Elías', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2297', '20', 'La Ceiba', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2298', '20', 'Miranda', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2299', '20', 'Monte Carmelo', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2300', '20', 'Motatán', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2301', '20', 'Pampán', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2302', '20', 'Pampanito', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2303', '20', 'Rafael Rangel', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2304', '20', 'San Rafael de Carvajal', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2305', '20', 'Sucre', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2306', '20', 'Trujillo', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2307', '20', 'Urdaneta', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2308', '20', 'Valera', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2309', '21', 'Vargas', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2310', '22', 'Arístides Bastidas', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2311', '22', 'Bolívar', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2312', '22', 'Bruzual', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2313', '22', 'Cocorote', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2314', '22', 'Independencia', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2315', '22', 'José Antonio Páez', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2316', '22', 'La Trinidad', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2317', '22', 'Manuel Monge', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2318', '22', 'Nirgua', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2319', '22', 'Peña', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2320', '22', 'San Felipe', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2321', '22', 'Sucre', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2322', '22', 'Urachiche', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2323', '22', 'José Joaquín Veroes', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2324', '23', 'Almirante Padilla', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2325', '23', 'Baralt', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2326', '23', 'Cabimas', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2327', '23', 'Catatumbo', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2328', '23', 'Colón', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2329', '23', 'Francisco Javier Pulgar', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2330', '23', 'Páez', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2331', '23', 'Jesús Enrique Losada', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2332', '23', 'Jesús María Semprún', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2333', '23', 'La Cañada de Urdaneta', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2334', '23', 'Lagunillas', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2335', '23', 'Machiques de Perijá', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2336', '23', 'Mara', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2337', '23', 'Maracaibo', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2338', '23', 'Miranda', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2339', '23', 'Rosario de Perijá', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2340', '23', 'San Francisco', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2341', '23', 'Santa Rita', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2342', '23', 'Simón Bolívar', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2343', '23', 'Sucre', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2344', '23', 'Valmore Rodríguez', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2345', '24', 'Libertador', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `municipios` VALUES ('2346', '1', 'Alto Orinoco', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2347', '1', 'Atabapo', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2348', '1', 'Atures', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2349', '1', 'Autana', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2350', '1', 'Manapiare', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2351', '1', 'Maroa', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2352', '1', 'Río Negro', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2353', '2', 'Anaco', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2354', '2', 'Aragua', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2355', '2', 'Manuel Ezequiel Bruzual', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2356', '2', 'Diego Bautista Urbaneja', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2357', '2', 'Fernando Peñalver', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2358', '2', 'Francisco Del Carmen Carvajal', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2359', '2', 'General Sir Arthur McGregor', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2360', '2', 'Guanta', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2361', '2', 'Independencia', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2362', '2', 'José Gregorio Monagas', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2363', '2', 'Juan Antonio Sotillo', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2364', '2', 'Juan Manuel Cajigal', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2365', '2', 'Libertad', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2366', '2', 'Francisco de Miranda', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2367', '2', 'Pedro María Freites', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2368', '2', 'Píritu', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2369', '2', 'San José de Guanipa', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2370', '2', 'San Juan de Capistrano', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2371', '2', 'Santa Ana', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2372', '2', 'Simón Bolívar', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2373', '2', 'Simón Rodríguez', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2374', '3', 'Achaguas', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2375', '3', 'Biruaca', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2376', '3', 'Muñóz', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2377', '3', 'Páez', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2378', '3', 'Pedro Camejo', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2379', '3', 'Rómulo Gallegos', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2380', '3', 'San Fernando', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2381', '4', 'Atanasio Girardot', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2382', '4', 'Bolívar', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2383', '4', 'Camatagua', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2384', '4', 'Francisco Linares Alcántara', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2385', '4', 'José Ángel Lamas', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2386', '4', 'José Félix Ribas', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2387', '4', 'José Rafael Revenga', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2388', '4', 'Libertador', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2389', '4', 'Mario Briceño Iragorry', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2390', '4', 'Ocumare de la Costa de Oro', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2391', '4', 'San Casimiro', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2392', '4', 'San Sebastián', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2393', '4', 'Santiago Mariño', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2394', '4', 'Santos Michelena', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2395', '4', 'Sucre', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2396', '4', 'Tovar', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2397', '4', 'Urdaneta', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2398', '4', 'Zamora', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2399', '5', 'Alberto Arvelo Torrealba', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2400', '5', 'Andrés Eloy Blanco', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2401', '5', 'Antonio José de Sucre', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2402', '5', 'Arismendi', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2403', '5', 'Barinas', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2404', '5', 'Bolívar', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2405', '5', 'Cruz Paredes', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2406', '5', 'Ezequiel Zamora', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2407', '5', 'Obispos', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2408', '5', 'Pedraza', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2409', '5', 'Rojas', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2410', '5', 'Sosa', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2411', '6', 'Caroní', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2412', '6', 'Cedeño', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2413', '6', 'El Callao', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2414', '6', 'Gran Sabana', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2415', '6', 'Heres', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2416', '6', 'Piar', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2417', '6', 'Angostura (Raúl Leoni)', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2418', '6', 'Roscio', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2419', '6', 'Sifontes', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2420', '6', 'Sucre', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2421', '6', 'Padre Pedro Chien', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2422', '7', 'Bejuma', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2423', '7', 'Carlos Arvelo', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2424', '7', 'Diego Ibarra', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2425', '7', 'Guacara', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2426', '7', 'Juan José Mora', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2427', '7', 'Libertador', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2428', '7', 'Los Guayos', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2429', '7', 'Miranda', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2430', '7', 'Montalbán', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2431', '7', 'Naguanagua', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2432', '7', 'Puerto Cabello', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2433', '7', 'San Diego', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2434', '7', 'San Joaquín', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2435', '7', 'Valencia', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2436', '8', 'Anzoátegui', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2437', '8', 'Tinaquillo', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2438', '8', 'Girardot', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2439', '8', 'Lima Blanco', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2440', '8', 'Pao de San Juan Bautista', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2441', '8', 'Ricaurte', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2442', '8', 'Rómulo Gallegos', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2443', '8', 'San Carlos', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2444', '8', 'Tinaco', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2445', '9', 'Antonio Díaz', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2446', '9', 'Casacoima', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2447', '9', 'Pedernales', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2448', '9', 'Tucupita', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2449', '10', 'Acosta', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2450', '10', 'Bolívar', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2451', '10', 'Buchivacoa', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2452', '10', 'Cacique Manaure', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2453', '10', 'Carirubana', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2454', '10', 'Colina', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2455', '10', 'Dabajuro', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2456', '10', 'Democracia', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2457', '10', 'Falcón', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2458', '10', 'Federación', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2459', '10', 'Jacura', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2460', '10', 'José Laurencio Silva', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2461', '10', 'Los Taques', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2462', '10', 'Mauroa', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2463', '10', 'Miranda', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2464', '10', 'Monseñor Iturriza', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2465', '10', 'Palmasola', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2466', '10', 'Petit', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `municipios` VALUES ('2467', '10', 'Píritu', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2468', '10', 'San Francisco', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2469', '10', 'Sucre', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2470', '10', 'Tocópero', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2471', '10', 'Unión', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2472', '10', 'Urumaco', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2473', '10', 'Zamora', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2474', '11', 'Camaguán', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2475', '11', 'Chaguaramas', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2476', '11', 'El Socorro', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2477', '11', 'José Félix Ribas', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2478', '11', 'José Tadeo Monagas', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2479', '11', 'Juan Germán Roscio', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2480', '11', 'Julián Mellado', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2481', '11', 'Las Mercedes', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2482', '11', 'Leonardo Infante', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2483', '11', 'Pedro Zaraza', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2484', '11', 'Ortíz', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2485', '11', 'San Gerónimo de Guayabal', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2486', '11', 'San José de Guaribe', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2487', '11', 'Santa María de Ipire', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2488', '11', 'Sebastián Francisco de Miranda', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2489', '12', 'Andrés Eloy Blanco', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2490', '12', 'Crespo', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2491', '12', 'Iribarren', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2492', '12', 'Jiménez', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2493', '12', 'Morán', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2494', '12', 'Palavecino', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2495', '12', 'Simón Planas', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2496', '12', 'Torres', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2497', '12', 'Urdaneta', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2498', '13', 'Alberto Adriani', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2499', '13', 'Andrés Bello', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2500', '13', 'Antonio Pinto Salinas', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2501', '13', 'Aricagua', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2502', '13', 'Arzobispo Chacón', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2503', '13', 'Campo Elías', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2504', '13', 'Caracciolo Parra Olmedo', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2505', '13', 'Cardenal Quintero', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2506', '13', 'Guaraque', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2507', '13', 'Julio César Salas', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2508', '13', 'Justo Briceño', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2509', '13', 'Libertador', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2510', '13', 'Miranda', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2511', '13', 'Obispo Ramos de Lora', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2512', '13', 'Padre Noguera', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2513', '13', 'Pueblo Llano', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2514', '13', 'Rangel', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2515', '13', 'Rivas Dávila', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2516', '13', 'Santos Marquina', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2517', '13', 'Sucre', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2518', '13', 'Tovar', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2519', '13', 'Tulio Febres Cordero', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2520', '13', 'Zea', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2521', '14', 'Acevedo', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2522', '14', 'Andrés Bello', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2523', '14', 'Baruta', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2524', '14', 'Brión', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2525', '14', 'Buroz', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2526', '14', 'Carrizal', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2527', '14', 'Chacao', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2528', '14', 'Cristóbal Rojas', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2529', '14', 'El Hatillo', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2530', '14', 'Guaicaipuro', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2531', '14', 'Independencia', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2532', '14', 'Lander', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2533', '14', 'Los Salias', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2534', '14', 'Páez', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2535', '14', 'Paz Castillo', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2536', '14', 'Pedro Gual', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2537', '14', 'Plaza', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2538', '14', 'Simón Bolívar', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2539', '14', 'Sucre', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2540', '14', 'Urdaneta', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2541', '14', 'Zamora', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2542', '15', 'Acosta', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2543', '15', 'Aguasay', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2544', '15', 'Bolívar', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2545', '15', 'Caripe', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2546', '15', 'Cedeño', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2547', '15', 'Ezequiel Zamora', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2548', '15', 'Libertador', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2549', '15', 'Maturín', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2550', '15', 'Piar', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2551', '15', 'Punceres', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2552', '15', 'Santa Bárbara', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2553', '15', 'Sotillo', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2554', '15', 'Uracoa', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2555', '16', 'Antolin del Campo', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2556', '16', 'Arismendi', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2557', '16', 'García', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2558', '16', 'Gómez', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2559', '16', 'Maneiro', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2560', '16', 'Marcano', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2561', '16', 'Mariño', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2562', '16', 'Península de Macanao', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2563', '16', 'Tubores', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2564', '16', 'Villalba', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2565', '16', 'Díaz', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2566', '17', 'Agua Blanca', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2567', '17', 'Araure', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2568', '17', 'Esteller', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2569', '17', 'Guanare', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2570', '17', 'Guanarito', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2571', '17', 'Monseñor José Vicente de Unda', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2572', '17', 'Ospino', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2573', '17', 'Páez', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2574', '17', 'Papelón', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2575', '17', 'San Genaro de Boconoíto', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2576', '17', 'San Rafael de Onoto', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2577', '17', 'Santa Rosalía', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2578', '17', 'Sucre', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2579', '17', 'Turén', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2580', '18', 'Andrés Eloy Blanco', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2581', '18', 'Andrés Mata', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2582', '18', 'Arismendi', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2583', '18', 'Benítez', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2584', '18', 'Bermúdez', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2585', '18', 'Bolívar', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2586', '18', 'Cajigal', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2587', '18', 'Cruz Salmerón Acosta', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2588', '18', 'Libertador', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2589', '18', 'Mariño', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2590', '18', 'Mejía', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2591', '18', 'Montes', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2592', '18', 'Ribero', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2593', '18', 'Sucre', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2594', '18', 'Valdéz', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2595', '19', 'Andrés Bello', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2596', '19', 'Antonio Rómulo Costa', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2597', '19', 'Ayacucho', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2598', '19', 'Bolívar', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2599', '19', 'Cárdenas', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2600', '19', 'Córdoba', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2601', '19', 'Fernández Feo', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2602', '19', 'Francisco de Miranda', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2603', '19', 'García de Hevia', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2604', '19', 'Guásimos', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2605', '19', 'Independencia', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2606', '19', 'Jáuregui', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2607', '19', 'José María Vargas', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2608', '19', 'Junín', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2609', '19', 'Libertad', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2610', '19', 'Libertador', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2611', '19', 'Lobatera', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2612', '19', 'Michelena', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2613', '19', 'Panamericano', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2614', '19', 'Pedro María Ureña', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2615', '19', 'Rafael Urdaneta', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2616', '19', 'Samuel Darío Maldonado', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2617', '19', 'San Cristóbal', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2618', '19', 'Seboruco', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2619', '19', 'Simón Rodríguez', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2620', '19', 'Sucre', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2621', '19', 'Torbes', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2622', '19', 'Uribante', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2623', '19', 'San Judas Tadeo', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2624', '20', 'Andrés Bello', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2625', '20', 'Boconó', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2626', '20', 'Bolívar', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2627', '20', 'Candelaria', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2628', '20', 'Carache', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2629', '20', 'Escuque', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2630', '20', 'José Felipe Márquez Cañizalez', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2631', '20', 'Juan Vicente Campos Elías', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2632', '20', 'La Ceiba', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2633', '20', 'Miranda', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2634', '20', 'Monte Carmelo', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2635', '20', 'Motatán', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2636', '20', 'Pampán', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2637', '20', 'Pampanito', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2638', '20', 'Rafael Rangel', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2639', '20', 'San Rafael de Carvajal', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2640', '20', 'Sucre', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2641', '20', 'Trujillo', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2642', '20', 'Urdaneta', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2643', '20', 'Valera', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2644', '21', 'Vargas', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2645', '22', 'Arístides Bastidas', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2646', '22', 'Bolívar', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2647', '22', 'Bruzual', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2648', '22', 'Cocorote', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2649', '22', 'Independencia', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2650', '22', 'José Antonio Páez', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2651', '22', 'La Trinidad', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2652', '22', 'Manuel Monge', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2653', '22', 'Nirgua', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2654', '22', 'Peña', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2655', '22', 'San Felipe', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2656', '22', 'Sucre', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2657', '22', 'Urachiche', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2658', '22', 'José Joaquín Veroes', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2659', '23', 'Almirante Padilla', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2660', '23', 'Baralt', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2661', '23', 'Cabimas', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2662', '23', 'Catatumbo', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2663', '23', 'Colón', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2664', '23', 'Francisco Javier Pulgar', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2665', '23', 'Páez', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2666', '23', 'Jesús Enrique Losada', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2667', '23', 'Jesús María Semprún', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2668', '23', 'La Cañada de Urdaneta', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2669', '23', 'Lagunillas', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2670', '23', 'Machiques de Perijá', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2671', '23', 'Mara', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2672', '23', 'Maracaibo', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2673', '23', 'Miranda', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2674', '23', 'Rosario de Perijá', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2675', '23', 'San Francisco', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2676', '23', 'Santa Rita', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2677', '23', 'Simón Bolívar', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2678', '23', 'Sucre', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2679', '23', 'Valmore Rodríguez', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);
INSERT INTO `municipios` VALUES ('2680', '24', 'Libertador', '2020-02-29 21:34:51', '2020-02-29 21:34:51', null);

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ord_prod_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_prod_id` bigint(20) unsigned NOT NULL,
  `ord_address` bigint(20) unsigned NOT NULL,
  `ord_price_bs` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ord_price_usd` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ord_description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ord_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ord_extras` bigint(20) unsigned DEFAULT NULL,
  `ord_rate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ord_dm_id` bigint(20) unsigned DEFAULT NULL,
  `ord_dm_rate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_ord_prod_id_foreign` (`ord_prod_id`),
  KEY `orders_ord_address_foreign` (`ord_address`),
  KEY `orders_ord_extras_foreign` (`ord_extras`),
  KEY `orders_ord_dm_id_foreign` (`ord_dm_id`),
  CONSTRAINT `orders_ord_address_foreign` FOREIGN KEY (`ord_address`) REFERENCES `clients_address` (`id`),
  CONSTRAINT `orders_ord_dm_id_foreign` FOREIGN KEY (`ord_dm_id`) REFERENCES `delivery_man` (`id`),
  CONSTRAINT `orders_ord_extras_foreign` FOREIGN KEY (`ord_extras`) REFERENCES `prod_extras` (`id`),
  CONSTRAINT `orders_ord_prod_id_foreign` FOREIGN KEY (`ord_prod_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of orders
-- ----------------------------

-- ----------------------------
-- Table structure for partners
-- ----------------------------
DROP TABLE IF EXISTS `partners`;
CREATE TABLE `partners` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `p_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_user` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_rif` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_phone_1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_phone_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_rs_id` bigint(20) unsigned DEFAULT NULL,
  `p_st_id` bigint(20) unsigned DEFAULT NULL,
  `p_mun_id` bigint(20) unsigned DEFAULT NULL,
  `p_adrress` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_cat_id` bigint(20) unsigned DEFAULT NULL,
  `p_intents` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_blocked` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_pass_exp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_open_time` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_close_time` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_rate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_shipping` bigint(20) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `partners_p_user_unique` (`p_user`),
  UNIQUE KEY `partners_p_email_unique` (`p_email`),
  KEY `partners_p_rs_id_foreign` (`p_rs_id`),
  KEY `partners_p_st_id_foreign` (`p_st_id`),
  KEY `partners_p_mun_id_foreign` (`p_mun_id`),
  KEY `partners_p_cat_id_foreign` (`p_cat_id`),
  CONSTRAINT `partners_p_cat_id_foreign` FOREIGN KEY (`p_cat_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `partners_p_mun_id_foreign` FOREIGN KEY (`p_mun_id`) REFERENCES `municipios` (`id`),
  CONSTRAINT `partners_p_rs_id_foreign` FOREIGN KEY (`p_rs_id`) REFERENCES `roles_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of partners
-- ----------------------------
INSERT INTO `partners` VALUES ('1', 'Dr. Keagan Bernier', 'Green', 'ut', 'kara94@yahoo.com', '8', '(463) 381-0854 x91940', '919-442-4301 x1254', '$2y$10$yo3H6eJ9nXsA.1xgEzZXFuiQdHUyv3f5ipxrc1/b3tGMlgLBTinKa', null, '16', '1', '7332 Hermann Stravenue\nEllisberg, FL 95140-8695', '2', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('2', 'Evans Lesch', 'Hamill', 'dolor', 'wolf.bert@hotmail.com', '8', '983-464-1915 x983', '818.273.9108 x6049', '$2y$10$xcE6QM3YNhWmP0gamvkczOncdWiYtmVNkj9jCEuu35i0s11SKF1Me', null, '14', '2', '9177 Borer Locks Apt. 572\nFraneckistad, MO 08637', '3', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('3', 'Dr. Alda Reinger DDS', 'Kuphal', 'quo', 'ynienow@hotmail.com', '8', '(295) 502-3097', '542.520.5052 x5285', '$2y$10$6.cxRNf5Goh.b2VLDxjkR.c80zLYCnJGdtc8E4OJSD83CSO3L.BAq', null, '6', '1', '7181 Hyatt Bypass Apt. 677\nAlbertofurt, ME 31017', '1', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('4', 'Marty Stehr II', 'Harvey', 'et', 'ptorphy@hotmail.com', '5', '+1.421.471.7495', '1-802-527-8207', '$2y$10$8TANizyA7I0jebyvrJfoHO1IopAGxlEILNHLj/aH41fDUYWFjynHm', null, '15', '2', '8216 Rohan Street\nHowellfort, ME 22996-7221', '2', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('5', 'Porter Von', 'Huel', 'aspernatur', 'jcole@corwin.com', '5', '(656) 963-7421', '1-576-770-7458 x5487', '$2y$10$x/6tqXat5Hc8Cq2iK5TcfeMvvqTNaFIYwBNHqEuGpznbQVSQIhLri', null, '10', '2', '62818 Jane Mountains\nWest Martin, CO 80464-7858', '2', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('6', 'Damion Christiansen', 'Heidenreich', 'ratione', 'wuckert.green@yahoo.com', '8', '+1-592-807-0334', '+1-679-270-8478', '$2y$10$Mvf.kOxWZcXj3uAlCxsh5ua0Gv1MO66WyESCM6CohQNI0aUeYKCGW', null, '16', '1', '658 Waters Rest\nDenesikmouth, TN 78096', '2', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('7', 'Vada Anderson', 'Gutkowski', 'voluptates', 'raina.mann@gmail.com', '3', '1-554-877-6713 x205', '1-723-228-2724', '$2y$10$V44NMpLfXNHc03Aroh7ZOObR5bIdT3/NzdhRt7PXhXfhgnAOcypcS', null, '15', '1', '32138 Kaylie Walks Apt. 087\nWilliemouth, IA 19954', '2', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('8', 'Myra Walker', 'Pagac', 'qui', 'quitzon.maximus@gmail.com', '7', '457-763-6426 x24773', '602.656.2665 x45816', '$2y$10$DwAHjT/Zp.4wOCktQUL/zupwVBG1cFqalgu5yQXK9ad07bOR3T6Jq', null, '24', '2', '1902 Lolita Track Suite 044\nLake Darienchester, MS 86302', '2', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('9', 'Bernhard Cummerata', 'Rau', 'aliquid', 'vschinner@hotmail.com', '9', '+1-829-769-0528', '1-819-570-9545', '$2y$10$74hy0NfXZpsX7K4ssGfC2ectAIQF2oDuIbVglwqQNKhXyyGHP.K8G', null, '7', '1', '26611 Dooley Fort\nBeahanfort, SC 78467-1241', '3', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('10', 'Retha Brown', 'Reilly', 'commodi', 'ignatius.frami@yahoo.com', '9', '+1-353-224-2935', '1-545-482-0030 x14027', '$2y$10$fU/0rqlkYEJiwjCZ.g56heTmbMZJJUOT9f80/rWibcFKEBg25FkJa', null, '4', '2', '2809 Bradtke Ports\nLake Alysonville, ID 06486-4397', '1', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('11', 'Colt Gibson', 'Gleichner', 'aut', 'wpowlowski@hodkiewicz.biz', '3', '982-496-1105 x775', '376-472-1696', '$2y$10$XRccdyVDQUtPP0e11zrVmO./SpH2NSyEuIqfS8PQPyzGF3hF2RBQm', null, '20', '1', '27212 Dandre Rapids\nCicerostad, ND 73137-5906', '1', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('12', 'Immanuel Keeling', 'Stamm', 'exercitationem', 'xander01@bahringer.net', '9', '1-373-477-8225 x72238', '1-826-609-5550 x786', '$2y$10$o2wKBcAsJscWRpeAsplq6e.fqeCwtXQ2ViynB41VFnqN3362RIRv6', null, '18', '1', '2189 Ashton Field\nGarnethaven, WA 14039', '1', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('13', 'Leta Hansen', 'Mertz', 'quia', 'yost.omari@krajcik.net', '6', '(778) 934-8003', '+14355634697', '$2y$10$dMWT7hSQALFfIIHKDLyUrOUNvvpE7TEM.HYQCCKNBTbh16psB7y9i', null, '15', '2', '92655 Hoppe Springs Suite 542\nEast Dedrick, MA 75458', '3', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('14', 'Mr. Lorenza Hirthe', 'Bernier', 'voluptatibus', 'xbeatty@gleason.com', '8', '1-307-734-1000 x4734', '909-532-2555 x369', '$2y$10$HVgglTYMZKgHA10cWZjNpuqC2HVYEdbCc2warLx5Y//Oidl420wp2', null, '15', '1', '1923 Dare Stravenue\nSouth Alanisburgh, DE 56855-0342', '1', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('15', 'Giles Barrows', 'Walsh', 'beatae', 'dalton77@gmail.com', '8', '1-678-903-8095 x6691', '785-589-5990', '$2y$10$E59ybpYqwAPD3L/I4JEf1.ZD84mQzGSBbRMHI9aXsLZQ8qXD7BJG.', null, '7', '1', '71830 Loma Union Apt. 471\nLittelburgh, KS 75602', '3', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('16', 'Mr. Guy Russel', 'Emmerich', 'officiis', 'icorwin@hotmail.com', '2', '(891) 577-6229 x1974', '+1-442-236-7031', '$2y$10$M3Kl7G.QS6u7Ius7Z5v4/.w7pcihdnPRiSwsndx5MReXFCrTIOPlS', null, '23', '2', '4009 Lauren Drive\nHicklemouth, IN 61180', '3', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('17', 'Narciso Daniel', 'Leannon', 'earum', 'isaias59@bogisich.com', '4', '1-757-723-4149', '676.474.9797', '$2y$10$g1Xz0wPDqDK7rEhjlLKVvOA.dmXoqn6ectQDOwQA./3p6jLnD7OIC', null, '15', '1', '7313 Catherine Skyway Apt. 030\nDurwardbury, AZ 41783-2346', '3', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('18', 'Adolph Labadie Jr.', 'Spinka', 'sunt', 'jovan.ernser@yahoo.com', '6', '326-447-7990', '1-892-527-5068', '$2y$10$XkQ7fYKVBaYTcJHJ8z9Zruq/RmfNtEkLcicAWUD6uqfjU4NyISNd2', null, '15', '2', '363 Glen Stream\nMedhurstshire, NY 61006', '3', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('19', 'Eden Monahan', 'Hammes', 'eaque', 'turcotte.ryley@gmail.com', '6', '1-495-478-1241 x371', '(737) 679-0333', '$2y$10$hYbqSB0OrqdqX8JvJmBZYeZuCIg3gDFVlex.kDhmyHj91LeqSJIHW', null, '20', '1', '7634 Kara Mount Apt. 884\nPort Austyn, KY 34154-6665', '2', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('20', 'Eleanora Hegmann IV', 'Erdman', 'harum', 'rowe.mathias@adams.com', '8', '+1.309.548.7965', '780.722.5280', '$2y$10$RxflR8JDOjoAjcdBun7SCOIbpxIlUDGbr9rogiuOrxsXtfc.g.AYW', null, '10', '2', '17141 Alexandre Point\nRuntebury, OR 89700-7130', '2', null, null, null, null, null, null, null, null, null, null, null, null);

-- ----------------------------
-- Table structure for password_resets
-- ----------------------------
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of password_resets
-- ----------------------------

-- ----------------------------
-- Table structure for products
-- ----------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `prod_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prod_partner_id` bigint(20) unsigned DEFAULT NULL,
  `prod_price_bs` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prod_price_usd` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prod_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `prod_category` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `products_prod_partner_id_foreign` (`prod_partner_id`),
  CONSTRAINT `products_prod_partner_id_foreign` FOREIGN KEY (`prod_partner_id`) REFERENCES `partners` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of products
-- ----------------------------
INSERT INTO `products` VALUES ('1', 'Golda Luettgen', '9', '6600', '5306', 'itaque', null, null, null, '1');
INSERT INTO `products` VALUES ('2', 'Ms. Kayli Batz', '8', '5056', '7190', 'rerum', null, null, null, '1');
INSERT INTO `products` VALUES ('3', 'Roslyn Berge', '7', '6557', '1722', 'et', null, null, null, '1');
INSERT INTO `products` VALUES ('4', 'Mrs. Jazmin Hegmann PhD', '7', '5584', '6699', 'esse', null, null, null, '1');
INSERT INTO `products` VALUES ('5', 'Emily Gulgowski', '4', '1852', '6172', 'facere', null, null, null, '1');
INSERT INTO `products` VALUES ('6', 'Prof. Clifford Stroman', '2', '8475', '1416', 'blanditiis', null, null, null, '1');
INSERT INTO `products` VALUES ('7', 'Mrs. Leanne Dach', '1', '1976', '7507', 'quis', null, null, null, '1');
INSERT INTO `products` VALUES ('8', 'Renee Stroman', '1', '5421', '204', 'fugiat', null, null, null, '1');
INSERT INTO `products` VALUES ('9', 'Trinity Lebsack', '9', '4117', '3519', 'porro', null, null, null, '1');
INSERT INTO `products` VALUES ('10', 'Madilyn Weissnat', '6', '5103', '6784', 'non', null, null, null, '1');
INSERT INTO `products` VALUES ('11', 'Dock Murazik', '9', '4090', '2535', 'in', null, null, null, '1');
INSERT INTO `products` VALUES ('12', 'Prof. Pierce Morissette MD', '3', '1448', '5915', 'neque', null, null, null, '1');
INSERT INTO `products` VALUES ('13', 'Amiya Hackett Jr.', '5', '7169', '1365', 'ut', null, null, null, '1');
INSERT INTO `products` VALUES ('14', 'Quinn Corkery', '9', '1813', '6091', 'eligendi', null, null, null, '1');
INSERT INTO `products` VALUES ('15', 'Terrill Langworth', '8', '2964', '8460', 'dolor', null, null, null, '1');
INSERT INTO `products` VALUES ('16', 'Camylle Corkery', '7', '8462', '9384', 'est', null, null, null, '1');
INSERT INTO `products` VALUES ('17', 'Petra O\'Kon', '1', '7190', '2736', 'et', null, null, null, '1');
INSERT INTO `products` VALUES ('18', 'Ulices Kunde', '2', '3646', '5803', 'vel', null, null, null, '1');
INSERT INTO `products` VALUES ('19', 'Arvid Keeling', '6', '2200', '85', 'necessitatibus', null, null, null, '1');
INSERT INTO `products` VALUES ('20', 'Emilia Corkery', '2', '6221', '6381', 'in', null, null, null, '1');
INSERT INTO `products` VALUES ('21', 'asdfadasd', '1', '95', '91', 'asdasdasdsadasdasd', '2020-03-10 17:23:58', '2020-03-10 17:23:58', null, null);
INSERT INTO `products` VALUES ('22', 'Maisie Hoover', '1', '932', '490', 'Est temporibus labor', '2020-03-10 17:25:28', '2020-03-10 17:25:28', null, null);
INSERT INTO `products` VALUES ('23', 'asdasdad', '1', '45541', '2112', 'asdasdasdadasd', '2020-03-10 17:28:37', '2020-03-10 17:28:37', null, null);

-- ----------------------------
-- Table structure for prod_extras
-- ----------------------------
DROP TABLE IF EXISTS `prod_extras`;
CREATE TABLE `prod_extras` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pe_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pe_price_bs` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pe_price_usd` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pe_partner_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prod_extras_pe_partner_id_foreign` (`pe_partner_id`),
  CONSTRAINT `prod_extras_pe_partner_id_foreign` FOREIGN KEY (`pe_partner_id`) REFERENCES `partners` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of prod_extras
-- ----------------------------

-- ----------------------------
-- Table structure for rates
-- ----------------------------
DROP TABLE IF EXISTS `rates`;
CREATE TABLE `rates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rt_value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of rates
-- ----------------------------

-- ----------------------------
-- Table structure for rate_list
-- ----------------------------
DROP TABLE IF EXISTS `rate_list`;
CREATE TABLE `rate_list` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rate_order_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rate_list_rate_order_id_foreign` (`rate_order_id`),
  CONSTRAINT `rate_list_rate_order_id_foreign` FOREIGN KEY (`rate_order_id`) REFERENCES `orders` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of rate_list
-- ----------------------------

-- ----------------------------
-- Table structure for roles_permissions
-- ----------------------------
DROP TABLE IF EXISTS `roles_permissions`;
CREATE TABLE `roles_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of roles_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for roles_users
-- ----------------------------
DROP TABLE IF EXISTS `roles_users`;
CREATE TABLE `roles_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rs_perms_id` bigint(20) unsigned NOT NULL,
  `rs_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `roles_users_rs_perms_id_foreign` (`rs_perms_id`),
  CONSTRAINT `roles_users_rs_perms_id_foreign` FOREIGN KEY (`rs_perms_id`) REFERENCES `roles_permissions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of roles_users
-- ----------------------------

-- ----------------------------
-- Table structure for states
-- ----------------------------
DROP TABLE IF EXISTS `states`;
CREATE TABLE `states` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `st_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `st_iso` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of states
-- ----------------------------
INSERT INTO `states` VALUES ('1', 'Amazonas', 'VE-X', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('2', 'Anzoátegui', 'VE-B', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('3', 'Apure', 'VE-C', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('4', 'Aragua', 'VE-D', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('5', 'Barinas', 'VE-E', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('6', 'Bolívar', 'VE-F', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('7', 'Carabobo', 'VE-G', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('8', 'Cojedes', 'VE-H', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('9', 'Delta Amacuro', 'VE-Y', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('10', 'Falcón', 'VE-I', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('11', 'Guárico', 'VE-J', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('12', 'Lara', 'VE-K', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('13', 'Mérida', 'VE-L', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('14', 'Miranda', 'VE-M', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('15', 'Monagas', 'VE-N', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('16', 'Nueva Esparta', 'VE-O', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('17', 'Portuguesa', 'VE-P', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('18', 'Sucre', 'VE-R', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('19', 'Táchira', 'VE-S', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('20', 'Trujillo', 'VE-T', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('21', 'Vargas', 'VE-W', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('22', 'Yaracuy', 'VE-U', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('23', 'Zulia', 'VE-V', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('24', 'Distrito Capital', 'VE-A', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('25', 'Dependencias Federales', 'VE-Z', '2020-02-29 21:28:41', '2020-02-29 21:28:41', null);
INSERT INTO `states` VALUES ('26', 'Amazonas', 'VE-X', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('27', 'Anzoátegui', 'VE-B', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('28', 'Apure', 'VE-C', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('29', 'Aragua', 'VE-D', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('30', 'Barinas', 'VE-E', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('31', 'Bolívar', 'VE-F', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('32', 'Carabobo', 'VE-G', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('33', 'Cojedes', 'VE-H', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('34', 'Delta Amacuro', 'VE-Y', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('35', 'Falcón', 'VE-I', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('36', 'Guárico', 'VE-J', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('37', 'Lara', 'VE-K', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('38', 'Mérida', 'VE-L', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('39', 'Miranda', 'VE-M', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('40', 'Monagas', 'VE-N', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('41', 'Nueva Esparta', 'VE-O', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('42', 'Portuguesa', 'VE-P', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('43', 'Sucre', 'VE-R', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('44', 'Táchira', 'VE-S', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('45', 'Trujillo', 'VE-T', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('46', 'Vargas', 'VE-W', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('47', 'Yaracuy', 'VE-U', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('48', 'Zulia', 'VE-V', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('49', 'Distrito Capital', 'VE-A', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('50', 'Dependencias Federales', 'VE-Z', '2020-02-29 21:29:00', '2020-02-29 21:29:00', null);
INSERT INTO `states` VALUES ('51', 'Amazonas', 'VE-X', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('52', 'Anzoátegui', 'VE-B', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('53', 'Apure', 'VE-C', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('54', 'Aragua', 'VE-D', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('55', 'Barinas', 'VE-E', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('56', 'Bolívar', 'VE-F', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('57', 'Carabobo', 'VE-G', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('58', 'Cojedes', 'VE-H', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('59', 'Delta Amacuro', 'VE-Y', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('60', 'Falcón', 'VE-I', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('61', 'Guárico', 'VE-J', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('62', 'Lara', 'VE-K', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('63', 'Mérida', 'VE-L', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('64', 'Miranda', 'VE-M', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('65', 'Monagas', 'VE-N', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('66', 'Nueva Esparta', 'VE-O', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('67', 'Portuguesa', 'VE-P', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('68', 'Sucre', 'VE-R', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('69', 'Táchira', 'VE-S', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('70', 'Trujillo', 'VE-T', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('71', 'Vargas', 'VE-W', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('72', 'Yaracuy', 'VE-U', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('73', 'Zulia', 'VE-V', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('74', 'Distrito Capital', 'VE-A', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('75', 'Dependencias Federales', 'VE-Z', '2020-02-29 21:29:16', '2020-02-29 21:29:16', null);
INSERT INTO `states` VALUES ('76', 'Amazonas', 'VE-X', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('77', 'Anzoátegui', 'VE-B', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('78', 'Apure', 'VE-C', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('79', 'Aragua', 'VE-D', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('80', 'Barinas', 'VE-E', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('81', 'Bolívar', 'VE-F', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('82', 'Carabobo', 'VE-G', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('83', 'Cojedes', 'VE-H', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('84', 'Delta Amacuro', 'VE-Y', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('85', 'Falcón', 'VE-I', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('86', 'Guárico', 'VE-J', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('87', 'Lara', 'VE-K', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('88', 'Mérida', 'VE-L', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('89', 'Miranda', 'VE-M', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('90', 'Monagas', 'VE-N', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('91', 'Nueva Esparta', 'VE-O', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('92', 'Portuguesa', 'VE-P', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('93', 'Sucre', 'VE-R', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('94', 'Táchira', 'VE-S', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('95', 'Trujillo', 'VE-T', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('96', 'Vargas', 'VE-W', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('97', 'Yaracuy', 'VE-U', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('98', 'Zulia', 'VE-V', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('99', 'Distrito Capital', 'VE-A', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('100', 'Dependencias Federales', 'VE-Z', '2020-02-29 21:31:44', '2020-02-29 21:31:44', null);
INSERT INTO `states` VALUES ('101', 'Amazonas', 'VE-X', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('102', 'Anzoátegui', 'VE-B', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('103', 'Apure', 'VE-C', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('104', 'Aragua', 'VE-D', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('105', 'Barinas', 'VE-E', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('106', 'Bolívar', 'VE-F', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('107', 'Carabobo', 'VE-G', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('108', 'Cojedes', 'VE-H', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('109', 'Delta Amacuro', 'VE-Y', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('110', 'Falcón', 'VE-I', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('111', 'Guárico', 'VE-J', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('112', 'Lara', 'VE-K', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('113', 'Mérida', 'VE-L', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('114', 'Miranda', 'VE-M', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('115', 'Monagas', 'VE-N', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('116', 'Nueva Esparta', 'VE-O', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('117', 'Portuguesa', 'VE-P', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('118', 'Sucre', 'VE-R', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('119', 'Táchira', 'VE-S', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('120', 'Trujillo', 'VE-T', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('121', 'Vargas', 'VE-W', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('122', 'Yaracuy', 'VE-U', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('123', 'Zulia', 'VE-V', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('124', 'Distrito Capital', 'VE-A', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('125', 'Dependencias Federales', 'VE-Z', '2020-02-29 21:32:29', '2020-02-29 21:32:29', null);
INSERT INTO `states` VALUES ('126', 'Amazonas', 'VE-X', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('127', 'Anzoátegui', 'VE-B', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('128', 'Apure', 'VE-C', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('129', 'Aragua', 'VE-D', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('130', 'Barinas', 'VE-E', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('131', 'Bolívar', 'VE-F', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('132', 'Carabobo', 'VE-G', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('133', 'Cojedes', 'VE-H', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('134', 'Delta Amacuro', 'VE-Y', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('135', 'Falcón', 'VE-I', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('136', 'Guárico', 'VE-J', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('137', 'Lara', 'VE-K', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('138', 'Mérida', 'VE-L', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('139', 'Miranda', 'VE-M', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('140', 'Monagas', 'VE-N', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('141', 'Nueva Esparta', 'VE-O', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('142', 'Portuguesa', 'VE-P', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('143', 'Sucre', 'VE-R', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('144', 'Táchira', 'VE-S', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('145', 'Trujillo', 'VE-T', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('146', 'Vargas', 'VE-W', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('147', 'Yaracuy', 'VE-U', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('148', 'Zulia', 'VE-V', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('149', 'Distrito Capital', 'VE-A', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('150', 'Dependencias Federales', 'VE-Z', '2020-02-29 21:33:14', '2020-02-29 21:33:14', null);
INSERT INTO `states` VALUES ('151', 'Amazonas', 'VE-X', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('152', 'Anzoátegui', 'VE-B', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('153', 'Apure', 'VE-C', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('154', 'Aragua', 'VE-D', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('155', 'Barinas', 'VE-E', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('156', 'Bolívar', 'VE-F', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('157', 'Carabobo', 'VE-G', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('158', 'Cojedes', 'VE-H', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('159', 'Delta Amacuro', 'VE-Y', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('160', 'Falcón', 'VE-I', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('161', 'Guárico', 'VE-J', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('162', 'Lara', 'VE-K', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('163', 'Mérida', 'VE-L', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('164', 'Miranda', 'VE-M', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('165', 'Monagas', 'VE-N', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('166', 'Nueva Esparta', 'VE-O', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('167', 'Portuguesa', 'VE-P', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('168', 'Sucre', 'VE-R', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('169', 'Táchira', 'VE-S', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('170', 'Trujillo', 'VE-T', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('171', 'Vargas', 'VE-W', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('172', 'Yaracuy', 'VE-U', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('173', 'Zulia', 'VE-V', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('174', 'Distrito Capital', 'VE-A', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('175', 'Dependencias Federales', 'VE-Z', '2020-02-29 21:34:06', '2020-02-29 21:34:06', null);
INSERT INTO `states` VALUES ('176', 'Amazonas', 'VE-X', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('177', 'Anzoátegui', 'VE-B', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('178', 'Apure', 'VE-C', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('179', 'Aragua', 'VE-D', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('180', 'Barinas', 'VE-E', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('181', 'Bolívar', 'VE-F', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('182', 'Carabobo', 'VE-G', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('183', 'Cojedes', 'VE-H', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('184', 'Delta Amacuro', 'VE-Y', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('185', 'Falcón', 'VE-I', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('186', 'Guárico', 'VE-J', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('187', 'Lara', 'VE-K', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('188', 'Mérida', 'VE-L', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('189', 'Miranda', 'VE-M', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('190', 'Monagas', 'VE-N', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('191', 'Nueva Esparta', 'VE-O', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('192', 'Portuguesa', 'VE-P', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('193', 'Sucre', 'VE-R', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('194', 'Táchira', 'VE-S', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('195', 'Trujillo', 'VE-T', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('196', 'Vargas', 'VE-W', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('197', 'Yaracuy', 'VE-U', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('198', 'Zulia', 'VE-V', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('199', 'Distrito Capital', 'VE-A', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);
INSERT INTO `states` VALUES ('200', 'Dependencias Federales', 'VE-Z', '2020-02-29 21:34:50', '2020-02-29 21:34:50', null);

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('1', 'gioanfranco', 'gioan2908@gmail.com', null, '$2y$10$zqN.1kzd9uLnSXDN/yB73umPef1rQltnUn.SSt2pCciMMn/AjsaIq', null, null, null);

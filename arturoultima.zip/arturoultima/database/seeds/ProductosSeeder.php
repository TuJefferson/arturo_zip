<?php

use Illuminate\Database\Seeder;
use Faker\Factory as Faker;
class ProductosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();
    	foreach (range(1,10) as $index) {
	        DB::table('products')->insert([
	            'prod_name' => $faker->name,
	            'prod_partner_id' => $faker->numberBetween(1,9),
	            'prod_price_bs' => $faker->randomNumber(4),
	            'prod_price_usd' => $faker->randomNumber(4),
	            'prod_description' => $faker->word
	        ]);
		}
    }
}

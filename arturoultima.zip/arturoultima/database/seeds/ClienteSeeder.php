<?php

use Illuminate\Database\Seeder;
use Faker\Factory as Faker;
class ClienteSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();
    	foreach (range(1,10) as $index) {
	        DB::table('clients')->insert([
	            'cl_name' => $faker->name,
	            'cl_last_name' => $faker->lastName,
	            'cl_user' => $faker->word,
	            'cl_dni' => $faker->randomDigit,
	            'cl_phone_1' => $faker->phoneNumber,
	            'cl_phone_2' => $faker->phoneNumber,
	            'cl_email' => $faker->email,
	            'password' => bcrypt('secret')
	        ]);
		}
    }
}

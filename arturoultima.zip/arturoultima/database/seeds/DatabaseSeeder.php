<?php

use Illuminate\Database\Seeder;

use Illuminate\Database\Eloquent\Model;
class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
         $this->call(EstadosSeeder::class);
         $this->call(MunicipiossSeeder::class);
         $this->call(AdminsSeeder::class);
         $this->call(CategoriesPartnerSeeder::class);
         $this->call(AddresssSeeder::class);
         $this->call(ClienteSeeder::class);
         $this->call(PartnerSeeder::class);
         $this->call(ProductosSeeder::class);
         $this->call(RepartidorSeeder::class);

    }
}

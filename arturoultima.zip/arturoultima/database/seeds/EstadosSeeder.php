<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
// use DB;
use App\States;
class EstadosSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
	{
		$estados = [
			['VE-X', 'Amazonas'],
			['VE-B', 'Anzoátegui'],
			['VE-C', 'Apure'],
			['VE-D', 'Aragua'],
			['VE-E', 'Barinas'],
			['VE-F', 'Bolívar'],
			['VE-G', 'Carabobo'],
			['VE-H', 'Cojedes'],
			['VE-Y', 'Delta Amacuro'],
			['VE-I', 'Falcón'],
			['VE-J', 'Guárico'],
			['VE-K', 'Lara'],
			['VE-L', 'Mérida'],
			['VE-M', 'Miranda'],
			['VE-N', 'Monagas'],
			['VE-O', 'Nueva Esparta'],
			['VE-P', 'Portuguesa'],
			['VE-R', 'Sucre'],
			['VE-S', 'Táchira'],
			['VE-T', 'Trujillo'],
			['VE-W', 'Vargas'],
			['VE-U', 'Yaracuy'],
			['VE-V', 'Zulia'],
			['VE-A', 'Distrito Capital'],
			['VE-Z', 'Dependencias Federales']
		];

		DB::beginTransaction();
		try{
			foreach ($estados as $estado) {
				States::create([
					'st_name' 		=> $estado[1],
					'st_iso' 	=> $estado[0]
				]);
			}
		}catch(Exception $e){
			DB::rollback();
			return "Error ";
		}
		DB::commit();
	}

}

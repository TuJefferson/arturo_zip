<?php

use Illuminate\Database\Seeder;
use Faker\Factory as Faker;
class RepartidorSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
       $faker = Faker::create();
    	foreach (range(1,10) as $index) {
	        DB::table('delivery_man')->insert([
	            'dm_name' => $faker->name,
	            'dm_last_name' => $faker->lastName,
	            'dm_user' => $faker->word,
	            'dm_email' => $faker->email,
	            'password' => bcrypt('secret'),
	            'dm_phone_1' => $faker->phoneNumber,
	            'dm_phone_2' => $faker->phoneNumber,
	        ]);
		}
    }
}

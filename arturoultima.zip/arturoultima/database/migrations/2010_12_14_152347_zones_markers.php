<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ZonesMarkers extends Migration
{
   public function up()
        {
            Schema::create('zones_markers', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->float('marker_lon', 8, 2);
                $table->float('marker_lat', 8, 2);
                $table->bigInteger('zone_id')->unsigned()->nullable();
                $table->foreign('zone_id')->references('id')->on('aviable_zones');
                $table->timestamps();
                $table->softDeletes();
            });
        }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('zones_markers');
    }
}

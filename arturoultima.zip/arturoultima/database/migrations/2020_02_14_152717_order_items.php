<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class OrderItems extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
        {
            Schema::create('order_items', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->bigInteger('ord_id')->unsigned()->nullable();
                $table->foreign('ord_id')->references('id')->on('orders');
                $table->bigInteger('prod_id')->unsigned()->nullable();
                $table->foreign('prod_id')->references('id')->on('products');
                $table->bigInteger('extra_id')->unsigned()->nullable();
                $table->foreign('extra_id')->references('id')->on('prod_extras');
                $table->timestamps();
                $table->softDeletes();
            });
        }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('order_items');
    }
}

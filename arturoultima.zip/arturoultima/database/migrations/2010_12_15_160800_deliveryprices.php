<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Deliveryprices extends Migration
{
   public function up()
        {
            Schema::create('delivery_price', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->string('delivery_price');
                $table->string('cur_name');
                $table->timestamps();
                $table->softDeletes();
            });
        }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('delivery_price');
    }
}

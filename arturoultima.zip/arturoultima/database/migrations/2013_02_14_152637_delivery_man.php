<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class DeliveryMan extends Migration
{
    public function up()
        {
            Schema::create('delivery_man', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->string('dm_name');
                $table->string('dm_last_name');
                $table->string('dm_user')->unique();
                $table->string('dm_email')->unique();
                $table->string('password');
                $table->string('avatar')->default('user.jpg');
                $table->string('mime')->nullable();
                $table->string('original_filename')->nullable();
                $table->string('dm_phone_1');
                $table->string('dm_phone_2')->nullable();
                $table->bigInteger('dm_rs_id')->unsigned()->nullable();
                $table->foreign('dm_rs_id')->references('id')->on('roles_users');
                $table->string('dm_rate')->nullable();
                $table->string('dm_intents')->nullable();
                $table->string('dm_blocked')->nullable();
                $table->string('dm_pass_exp')->nullable();
                $table->rememberToken();
                $table->timestamps();
                $table->softDeletes();
            });
        }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('delivery_man');
    }
}

<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class OrderItemsExtras extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
        {
            Schema::create('order_items_extras', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->bigInteger('order_item_prod')->unsigned()->nullable();
                $table->foreign('order_item_prod')->references('prod_id')->on('order_items');
                $table->bigInteger('extra_id')->unsigned()->nullable();
                $table->foreign('extra_id')->references('id')->on('prod_extras');
                $table->timestamps();
                $table->softDeletes();
            });
        }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('order_items_extras');
    }
}

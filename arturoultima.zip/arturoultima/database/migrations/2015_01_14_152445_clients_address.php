<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ClientsAddress extends Migration
{
    public function up()
        {
            Schema::create('clients_address', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->bigInteger('ca_cl_id')->unsigned()->nullable();
                $table->foreign('ca_cl_id')->references('id')->on('clients');
                $table->bigInteger('ca_address_id')->unsigned()->nullable();
                $table->foreign('ca_address_id')->references('id')->on('address');
                $table->timestamps();
                $table->softDeletes();
            });
        }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('clients_address');
    }
}

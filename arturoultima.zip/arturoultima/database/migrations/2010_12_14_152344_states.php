<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class States extends Migration
{
     public function up()
        {
            Schema::create('states', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->string('st_name',100);
                $table->string('st_iso',100);
                $table->timestamps();
                $table->softDeletes();
            });
        }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('states');
    }

}

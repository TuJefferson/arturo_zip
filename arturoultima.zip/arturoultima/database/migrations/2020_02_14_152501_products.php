<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Products extends Migration
{
    public function up()
        {
            Schema::create('products', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->string('prod_name');
                $table->bigInteger('prod_partner_id')->unsigned()->nullable();
                $table->foreign('prod_partner_id')->references('id')->on('partners');
                $table->bigInteger('prod_partner_id')->unsigned()->nullable();
                $table->foreign('prod_partner_id')->references('id')->on('partners');
                $table->string('prod_price_bs')->nullable();
                $table->string('prod_price_usd');
                $table->string('prod_description')->nullable();
                $table->string('prod_category')->nullable();
                $table->string('prod_image')->nullable();
                $table->string('prod_suges')->nullable();
                $table->string('prod_recome')->nullable();
                $table->foreign('prod_seg_id')->references('id')->on('segmentatios');
                $table->bigInteger('prod_seg_id')->unsigned()->nullable();
                $table->timestamps();
                $table->softDeletes();
            });
        }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('products');
    }
}

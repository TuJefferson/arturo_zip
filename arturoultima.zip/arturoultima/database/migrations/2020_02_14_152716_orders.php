<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Orders extends Migration
{
     public function up()
        {
            Schema::create('orders', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->string('ord_prod_name');
                $table->bigInteger('ord_prod_id')->unsigned()->nullable();
                $table->foreign('ord_prod_id')->references('id')->on('products');
                $table->bigInteger('ord_address')->unsigned()->nullable();
                $table->foreign('ord_address')->references('id')->on('clients_address');
                $table->string('ord_price_bs');
                $table->string('ord_price_usd');
                $table->string('ord_description');
                $table->string('ord_status');
                $table->bigInteger('ord_extras')->unsigned()->nullable();
                $table->foreign('ord_extras')->references('id')->on('prod_extras');
                $table->string('ord_rate');
               $table->bigInteger('ord_dm_id')->unsigned()->nullable();
                $table->foreign('ord_dm_id')->references('id')->on('delivery_man');
                $table->string('ord_dm_rate');
                $table->bigInteger('ord_payment_id')->unsigned()->nullable();
                $table->foreign('ord_payment_id')->references('id')->on('payments');
                $table->timestamps();
                $table->softDeletes();
            });
        }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('orders');
    }
}

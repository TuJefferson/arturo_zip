<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Address extends Migration
{

    public function up()
    {
        Schema::create('address', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('st_id')->unsigned()->nullable();
            $table->foreign('st_id')->references('id')->on('states');
            $table->bigInteger('mun_id')->unsigned()->nullable();
            $table->foreign('mun_id')->references('id')->on('municipios');
            $table->string('description',191);
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('address');
    }
}



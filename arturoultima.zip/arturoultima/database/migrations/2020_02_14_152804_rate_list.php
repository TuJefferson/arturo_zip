<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class RateList extends Migration
{
    public function up()
        {
            Schema::create('rate_list', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->bigInteger('rate_order_id')->unsigned()->nullable();
                $table->foreign('rate_order_id')->references('id')->on('orders');
                $table->timestamps();
                $table->softDeletes();
            });
        }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('rate_list');
    }
}

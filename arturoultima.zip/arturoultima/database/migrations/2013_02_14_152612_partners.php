<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Partners extends Migration
{
      public function up()
        {
            Schema::create('partners', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->string('p_name');
                $table->string('p_last_name');
                $table->string('p_user')->unique();
                $table->string('p_email')->unique();
                $table->string('p_phone_1');
                $table->string('p_phone_2')->nullable();
                $table->string('password');
                $table->string('p_rif');
                $table->bigInteger('p_rs_id')->unsigned()->nullable();
                $table->foreign('p_rs_id')->references('id')->on('roles_users');
                $table->bigInteger('p_mun_id')->unsigned()->nullable();
                $table->foreign('p_mun_id')->references('id')->on('municipios');
                $table->string('p_adrress');
                $table->bigInteger('p_cat_id')->unsigned()->nullable();
                $table->foreign('p_cat_id')->references('id')->on('categories');
                $table->string('p_intents')->nullable();
                $table->string('p_blocked')->nullable();
                $table->string('p_pass_exp')->nullable();
                $table->string('p_open_time')->nullable();
                $table->string('p_close_time')->nullable();
                $table->string('p_rate')->nullable();
                $table->string('p_description')->nullable();
                $table->bigInteger('p_shipping')->nullable();
                $table->rememberToken();
                $table->timestamps();
                $table->softDeletes();
            });
        }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('partners');
    }
}


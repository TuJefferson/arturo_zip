<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class DmPayments extends Migration
{
    public function up()
        {
            Schema::create('dm_payments', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->bigInteger('ord_id')->unsigned()->nullable();
                $table->foreign('ord_id')->references('id')->on('orders');
                $table->bigInteger('dm_id')->unsigned()->nullable();
                $table->foreign('dm_id')->references('id')->on('delivery_man');
                $table->string('dm_pay_amount');
                $table->string('dm_pay_bank');
                $table->string('dm_payref');
                $table->timestamps();
                $table->softDeletes();
            });
        }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('dm_payments');
    }
}

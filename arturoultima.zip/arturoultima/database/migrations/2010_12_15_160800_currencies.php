<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Currencies extends Migration
{
   public function up()
        {
            Schema::create('curriencies', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->string('cur_name');
                $table->string('cur_value');
                $table->timestamps();
                $table->softDeletes();
            });
        }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('curriencies');
    }
}

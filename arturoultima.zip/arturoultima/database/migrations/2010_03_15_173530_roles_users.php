<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class RolesUsers extends Migration
{
   public function up()
    {
        Schema::create('roles_users', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->bigInteger('rs_perms_id')->unsigned();
            $table->foreign('rs_perms_id')->references('id')->on('roles_permissions');
            $table->string('rs_type',191);
            $table->timestamps();
            $table->softDeletes();
        });

    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('roles_users');
    }
}






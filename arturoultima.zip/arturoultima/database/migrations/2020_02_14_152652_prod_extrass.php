<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class ProdExtrass extends Migration
{
    public function up()
        {
            Schema::create('prod_extras', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->string('pe_name');
                $table->string('pe_price_bs');
                $table->string('pe_price_usd');
                $table->string('prod_type');
                $table->bigInteger('pe_partner_id')->unsigned()->nullable();
                $table->foreign('pe_partner_id')->references('id')->on('partners');
                $table->bigInteger('prod_id')->unsigned()->nullable();
                $table->foreign('prod_id')->references('id')->on('products');
                $table->timestamps();
                $table->softDeletes();
            });
        }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('prod_extras');
    }
}

<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Admins extends Migration
{

      public function up()

        {
            Schema::create('admins', function (Blueprint $table) {
                $table->bigIncrements('id');
                $table->string('ad_name');
                $table->string('ad_last_name');
                $table->string('ad_email')->unique();
                $table->string('ad_user_name')->unique();
                $table->string('password');
                $table->bigInteger('ad_rs_id')->unsigned()->nullable();
                $table->foreign('ad_rs_id')->references('id')->on('roles_users');
                $table->string('ad_intents')->nullable();;
                $table->string('ad_blocked')->nullable();;
                $table->string('ad_pass_exp')->nullable();;
                $table->rememberToken();
                $table->timestamps();
            });
        }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('admins');
    }
}

<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateClientsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('clients', function (Blueprint $table) {
            $table->bigIncrements('id');
            $table->string('cl_name');
            $table->string('cl_last_name');
            $table->string('cl_user')->unique();
            $table->string('cl_dni');
            $table->string('cl_phone_1');
            $table->string('cl_phone_2');
            $table->bigInteger('cl_rs_id')->unsigned()->nullable();
            $table->foreign('cl_rs_id')->references('id')->on('roles_users');
            $table->string('cl_email')->unique();
            $table->string('cl_verified')->nullable();
            $table->string('password');
            $table->string('cl_intents')->nullable();
            $table->string('cl_blocked')->nullable();
            $table->string('cl_pass_exp')->nullable();
            $table->rememberToken();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('clients');
    }
}

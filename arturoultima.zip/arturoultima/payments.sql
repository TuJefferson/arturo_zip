/*
Navicat MySQL Data Transfer

Source Server         : local_host
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : its_on_the_way

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2020-04-07 08:50:04
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for payments
-- ----------------------------
DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pay_platform_id` bigint(20) NOT NULL,
  `pay_ref` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pay_type` bigint(20) NOT NULL,
  `pay_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `pay_amount` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `payment_type_id_fk` (`pay_type`),
  KEY `payment_platform_id_fk` (`pay_platform_id`),
  CONSTRAINT `payment_platform_id_fk` FOREIGN KEY (`pay_platform_id`) REFERENCES `payments_platforms` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `payment_type_id_fk` FOREIGN KEY (`pay_type`) REFERENCES `payment_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of payments
-- ----------------------------
INSERT INTO `payments` VALUES ('1', '1', '1012455', '1', 'pago por deuda mes 1', '357891', '2020-03-21 22:17:46', null, null);

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class States extends Model
{
	 use SoftDeletes;
    protected $table = 'states';


     public function municipios(){
        // hasMany = "tiene muchas" | hace relacion desde el maestro hasta el detalle
        return $this->hasMany('App\municipios', 'states_id');
    }

}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class AviableZones extends Model
{
    use SoftDeletes;
    protected $table = 'aviable_zones';


    public function zones_markers(){

        return $this->hasMany('App\AviableZonesMarkers',  'zone_id');
    }
}

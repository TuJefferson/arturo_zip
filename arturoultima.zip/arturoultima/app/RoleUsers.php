<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class RoleUsers extends Model
{
    protected $table = 'roles_users';
}

<?php

namespace App;


use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

use Tymon\JWTAuth\Contracts\JWTSubject;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;


class Clients extends Authenticatable implements JWTSubject


{
   use Notifiable;
	 use SoftDeletes;
   protected $table = 'clients';

   protected $fillable = [
        'cl_name', 'cl_email','cl_verified', 'password', 'cl_last_name', 'cl_user', 'cl_phone_1', 'cl_phone_2', 'cl_dni', 'cl_mun_id','cl_adrress' , 'cl_descricltion', 'cl_shipping', 'cl_intents', 'cl_blocked', 'cl_pass_exp', 'created_at' , 'updated_at', 'deleted_at'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token','confirmation_code'
    ];

      public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [];
    }

    // public function setPasswordAttribute($value) {
    //     $this->attributes['password'] = encrypt($value);
    // }
}

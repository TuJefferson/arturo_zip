<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Orders extends Model
{

    use SoftDeletes;
    protected $table = 'orders';
    
    public function payments(){
        // hasMany = "tiene muchas" | hace relacion desde el maestro hasta el detalle
         return $this->belongsTo('App\Payments', 'ord_payment_id', 'id');
    }

    public function orderItems(){
        // hasMany = "tiene muchas" | hace relacion desde el maestro hasta el detalle
        return $this->belongsTo('App\Orders', 'ord_id');
    }

    public function partners()
    {
        return $this->belongsTo('App\Partners', 'ord_id');
    }
}
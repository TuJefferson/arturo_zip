<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class WorkingStatus extends Model
{
    use SoftDeletes;
    protected $table = 'working_status';
      protected $fillable = [
        'status',
    ];

}

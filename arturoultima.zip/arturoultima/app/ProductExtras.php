<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class ProductExtras extends Model
{
    use SoftDeletes;
    protected $table = 'prod_extras';

    public function products() {
        return $this->belongsTo('Products');
    }
}

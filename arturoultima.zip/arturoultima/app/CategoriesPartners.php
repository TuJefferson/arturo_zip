<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class CategoriesPartners extends Model
{
	 use SoftDeletes;
  protected $table = 'categories';


  public function subcategory(){
        // hasMany = "tiene muchas" | hace relacion desde el maestro hasta el detalle
        return $this->hasMany('App\AviableZonesMarkers', 'cat_id');
    }
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class PartnerAccounts extends Model
{
    use SoftDeletes;
   // protected $table = 'partner_accounts_partners';
    protected $table = 'partner_accounts_partners';

	  public function partners()
	    {
	        return $this->hasOne(Partners::class);
	    }
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class PartnerPayments extends Model
{
    
   protected $table = 'partner_payments';

   protected $fillable = [
      'partner_id', 'payment_id'
   ];

}
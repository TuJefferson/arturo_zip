<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Products extends Model
{
	 use SoftDeletes;
   protected $table = 'products';

    public function productsExtras() {
        return $this->hasMany('ProductsExtras');
    }
    public function partners() {
        return $this->belongsTo('Partners');
    }
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Notifications\Notifiable;
class Payments extends Model
{
   use Notifiable;
   protected $table = 'payments';

    public function paymentsplatforms(){
        // hasMany = "tiene muchas" | hace relacion desde el maestro hasta el detalle
        return $this->belongsTo('App\PaymentsPlatforms', 'pay_platform_id');
    }

    public function orders() {
        return $this->belongsTo('App\Orders', 'ord_payment_id');
    }
}
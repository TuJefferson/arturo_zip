<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class OrderItemsExtra extends Model
{
    //
    use SoftDeletes;
   	protected $table = 'order_items_extras';

    public function OrderItem()
	    {
	        return $this->hasOne(OrderItem::class);
	    }
}

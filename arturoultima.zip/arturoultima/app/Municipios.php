<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Municipios extends Model
{
	 use SoftDeletes;
    protected $table = 'municipios';


     public function estados()
    {
        return $this->belongsTo('App\Estados', 'states_id');
    }


}

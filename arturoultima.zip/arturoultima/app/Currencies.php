<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class Currencies extends Model
{
    use SoftDeletes;
    protected $table = 'curriencies';
}

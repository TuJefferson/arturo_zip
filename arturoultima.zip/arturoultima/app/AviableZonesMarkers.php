<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class AviableZonesMarkers extends Model
{
    use SoftDeletes;
    protected $table = 'zones_markers';


      public function zones()
	    {
	        return $this->hasOne(AviableZones::class);
	    }
}

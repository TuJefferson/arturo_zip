<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

use Tymon\JWTAuth\Contracts\JWTSubject;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;


class Partners extends Authenticatable implements JWTSubject
{
     use Notifiable;
    
   protected $table = 'partners';

   protected $fillable = [
        'p_name', 'p_email', 'password', 'p_last_name', 'p_user', 'p_phone_1', 'phone_2', 'p_rif', 'p_mun_id','p_adrress', 'p_cat_id', 'p_open_time', 'p_close_time', 'p_description', 'p_shipping'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

      public function getJWTIdentifier()
    {
        return $this->getKey();
    }

    /**
     * Return a key value array, containing any custom claims to be added to the JWT.
     *
     * @return array
     */
    public function getJWTCustomClaims()
    {
        return [];
    }
     public function partneraccounts()
    {
        return $this->belongsToMany(PartnerAccounts::class);
    }
    // public function articles()
    // {
    //     return $this->hasMany('App\Article');
    // }

    public function orders(){
        // hasMany = "tiene muchas" | hace relacion desde el maestro hasta el detalle
        return $this->hasMany('App\Orders');
    }
}
<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Partners;
use App\RoleUsers;
use Hash;
use DB;
use App\Clients;

class ClientInfoController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

     public function index($id)

    {


            // $roles = RoleUsers::all();

             $clients_info = Clients::find($id);
                 // $dm_info = DB::table('partners')
                 
             // dd($dm_info);
            return view('cliente_info')->with([
            'clients_info' => $clients_info,
        ]);
    }
}



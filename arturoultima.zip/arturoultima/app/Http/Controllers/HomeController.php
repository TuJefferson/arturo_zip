<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Orders;
use DB;
use App\WorkingStatus;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {



       $last_orders = DB::table('orders')

                 ->join('orders_status_type', 'orders.ord_status', '=', 'orders_status_type.id')   
                 ->join('clients_address', 'orders.ord_address', '=', 'clients_address.id')
                 ->join('address', 'clients_address.ca_address_id', '=', 'address.id')
                 ->join('aviable_zones','address.zon_id', '=','aviable_zones.id')
                 ->join('clients', 'clients_address.ca_cl_id', '=', 'clients.id')
                 ->join('municipios', 'address.mun_id', '=', 'municipios.id')
                 ->select(
                    'orders.id',
                    'orders.created_at',
                    'orders.bank_name',
                    'orders.zelle_name',
                    'orders.pay_by_zelle',
                    'orders.zelle_email',
                    'orders.ref_pay',
                    'clients.cl_name',
                    'clients.cl_email',
                    'orders_status_type.status_name',
                    'orders.ord_status AS ord_status',
                    'address.description AS address_description',
                    'municipios.mun_name AS municipio',
                    'aviable_zones.zone_name AS zone_name'
                 )
                 ->orderBy('created_at', 'desc')
                ->paginate(20);

               
        $workingStatus = DB::table('working_status')
                            ->select('status')
                            ->first();

        //script para recargar la pagina. 

        echo "<script>";
        echo "setInterval(function(){
        window.location.reload(1);
        }, 30000);";
        echo "</script>";
        return view('home')->with([
            'last_orders' => $last_orders,
            'workingStatus'=> $workingStatus,
        ]);
    }



    public function updateStatusOrder(Request $request){

        // dd($request);

             $order = Orders::find($request->order_id);

             if ($order) {
                    $order->ord_status = $request->order_status;
                    $order->save();
                   return back();
                }
            else{
                return response()->json('error');
            }
    }



}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use App\Admins;
use Auth;
use Redirect;

class AdminsController extends Controller
{

	public function register(Request $request)
        {
                $validator = Validator::make($request->all(), [
	                'ad_name' => 'required|string|max:255',
	                'ad_last_name' => 'required|string|max:255',
	                'email' => 'required|string|email|max:255|unique:admins',
	                'ad_user_name' => 'required|string|max:255|unique:admins',
	                'password' => 'required|string|min:6',
            	]);


	            $admin = new Admins;
	            $admin->ad_email = $request->email;
	           	$admin->ad_name = $request->ad_name;
	           	$admin->ad_last_name = $request->ad_last_name;
	           	$admin->ad_user_name = $request->ad_user_name;
	            $admin->password = bcrypt($request->password);
	             $admin->save();
	                  return response([	 'status' => 'success',	'data' => $admin	], 200);


        }

    public function login(Request $request)
    {


        $credentials = $request->only('ad_email', 'password');

    	// dd($credentials);

        if (!$token = JWTAuth::attempt($credentials)){
        	return response([
        	'status' => 'error',
        	'error' => 'invalid.credentials',
        	'msg' => 'crendenciales invalidas'

        	], 400);
        }
        return Redirect::to('adminhome/home')->with([
          'status' => 'success',
          'token' => $token

        ]);
        // return response([
        // 	'status' => 'success',
        // 	'token' => $token

        // ]);
    }


    public function logout(Request $request){

    	$this->validate($request, ['token' => 'required']);

    	try{
    		 JWTAuth::invalidate($request->input('token'));
    		 return response([
    		 	'status' => 'success',
    		 	'msg' => 'Has cerrado sesión']);

    	   }
    	   catch(JWTException $e) {
    	   		 return response([
    	   		 	'status' => 'error',
    	   		 	'msg' => 'Ha ocurrido un error por favor intenta de nuevo']);
    	   }


    }

    public function refresh(){
          return response([
          	'status' => 'success'
          ]);
      }

  	public function Admin(Request $request)	    {
  	       $admin = Admins::all();

  	               return response([
  	               	 'status' => 'success',	 'data' => $admin]);

  	       }


}

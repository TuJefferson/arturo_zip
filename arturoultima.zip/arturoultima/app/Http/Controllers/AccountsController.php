<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Orders;
use App\OrderItems;
use App\PartnerPayments;

use App\Partners;
use App\Products;
use App\PartnerAccounts;
use App\Payments;
use Carbon\Carbon;

use DB;

class AccountsController extends Controller
{



   public function index()
    {

            $partners =  DB::table('orders')
                        ->join('order_items', 'order_items.ord_id', '=', 'orders.id')
                        ->join('products', 'order_items.prod_id', '=', 'products.id')
                        ->join('partners', 'products.prod_partner_id','=','partners.id')
                         ->whereNull('orders.ord_payment_id')
                     ->select(
                        'partners.id AS p_id',
                        'partners.p_user AS p_user',
                        'partners.percent_amount',
                        'partners.percent_up',
                        'partners.profile_pic',
                        'orders.id AS ord_id'
                        )
                     ->get();
    
        return view('accounts')->with([
                    'partners' => $partners,
            ]);
    }


    //por pagar
    public function accounts_payable()
    {
        // $ordenes1 = DB::table('orders')
        //     ->join('order_items', 'order_items.ord_id', '=', 'orders.id')
        //     ->join('partners', 'order_items.order_partner_id','=','partners.id')
        //     ->where('ord_status', 4)
        //     ->whereNull('orders.ord_payment_id')
        //     ->whereNull('orders.ord_payment_id_bs')
        //     ->select(
        //         'orders.id AS orden_id',
        //         'orders.created_at AS orden_fecha',
        //         'orders.zelle_email AS orden_zelle_email',

        //         'orders.order_amount_bs AS orden_amount_bs',
        //         'orders.order_amount_usd AS order_amount_usd',

        //         // DB::Raw('sum(order_amount_bs) as orden_amount_bs'),
        //         // DB::Raw('sum(order_amount_usd) as order_amount_usd'),
        //         'partners.id AS partner_id',
        //         'partners.p_user AS partner_user',
        //         'partners.percent_amount AS partner_percent',
        //             )
        //     ->groupBy('orders.order_horario')
        //     ->groupBy('order_partner_id')
        //     ->groupBy( DB::Raw('DATE(orders.created_at)') )
        //     ->orderBy('orders.created_at')
        //     ->get();
        $ordenes = DB::table('orders')
        ->where('ord_status', 4)
        ->whereNull('deleted_at')
        ->whereNull('ord_payment_id')
        ->whereNull('ord_payment_id_bs')
        ->select(
            'id AS id',
            'partners_id AS partners_id',
            'created_at AS created_at',
            'order_horario AS order_horario',
            DB::Raw('sum(order_amount_bs) as order_amount_bs'),
            DB::Raw('sum(order_amount_usd) as order_amount_usd'),
        )
        ->groupBy('partners_id')
        ->groupBy('order_horario')
        ->groupBy( DB::Raw('DATE(created_at)') )
        ->orderBy('created_at', 'desc')
        ->get();

        return view('accounts_payable')->with([
                'ordenes' => $ordenes,
                          
            ]);

    }

    public function detail_accounts_payable (Request $request,$order_id) {

        $partner = Partners::find($request->partnerid);

        $partner_id_order1 = Products::where('prod_partner_id', $partner->id)->get();

        $ids_partner_id_order1 = array();

        foreach ($partner_id_order1 as $key => $value) {
            $ids_partner_id_order1[] =  $value->id;
        }

        $partner_id_order = OrderItems::whereIn('prod_id', $ids_partner_id_order1)->get();

        $ids_partner_id_order = array();

        foreach ($partner_id_order as $key => $value) {
            $ids_partner_id_order[] =  $value->ord_id;
        }

        $fecha = $request->fecha;
        $fecha =substr($fecha, -19, 10);


        if ($request->horario == 'am') {
         
            $order = Orders::
            where('created_at', 'LIKE' , '%'.$fecha.'%')
            ->where('created_at', '<=' , $fecha.' '.'11:59:59')
            ->where('ord_payment_id','=',null)
            ->where('ord_payment_id_bs','=',null)
            ->whereIn('id',$ids_partner_id_order)
            ->get();

        }else{
        
            $order = Orders::
            where('created_at', 'LIKE' , '%'.$fecha.'%')
            ->where('created_at', '>=' , $fecha.' '.'12:00:00')
            ->where('ord_payment_id','=',null)
            ->where('ord_payment_id_bs','=',null)
            ->whereIn('id',$ids_partner_id_order)
            ->get();
        }

        $porcentaje = $request->porcentaje;

        $cuentaspagarbs = PartnerAccounts::where('partners_id' , $request->partnerid)->where('bank_name','!=', 'Zelle')->get(); 

        $cuentaspagarusd = PartnerAccounts::where('partners_id' , $request->partnerid)->where('bank_name','=', 'Zelle')->get(); 

        $cuentas = PartnerAccounts::where('partners_id' , $request->partnerid)->get(); 

        $cuentaspagarbscount = count($cuentaspagarbs);
        
        return view('detail_accounts_payable', compact('order_id','order','partner','fecha','cuentas','porcentaje','cuentaspagarbs','cuentaspagarbscount','cuentaspagarusd'));
    }
 
    public function accounts_payable_pay (Request $request) {


        if ($request->totalbs > 0 && $request->totaluds > 0) {

            $id_order = Payments::orderBy('id','desc')->limit(1)->first();
 
            $payments = new Payments();
            $payments->pay_platform_id = 1;
            $payments->pay_ref = request()->refbs;
            $payments->pay_type = 1;
            $payments->pay_description = request()->banckname;
            $payments->pay_amount = request()->totalbs;
            $payments->created_at = Carbon::now();
            $payments->save();

            $payment_id = Payments::orderBy('id','desc')->limit(1)->first();

            $payments = new PartnerPayments();
            $payments->partner_id = request()->partner_id;
            $payments->payment_id = $payment_id->id;
            $payments->save();

            $id_orderbs = Payments::orderBy('id','desc')->limit(1)->first();

            $payments = new Payments();
            $payments->pay_platform_id = 2;
            $payments->pay_ref = request()->refusd;
            $payments->pay_type = '1';
            $payments->pay_description = request()->cuentausd;
            $payments->pay_amount = request()->totaluds;
            $payments->created_at = Carbon::now();
            $payments->save();

            $payment_id = Payments::orderBy('id','desc')->limit(1)->first();

            $payments = new PartnerPayments();
            $payments->partner_id = request()->partner_id;
            $payments->payment_id = $payment_id->id;
            $payments->save();

            $id_orderuds = Payments::orderBy('id','desc')->limit(1)->first();

            foreach ($request->idsordenes as $key => $value) {
                $update = Orders::find($value);
                $update->ord_payment_id_bs = $id_orderbs->id;
                $update->ord_payment_id = $id_orderuds->id;

                $update->save();
            }

            return redirect()->route('accounts_paid');

        } elseif ($request->totalbs > 0) {

            $payments = new Payments();
            $payments->pay_platform_id = 1;
            $payments->pay_ref = request()->refbs;
            $payments->pay_type = 1;
            $payments->pay_description = request()->banckname;
            $payments->pay_amount = request()->totalbs;
            $payments->created_at = Carbon::now();
            $payments->save();

            $id_order = Payments::orderBy('id','desc')->limit(1)->first();
            foreach ($request->idsordenes as $key => $value) {
                $update = Orders::find($value);
                $update->ord_payment_id_bs = $id_order->id;
                $update->ord_payment_id = null;
                $update->save();
            }

            $payment_id = Payments::orderBy('id','desc')->limit(1)->first();

            $payments = new PartnerPayments();
            $payments->partner_id = request()->partner_id;
            $payments->payment_id = $payment_id->id;
            $payments->save();

            return redirect()->route('accounts_paid');

        } else { 
            $payments = new Payments();
            $payments->pay_platform_id = 2;
            $payments->pay_ref = request()->refusd;
            $payments->pay_type = '1';
            $payments->pay_description = request()->cuentausd;
            $payments->pay_amount = request()->totaluds;
            $payments->created_at = Carbon::now();
            $payments->save();

            $id_order = Payments::orderBy('id','desc')->limit(1)->first();

            foreach ($request->idsordenes as $key => $value) {
                $update = Orders::find($value);
                $update->ord_payment_id_bs = null;
                $update->ord_payment_id = $id_order->id;
                $update->save();
            }

            $payment_id = Payments::orderBy('id','desc')->limit(1)->first();

            $payments = new PartnerPayments();
            $payments->partner_id = request()->partner_id;
            $payments->payment_id = $payment_id->id;
            $payments->save();

            return redirect()->route('accounts_paid');

        } 

    }

    
    //pagada
    public function accounts_paid()
    {

        $ordenes = DB::table('orders')
        ->where('ord_status', 4)
        ->whereNull('deleted_at')
        ->whereNotNull('ord_payment_id')
        ->orwhereNotNull('ord_payment_id_bs')
        ->select(
            'id AS id',
            'partners_id AS partners_id',
            'created_at AS created_at',
            'order_horario AS order_horario',
            DB::Raw('sum(order_amount_bs) as order_amount_bs'),
            DB::Raw('sum(order_amount_usd) as order_amount_usd'),
        )
        ->groupBy('order_horario')
        ->groupBy('partners_id')
        ->groupBy( DB::Raw('DATE(created_at)') )
        ->orderBy('created_at', 'desc')
        ->get();
        // $ordenes1 = DB::table('orders')
        // ->join('order_items', 'order_items.ord_id', '=', 'orders.id')
        // ->join('partners', 'order_items.order_partner_id','=','partners.id')
        // ->where('ord_status', 4)
        // ->where('orders.deleted_at', '=' ,null)
        // ->whereNotNull('orders.ord_payment_id')
        // ->orwhereNotNull('orders.ord_payment_id_bs')
        // ->select(
        //     'orders.id AS orden_id',
        //     'orders.created_at AS orden_fecha',
        //     'orders.zelle_email AS orden_zelle_email',
        //     'orders.order_amount_bs AS orden_amount_bs',
        //     'orders.order_amount_usd AS orden_amount_usd',
        //     // DB::Raw('sum(ordersorder_amount_bs) as orden_amount_bs'),
        //     // DB::Raw('sum(order_amount_usd) as order_amount_usd'),
        //     'partners.id AS partner_id',
        //     'partners.p_user AS partner_user',
        //     'partners.percent_amount AS partner_percent',
        //         )
        // ->groupBy('orders.order_horario')
        // ->groupBy('order_partner_id')
        // ->groupBy( DB::Raw('DATE(orders.created_at)') )
        // ->get();
        return view('accounts_paid')->with([
                    'ordenes' => $ordenes,
                ]);
    }

    public function detail_accounts_paid (Request $request,$order_id) {

        $null = null;

        $ordenes_item = OrderItems::where('order_partner_id', $request->partnerid)->get();

        $ids = array();

        foreach ($ordenes_item as $key => $value) {
            $ids[] =  $value->ord_id;
        }

        if ($request->horario == 'pm') {

            $order = Orders::
                whereIn('id',$ids)
                ->where('ord_status', 4)
                ->where('deleted_at', '=', null)
                ->where('order_horario', 'pm')
                ->where(function($query) use ($null){
                    $query->where('ord_payment_id', '!=', $null)
                    ->orWhere('ord_payment_id_bs', '!=', $null);
                })
                ->get();

        }else{

            $order = Orders::
                whereIn('id',$ids)
                ->where('ord_status', 4)
                ->where('deleted_at', '=', null)
                ->where('order_horario', 'am')
                ->where(function($query) use ($null){
                    $query->where('ord_payment_id', '!=', $null)
                    ->orWhere('ord_payment_id_bs', '!=', $null);
                })
                ->get();
        }


        $partner = Partners::find($request->partnerid);

        $fecha = $request->fecha;
        $fecha =substr($fecha, -19, 10);

        $porcentaje = $request->porcentaje;
        $cuentas = PartnerAccounts::where('partners_id' , $request->partnerid)->get(); 

        $porcentaje = $request->porcentaje;

        return view('detail_accounts_paid', compact('order','partner','fecha','cuentas','porcentaje'));
    }

    
    public function AccountDetail($id){


        $partner_info = DB::table('partners')
                ->where('partners.id','=', $id)
                ->first();  

        $partners_orders = DB::table('orders')
            ->join('order_items', 'order_items.ord_id', '=', 'orders.id')
            ->join('products', 'order_items.prod_id', '=', 'products.id')
            ->join('partners', 'products.prod_partner_id','=','partners.id')
            ->where('partners.id', '=', $id)
            ->where('orders.ord_status', '=', 4)
            ->whereNull('orders.ord_payment_id')            
            ->select('orders.id')
            ->groupBy('orders.id')
            ->get();
        // dd($partners_orders);

        $deb_amount = DB::table('orders')
            ->join('order_items', 'order_items.ord_id', '=', 'orders.id')
            ->join('products', 'order_items.prod_id', '=', 'products.id')
            ->join('partners', 'products.prod_partner_id','=','partners.id')
            ->where('partners.id', '=', $id)
            ->where('orders.ord_status', '>=', 2)
            ->sum('products.prod_price_usd');

            return view('accounts_detail')->with([
                'partner_info' => $partner_info,
                'deb_amount' => $deb_amount,
                'partners_orders' => $partners_orders
            ]);
    }


    public function PayToPartner(Request $request){


        

          $payment = Payments::find($request->pay_ref);
            if(!$payment){

                $payment = new Payments;
                $payment->pay_platform_id = $request->pay_platform_id;
                $payment->pay_ref = $request->pay_ref;
                $payment->pay_type = $request->pay_type;
                $payment->pay_description = $request->pay_description;
                $payment->pay_amount = $request->pay_amount;
                $payment->save();


                foreach ($request->ord_id as  $orden) {
                    
                    $orden = Orders::find($orden);
                    $orden->ord_payment_id = $payment->id;
                    $orden->save();
                }
                return back();
            }else{

                return response()->json(['error'=>  'pago ya se encuentra registrado']);
            }

    }

}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\WorkingStatus;

class WorkingStatusController extends Controller



{

	public function UpdateWorkingStatus(Request $request){

        $data = $request->all();


        $workingStatus = WorkingStatus::find(1);

         if ($workingStatus) {
                $workingStatus->status = $request->workingStatus;
                $workingStatus->save();
               return back();
            }
            else{
                return response()->json('error');
            }
  	  }


}

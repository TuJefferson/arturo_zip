<?php

namespace app\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use Redirect;
use DB;
use App\Orders;
use App\Partners;
use App\Products;
use App\DeliveryMan;
use Config;
use Response;

class PartnerPaymentsController extends Controller
{


		public function __construct()
	    {
			    Config::set('jwt.user', 'App\Partners');
	        	Config::set('auth.providers.users.model', \App\Partners::class);
		}



      public function payments($id)
	    {
	    	// dd($id);

	    	if ($id) {
	    		try {
	    		  $partner_payments = DB::table('partner_payments')
	             ->join('payments', 'partner_payments.payment_id', '=', 'payments.id')
	             ->join('partners', 'partner_payments.partner_id', '=', 'partners.id')
	             ->join('payment_type', 'payments.pay_type', '=', 'payment_type.id')
	             ->join('payments_platforms', 'payments.pay_platform_id', '=', 'payments_platforms.id')
	             ->where('payment_type.id', '=', '1')
	             ->where('partners.id', '=', $id)
	             ->select('payments_platforms.platform_payment','payments.pay_description','payments.pay_amount', 'payments.pay_ref')
	             ->get();

	              return [

		                	'response'=> array(
		                    	'partner_payments' =>$partner_payments,
		                    	'status'=> '200',
		               			 )
		            		];


	    	}catch(Throwable $e) {
        		report($e);

        		return false;
    			}
	    }

	}







}
<?php

namespace app\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use Redirect;
use DB;
use App\Orders;
use App\Partners;
use App\Products;
use App\DeliveryMan;
use Config;
use Response;

class PartnerTotalSalesController extends Controller
{


    public function __construct()
      {
          Config::set('jwt.user', 'App\Partners');
            Config::set('auth.providers.users.model', \App\Partners::class);
    }



      public function sales($id)
      {

        if ($id) {
          try {
            $partner_sales = DB::table('partner_payments')
               ->join('payments', 'partner_payments.payment_id', '=', 'payments.id')
               ->join('partners', 'partner_payments.partner_id', '=', 'partners.id')
               ->join('payment_type', 'payments.pay_type', '=', 'payment_type.id')
               ->where('partners.id', '=', $id, )
               ->where('payment_type.id', '=', '1', )
               ->sum('payments.pay_amount');

             $discount =    $partner_sales /100;
              $total = $partner_sales-$discount;

                return [

                  'response'=> array(
                      'partner_sales' =>$partner_sales,
                       'discount'   =>  $discount,
                       'total' =>   $total,
                      'status'=> '200',
                     )
                ];


        }catch(Throwable $e) {
            report($e);

            return false;
          }



          // return response()->json(compact('token', ));
      }

  }







}
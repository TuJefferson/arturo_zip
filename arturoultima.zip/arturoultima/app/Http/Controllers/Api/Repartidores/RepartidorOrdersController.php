<?php

namespace app\Http\Controllers\Api\Repartidores;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use Redirect;
use DB;
use App\Orders;
use App\Partners;
use App\Products;
use App\DeliveryMan;
use Config;
use Response;
use Carbon\Carbon;
class RepartidorOrdersController extends Controller
{


   public function __construct()
      {
          Config::set('jwt.user', 'App\DeliveryMan');
            Config::set('auth.providers.users.model', \App\DeliveryMan::class);
    }


      public function delivered($id)
      {

          if ($id) {
            try {
              $ordersDelivered = DB::table('orders')
                 ->join('products', 'orders.ord_prod_id', '=', 'products.id')
                 ->join('partners', 'products.prod_partner_id', '=', 'partners.id',)
                 ->join('orders_status_type', 'orders.ord_status', '=', 'orders_status_type.id')



                 ->where('orders.ord_status', '=', '4', )
                 ->where('partners.id', '=', $id, )
                 ->select('products.prod_name','orders.ord_price_bs','partners.p_user','partners.p_phone_1','orders_status_type.status_name')
                 ->get();

                  return [

                    'response'=> array(
                        'ordersDelivered' =>$ordersDelivered,
                        'status'=> '200',
                       )
                  ];


          }catch(Throwable $e) {
              report($e);

              return false;
            }

        }

      }

       public function orders()
        {

          // $matchThese = ['orders.ord_status' => '0',];
            try {
             $orders = DB::table('orders')

                 ->join('orders_status_type', 'orders.ord_status', '=', 'orders_status_type.id')   
                 ->join('clients_address', 'orders.ord_address', '=', 'clients_address.id')
                 ->join('address', 'clients_address.ca_address_id', '=', 'address.id')
                 ->join('aviable_zones','address.zon_id', '=','aviable_zones.id')
                 ->join('clients', 'clients_address.ca_cl_id', '=', 'clients.id')
                 ->join('municipios', 'address.mun_id', '=', 'municipios.id')
                 ->select(
                    'orders.id',
                    'orders.created_at',
                    'orders.bank_name',
                    'orders.zelle_name',
                    'orders.pay_by_zelle',
                    'orders.zelle_email',
                    'orders.ref_pay',
                    'clients.cl_name',
                    'clients.cl_email',
                    'orders_status_type.status_name',
                    'orders.ord_status AS ord_status',
                    'address.description AS address_description',

                    'municipios.mun_name AS municipio',
                    'aviable_zones.zone_name AS zone_name'
                 )
                 ->where('orders.ord_status', '=', 3)
                  // ->groupBy('order_items.id')
                  ->orderBy('orders.created_at', 'desc')
                ->get();

                  return [

                    'response'=> array(
                        'aviable_orders' =>$orders,
                        'status'=> '200',
                       )
                  ];


          }catch(Throwable $e) {
              report($e);

              return false;
            }

     

    }

    public function orderDetail($id){

      $order = Orders::find($id);
      // dd($order);



      if ($order) {

        try {
              $order = DB::table('orders')
                ->join('orders_status_type', 'orders.ord_status', '=', 'orders_status_type.id')
                ->join('clients_address', 'orders.ord_address', '=', 'clients_address.id')
                ->join('address', 'clients_address.ca_address_id', '=', 'address.id')
                 ->join('aviable_zones','address.zon_id', '=','aviable_zones.id')
                 ->join('clients', 'clients_address.ca_cl_id', '=', 'clients.id')
                 ->join('municipios', 'address.mun_id', '=', 'municipios.id')
                  ->where('orders.id', '=', $order->id) 
                  ->select('orders.id AS ord_id',
                    'orders.ord_description', 
                    'orders.ord_status',
                    'orders.order_time',
                    'orders.ref_pay',
                    'clients.cl_name',
                    'clients.cl_email',
                    'clients.cl_phone_1',
                    'clients.cl_phone_2',
                    'clients.id AS cl_id',
                    'orders_status_type.status_name',
                    'orders.ord_status AS ord_status',
                    'address.description AS address_description',
                    'address.address_lon AS address_lon',
                    'address.address_lat AS address_lat',
                    'municipios.mun_name AS municipio',
                    'aviable_zones.zone_name AS zone_name',
                    'orders.ord_description AS ord_description',
                    'orders.order_time',
                    'orders.order_approved'
                    )
                  ->first();

                    $order_aproved = Carbon::parse($order->order_approved)->format('d-m-Y H:i');
                    $order->order_approved = $order_aproved;
                    $order->current_time = Carbon::now()->format('d-m-Y H:i');


                  $order_productos = DB::table('order_items')
                    ->join('products', 'order_items.prod_id', '=', 'products.id')
                    ->join('partners', 'products.prod_partner_id', '=', 'partners.id')
                    ->where('order_items.ord_id', '=', $order->ord_id )
                    ->select('products.prod_name','products.prod_price_usd',
                          'products.prod_description',
                          'products.prod_image'
                          )
                    ->get();

                    $order_partner =  DB::table('order_items')
                    ->join('products', 'order_items.prod_id', '=', 'products.id')
                    ->join('partners', 'products.prod_partner_id', '=', 'partners.id')
                    ->where('order_items.ord_id', '=', $order->ord_id )
                    ->select('partners.p_user',
                          'partners.profile_pic',
                          'partners.id AS p_id'
                          )
                    ->first();
                      return [
                              'status'=> '200',
                              'response'=> array(
                              'order_partner' => $order_partner,
                              'order' =>$order,
                              'order_productos' => $order_productos,
                            )
                        ];
          
        } catch (Exception $e) {

           return response([
                      'status' => 'error',
                      'msg' => 'Ha ocurrido un error por favor intenta de nuevo']);
        }
      
      }else{
         return [
                'status'=> '200',
                'response'=> array(
                'error' =>'orden no encontrada',
             )
        ];

       }
    }


    public function acceptOrder(Request $request){


             $order = Orders::find($request->ord_id);

             if ($order) {

                if ($request->ord_status == 0) {
                      if($order->ord_dm_id)
                            {
                              return [
                                      'status'=> '300',
                                      'response'=> array(
                                       'error' => 'orden ya tiene repartidor',
                                       
                                      )
                                  ];
                            }else{
                                 $order->ord_dm_id = $request->dm_id;
                                 $order->ord_status = $request->ord_status;
                                 $order->save();
                                 return [
                                      'status'=> '200',
                                      'response'=> array(
                                        'order' =>$order,
                                        'msg' => 'actualizado status con exito'
                                      )
                                  ];
                            }
                }
                if ($request->ord_status == 5) {
                     if($order->ord_dm_id)
                            {
                              
                                  $order->ord_dm_id = $request->dm_id;
                                 $order->ord_status = $request->ord_status;
                                 $order->save();
                                 return [
                                      'status'=> '200',
                                      'response'=> array(
                                        'order' =>$order,
                                        'msg' => 'actualizado status con exito'
                                      )
                                  ];
                            }else{
                                return [
                                      'status'=> '300',
                                      'response'=> array(
                                        'error' => 'orden no tiene repartidor',
                                       
                                      )
                                  ]; 
                            } 
                }

                if ($request->ord_status == 4) {
                     if($order->ord_dm_id)
                            {
                              
                                  $order->ord_dm_id = $request->dm_id;
                                 $order->ord_status = $request->ord_status;
                                 $order->save();
                                 return [
                                      'status'=> '200',
                                      'response'=> array(
                                        'order' =>$order,
                                        'msg' => 'actualizado status con exito'
                                      )
                                  ];
                            }else{
                                return [
                                      'status'=> '300',
                                      'response'=> array(
                                        'error' => 'orden no tiene repartidor',
                                       
                                      )
                                  ]; 
                            } 
                }

             }else
             {
                return [
                         'status'=> '400',
                         'response'=> array(
                         'error' => 'orden no encontrada')
                 ];
             }
            



    }

    public function CurrentOrders($id){

            $orders = DB::table('orders')
            ->where('ord_dm_id','=',$id)
            ->where('ord_status','!=',4)
            ->get();
                        return [
                              'status'=> '200',
                              'response'=> array(
                              'orders' =>$orders,

                            )
                        ];
    }

    public function OrderWasDelivered(Request $request){


             $order = Orders::find($request->ord_id);

             if ($order->ord_status = 4) {
                    $order->ord_dm_id = $request->dm_id;
                    $order->ord_status = 4;
                    $order->save();
                   // return back();

                    return [
                              'status'=> '200',
                            'response'=> array(
                              'order' =>$order,
                              'msg' => 'orden entrega al cliente con exito'
                            )
                        ];
                }
            else{
                return response()->json('error');
            }

    }



    public function OrdersDelivered($id)
      {

          if ($id) {
            try {
              $ordersDelivered = DB::table('orders')

                 ->join('orders_status_type', 'orders.ord_status', '=', 'orders_status_type.id')   
                 ->join('clients_address', 'orders.ord_address', '=', 'clients_address.id')
                 ->join('address', 'clients_address.ca_address_id', '=', 'address.id')
                 ->join('aviable_zones','address.zon_id', '=','aviable_zones.id')
                 ->join('clients', 'clients_address.ca_cl_id', '=', 'clients.id')
                 ->join('municipios', 'address.mun_id', '=', 'municipios.id')
                 ->join('delivery_man', 'orders.ord_dm_id', '=', 'delivery_man.id')
                 ->select(
                    'orders.id',
                    'orders.created_at',
                    'orders.bank_name',
                    'orders.zelle_name',
                    'orders.pay_by_zelle',
                    'orders.zelle_email',
                    'orders.ref_pay',
                    'clients.cl_name',
                    'clients.cl_email',
                    'orders_status_type.status_name',
                    'orders.ord_status AS ord_status',
                    'address.description AS address_description',
                    'municipios.mun_name AS municipio',
                    'aviable_zones.zone_name AS zone_name'
                 )
                 ->where('orders.ord_status', '=', 4)
                 ->where('orders.ord_dm_id', '=', $id)
                 ->orderBy('created_at', 'desc')
                ->get();


                  return [

                    'response'=> array(
                        'status'=> '200',
                        'ordersDelivered' =>$ordersDelivered,
                       )
                  ];


          }catch(Throwable $e) {
              report($e);

              return false;
            }

        }

      } 



}
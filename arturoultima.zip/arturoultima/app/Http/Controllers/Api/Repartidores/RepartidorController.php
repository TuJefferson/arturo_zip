<?php

namespace app\Http\Controllers\Api\Repartidores;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use Redirect;
use DB;
use App\Orders;
use App\Partners;
use App\Products;
use App\DeliveryMan;
use Config;
use Response;

class RepartidorController extends Controller
{


		public function __construct()
	    {
			    Config::set('jwt.user', 'App\DeliveryMan');
	        	Config::set('auth.providers.users.model', \App\DeliveryMan::class);
		}



      public function authenticate(Request $request)
	    {

			$credentials = $request->only('dm_email', 'password');
	        try {
	            if (! $token = JWTAuth::attempt($credentials)) {
	                return response()->json(['error' => 'Usuario o clave incorrecta'], 400);
	            }else{
	            	 $delivery_man = DB::table('delivery_man')
	        			->where('delivery_man.dm_email', '=', $request->dm_email)
	       			    ->select('delivery_man.dm_name', 
                                 'delivery_man.dm_profile_pic', 
                                 'delivery_man.dm_email',
                                 'delivery_man.dm_last_name',
                                 'delivery_man.dm_phone_1',
                                 'delivery_man.id')
	        		 ->first();
	            }
	        } catch (JWTException $e) {
	            return response()->json(['error' => 'could_not_create_token'], 500);
	        }
	        return [

                'token' => $token,
                'response'=> array(
                    'status'=> '200',
                    'partner_info' =>$delivery_man,
                    'dm_avatar'=> asset('images/repartidores/'.$delivery_man->id.'/'.$delivery_man->dm_profile_pic),

            )];
	    }




    public function getAuthenticatedUser()
	    {
	        try {
	            if (!$user = JWTAuth::parseToken()->authenticate()) {
	                    return response()->json(['user_not_found'], 404);
	            }
	            } catch (Tymon\JWTAuth\Exceptions\TokenExpiredException $e) {
	                    return response()->json(['token_expired'], $e->getStatusCode());
	            } catch (Tymon\JWTAuth\Exceptions\TokenInvalidException $e) {
	                    return response()->json(['token_invalid'], $e->getStatusCode());
	            } catch (Tymon\JWTAuth\Exceptions\JWTException $e) {
	                    return response()->json(['token_absent'], $e->getStatusCode());
	            }
	            return response()->json(compact('user'));
	    }

    public function logout(Request $request){

    	$this->validate($request, ['token' => 'required']);

    	try{
    		 JWTAuth::invalidate($request->input('token'));
    		 return response([
    		 	'status' => 'success',
    		 	'msg' => 'Has cerrado sesión']);

    	   }
    	   catch(JWTException $e) {
    	   		 return response([
    	   		 	'status' => 'error',
    	   		 	'msg' => 'Ha ocurrido un error por favor intenta de nuevo']);
    	   }
    }

    public function refresh(){
          return response([
          	'status' => 'success'
          ]);
      }


     public function RateDm($id)
     {

    	$dm = DeliveryMan::find($id);

    	if ($dm) {
    		try {
    			$total_orders = DB::table('orders')
    	  			->join('delivery_man', 'delivery_man.id', '=', 'orders.ord_dm_id')
                    ->where('orders.ord_dm_id', '=', $dm->id)
                    ->count();

    	  			$orders_rates_total = DB::table('orders')
    	  			->join('delivery_man', 'delivery_man.id', '=', 'orders.ord_dm_id')
                     ->where('orders.ord_dm_id', '=', $dm->id)
                    ->sum('orders.ord_rate');
    				$prom = $orders_rates_total / $total_orders;
    				 return [
		                'response'=> array(
		                    'status'=> '200',
		                    'prom' => $prom
		                )
            		];
    		} catch (Exception $e) {
    				 return response([
    	   		 	'status' => 'error',
    	   		 	'msg' => $e]);
    		}
    	}else
    	{
    			return [
		                'response'=> array(
		                    'status'=> '400',
		                    'msg' => 'socio no encontrado'
		                )
            		];
    	}
    }  

}
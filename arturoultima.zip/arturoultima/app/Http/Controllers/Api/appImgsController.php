<?php

namespace app\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Redirect;
use Config;
use Response;

class appImgsController extends Controller
{


      public function logoVerde()
	    {

				return response()->file('appImgs/verde.png');
	    }
	    public function logoVerdePerfil()
	    {

				return response()->file('appImgs/imgBlanca.png');
	    }
	   public function LogoBlanco()
	    {

				return response()->file('appImgs/blanco.png');

	    }

	    public function LogoNegro()
	    {

				return response()->file('appImgs/negro.png');

	    }

	    public function partnerBanner()
	    {

				return response()->file('appImgs/partnerbanners/negro.png');

	    }
	    public function partnerBanner1()
	    {

				return response()->file('appImgs/partnerbanners/mac.jpg');

	    }

	      public function menuBar()
			    {
						return response()->file('appImgs/partnerbanners/open-menu(1).png');

			    }
}
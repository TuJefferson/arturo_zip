<?php

namespace app\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use Redirect;
use DB;
use App\Orders;
use App\Partners;
use App\Products;
use App\DeliveryMan;
use Config;
use Response;

class PartnerOrdersDeliveredController extends Controller
{


    public function __construct()
      {
          Config::set('jwt.user', 'App\Partners');
            Config::set('auth.providers.users.model', \App\Partners::class);
    }



      public function delivered($id)
      {

          if ($id) {
            try {
              $ordersDelivered = DB::table('orders')
                 ->join('products', 'orders.ord_prod_id', '=', 'products.id')
                 ->join('partners', 'products.prod_partner_id', '=', 'partners.id',)
                 ->join('orders_status_type', 'orders.ord_status', '=', 'orders_status_type.id')



                 ->where('orders.ord_status', '=', '4', )
                 ->where('partners.id', '=', $id, )
                 ->select('products.prod_name','orders.ord_price_bs','partners.p_user','partners.p_phone_1','orders_status_type.status_name')
                 ->get();

                  return [

                    'response'=> array(
                        'ordersDelivered' =>$ordersDelivered,
                        'status'=> '200',
                       )
                  ];


          }catch(Throwable $e) {
              report($e);

              return false;
            }

        }

      }

  //      public function orders($id)
  //       {

  //         if ($id) {
  //           try {
  //             $orders = DB::table('orders')
  //                ->join('products', 'orders.ord_prod_id', '=', 'products.id')
  //                ->join('partners', 'products.prod_partner_id', '=', 'partners.id')
  //                ->join('clients_address', 'orders.ord_address', '=', 'clients_address.id')
  //                ->join('address', 'clients_address.ca_address_id', '=', 'address.id')
  //                ->join('municipios', 'address.mun_id', '=', 'municipios.id')
  //                ->join('orders_status_type', 'orders.ord_status', '=', 'orders_status_type.id')
  //                ->where('partners.id', '=', $id, )
  //                ->where('orders.status', '=', 2 )
  //                ->select('products.prod_name',
  //                 'orders.ord_price_bs',
  //                 'partners.p_user','partners.p_phone_1',
  //                 'orders_status_type.status_name',
  //                 'orders.ord_description',
  //                 'ord_dm_id',
  //                 'orders.ord_address',
  //                 'address.description',
  //                 'municipios.mun_name')
  //                ->get();

  //                 return [

  //                   'response'=> array(
  //                       'partner_orders' =>$orders,
  //                       'status'=> '200',
  //                      )
  //                 ];


  //         }catch(Throwable $e) {
  //             report($e);

  //             return false;
  //           }

  //     }

  // }







}
<?php

namespace app\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Redirect;
use Config;
use Response;
use App\DeliveryPrice;
use App\Currencies;
use App\AviableZones;
use DB;
class DeliveryPriceController extends Controller
{


      public function deliveryPrice(Request $request)
	    {


	    	$distance =  $request->distance;

	    	if ($distance) {
       					try {
       							$d_price = DB::table('delivery_price')
						            ->select('delivery_price.delivery_price', 'delivery_price.id', DB::raw("ABS(distance - $distance) AS distance"))  
						            ->orderBy('distance')
						            ->first(); 
						            // dd($d_price);
						            return [
					                	'response'=> array(
					                    'd_price' =>$d_price,
					                    'status'=> '200',
				                		)
            						];

       					} catch (Exception $e) {
       						 return [
					                	'response'=> array(
					                    'error' => $e,
					                    'status'=> '300',
				                		)
            						];	
       					}
    		}



      //  		$d_prices =  DeliveryPrice::all();

	    	// dd($d_prices);
        	

        // return ['status' => '200', 'response' => array(
        //     'app_percentage' => $app_percentage,
        // ) ];

	  //   	$d_price = DB::table('aviable_zones')
	  //   				->where('aviable_zones.id', '=', $id)
	  //   				->get();
	  //   	// find($id);
	  //   				// dd($d_price);
	  //   	if ($d_price) {
	  //   		$d_price = DB::table('aviable_zones')
	  //   					->where('aviable_zones.id', '=', $id)
	  //   					->select('delivery_price_usd','zone_name')
	  //   				->first();
			// 	 return [
	  //               	'response'=> array(
	  //                   'd_price' =>$d_price,
	  //                   'status'=> '200',
   //              		)

   //          	];
	  //   	}else{

			// 	return response()->json(['error'=>  'zona no encontrada']);
			// }
	    				



	    }

	     public function currencyValue()
	    {


	    	$usd = Currencies::where('id','=', '1')
	    	->select('cur_name','cur_value')
	    				->first();
	       return [
                	'response'=> array(
                    'c_price' =>$usd,
                    'status'=> '200',
                )

            ];


	    }

	   
}
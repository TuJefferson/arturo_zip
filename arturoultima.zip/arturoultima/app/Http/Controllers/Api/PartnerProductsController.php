<?php

namespace app\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use Redirect;
use DB;
use App\Orders;
use App\Partners;
use App\Products;
use App\DeliveryMan;
use Config;
use Response;

class PartnerProductsController extends Controller
{


		public function __construct()
	    {
			    Config::set('jwt.user', 'App\Partners');
	        	Config::set('auth.providers.users.model', \App\Partners::class);
		}



      public function products($id)
	    {

	    	if ($id>1)
	    	 {
			    		try {
			    		  $partner_products = DB::table('partners')
			             ->join('products', 'products.prod_partner_id', '=', 'partners.id')
			             ->where('products.prod_partner_id', '=', $id, )
			             ->whereNull('products.deleted_at')
			             ->get('products.*');

			              return [

		                	'response'=> array(
		                    	'partner_products' =>$partner_products,
		                    	'status'=> '200',
		               			 )
		            		];


			    	}catch(Throwable $e) {
		        		report($e);

		        		return false;
		    			}

	   		 }

		}

	 public function productInfo($id)
	    {

	    	if ($id>1)
	    	 {
	    	 	// dd('asda');
			    		try {
			    		  $products_info = DB::table('products')
			             ->where('products.id', '=', $id, )
			             ->whereNull('products.deleted_at')
			             ->first();

			              return [

		                	'response'=> array(
		                    	'products_info' =>$products_info,
		                    	'status'=> '200',
		               			 )
		            		];


			    	}catch(Throwable $e) {
		        		report($e);

		        		return false;
		    			}

	   		 }

		}

		public function newPriceProducts(Request $request)
	    {

	    	 $product = Products::find($request->id);
	    	if ($product != null)
	    	 {
			    		try {
				    		$product->prod_price_usd = $request->prod_price_usd;
	                		$product->save();
			              return [

		                	'response'=> array(
		                    	'product' => 'precio actualizado',
		                    	'status'=> '200',
		               			 )
		            		];


			    	}catch(Throwable $e) {
		        		report($e);

		        		return false;
		    			}

	   		 }else{
	   		 	  return [

		                	'response'=> array(
		                    	'status'=> 'error',
		                    	'product' =>' no existe',
		               			 )
		            		];
	   		 }

		}

		public function productAviable(Request $request)
		    {

		    	 $product = Products::find($request->prod_id);
		    	if ($product != null)
		    	 {
				    		try {
					    		$product->prod_aviable = $request->prod_aviable;
		                		$product->save();
				              return [

			                	'response'=> array(
			                    	'product' => 'producto actualizado',
			                    	'status'=> '200',
			               			 )
			            		];


				    	}catch(Throwable $e) {
			        		report($e);

			        		return $e;
			    			}

		   		 }else{
		   		 	  return [

			                	'response'=> array(
			                    	'status'=> 'error',
			                    	'product' =>' producto no existe',
			               			 )
			            		];
		   		 }

			}
    public function refresh(){
          return response([
          	'status' => 'success'
          ]);
      }




}
<?php

namespace App\Http\Controllers\Api\Clients;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use GuzzleHttp\Client;
use App\CategoriesPartners;
use DB;
use App\Partners;
use Carbon\Carbon;
class SearchByCatController extends Controller
{


      public function searchByCategory($id) {


      	 $date = Carbon::now()->format('H:i');
      	 // dd($date);
          	$categories = CategoriesPartners::find($id);
          	// dd($categories);
          	 if ($categories) {

		         	try {
							$parterByCat = DB::table('categories')
					        ->join('partners','partners.p_cat_id', '=','categories.id')
					        ->where('categories.id','=',$id)
					        ->whereNull('partners.deleted_at')
					        ->select('partners.p_user',
					        	'partners.p_rif',
					        	'partners.id',
					        	'partners.p_description',
					        	'partners.p_shipping',
					        	'partners.profile_pic',
					        	'partners.p_rate',
					        	'partners.p_close_time',
					        	'partners.p_open_time',
					        	'partners.p_lat',
					        	'partners.p_lng',
					        	'partners.p_is_close',
					            'categories.cat_name')
					        ->get();

					        foreach ($parterByCat as $p_cat) {


					        	if ($p_cat->p_is_close == 1) {
					        		$is_open = false;
								    $p_cat->is_open = $is_open;
					        	}else{

					        		if ($date > $p_cat->p_open_time && $date < $p_cat->p_close_time  ) {
								        		# code...
								       	$is_open = true;

								       	$p_cat->is_open = $is_open;
								   		// dd('abierto');
								       }else{
								       	$is_open = false;
								       	 	$p_cat->is_open = $is_open;
								   	   }  

					        	}
								   
					        }

		         	 	 return [
		                	'response'=> array(
		                    	'parterByCat' => $parterByCat,
		                    	'status'=> '200',
		               			 )
		            		];
		    		}catch (Throwable $e) {
		       			return response()->json(['error'=>  report($e)]);
		    		}
            }else{
            	return response()->json(['error'=>  'orden ya registrada']);
            }

      }

     public function showPartner($id)
     {

     	 $partner_id = DB::table('partners')
					        ->where('partners.id','=',$id)
					        ->first();

					        $date = Carbon::now()->format('H:i');
     		
     			 if ($partner_id) {

		         	try {
							$partner = DB::table('partners')
					        ->where('partners.id','=',$partner_id->id)
					        ->select('partners.p_user',
					        	'partners.p_rif',
					        	'partners.id AS p_id',
					        	'partners.p_description',
					        	'partners.p_shipping',
					        	'partners.profile_pic',
					        	'partners.p_rate',
					        	'partners.p_close_time',
					        	'partners.p_open_time',
					        	'partners.percent_amount',
					        	'partners.p_lat',
					        	'partners.p_lng',
					        	'partners.p_is_close',
					        	'partners.percent_up'
					        )
					        ->first();

					   		if ($partner->p_is_close == 1) {
					        		$is_open = false;
								    $partner->is_open = $is_open;
					        	}else{

					        		if ($date > $partner->p_open_time && $date < $partner->p_close_time  ) {
								        		# code...
								       	$is_open = true;

								       	$partner->is_open = $is_open;
								   		// dd('abierto');
								       }else{
								       	$is_open = false;
								       	 	$partner->is_open = $is_open;
								   	   }  

					        	}	
     


						$partner_products = DB::table('products')
							->join('partners','products.prod_partner_id', '=','partners.id')
							->where('products.prod_partner_id', '=', $partner->p_id)
							->whereNull('products.deleted_at')
							->select('products.prod_name',
									 'products.id',
									 'products.prod_partner_id',
									 'products.prod_price_usd',
									 'products.prod_recome',
									 'products.prod_category',
									 'products.prod_image',
									 'products.prod_seg_id',
									 'products.prod_aviable',
									 'products.prod_description',
									 'products.prod_suges')
							->get();
							


								if ($partner->percent_up == 'on') {
										foreach ($partner_products as $prod) {
										 	$prod_price_usd = $prod->prod_price_usd;
											$percent_value = $partner->percent_amount;
											$products_percent = round($percent_value*$prod_price_usd / 100,4);
											$sum =  $prod_price_usd	+ $products_percent;

												if ($prod->prod_aviable == 1) {
													$prod_aviable = true;
												}else{
													$prod_aviable = false;
												}
											$prod->prod_aviable = $prod_aviable;	
											$prod->prod_price_usd = $sum;
									}
								}else{

									foreach ($partner_products as $prod) {
										 	$prod_price_usd = $prod->prod_price_usd;
											$sum =  $prod_price_usd;

											if ($prod->prod_aviable == 1) {
													$prod_aviable = true;
												}else{
													$prod_aviable = false;
												}
											$prod->prod_aviable = $prod_aviable;	
											$prod->prod_price_usd = $sum;
									}							
								}


						$total_orders = DB::table('orders')
			    	  			->join('order_items', 'order_items.ord_id', '=', 'orders.id')
			                    ->join('products', 'order_items.prod_id', '=', 'products.id')
			                    ->join('partners', 'products.prod_partner_id', '=', 'partners.id',)
			                    ->where('partners.id', '=', $partner->p_id)
			                    ->count();


			              if($total_orders == 0){

			              		$prom_rate = 0;
			              }else{

    	  					$orders_rates_total = DB::table('orders')
    	  						->join('order_items', 'order_items.ord_id', '=', 'orders.id')
                    			->join('products', 'order_items.prod_id', '=', 'products.id')
                    			->join('partners', 'products.prod_partner_id', '=', 'partners.id',)
                   			    ->where('partners.id', '=', $partner->p_id)
                                ->sum('orders.ord_rate');

    				         	 $prom = $orders_rates_total / $total_orders;		

    				           if($prom < 1){
    				           		$prom_rate = 0;
    				           }else{
    				           	  $prom_rate =  round($prom, 2);
    				           }	
			              }    


		         	 	 return [
		                	'response'=> array(
		                    	'partner' => $partner,
		                    	'partner_products' => $partner_products,
		                    	'partner_banner'=> asset('images/socios/'.$partner->p_id.'/'.$partner->profile_pic),
		                    	'prom_rate' => $prom_rate,
		                    	'status'=> '200',
		               			 )
		            		];


		    		}catch (Throwable $e) {
		       			return response()->json(['error'=>  report($e)]);
		    		}
            }else{
            	return response()->json(['error'=>  'socio no encontrado']);
            }
     }


      public function searchByParam($name) {

          		$results = DB::table('partners')
          					->join('products','products.prod_partner_id', '=','partners.id')
							->whereNull('products.deleted_at')
							->whereNull('partners.deleted_at')
          					->where('partners.p_user', 'like', "%{$name}%")
          					->orWhere('products.prod_name', 'like', "%{$name}%")
          			->select('partners.p_user',
					        	'partners.p_rif',
					        	'partners.id AS p_id',
					        	'partners.p_description',
					        	'partners.p_shipping',
					        	'partners.profile_pic',
					        	'partners.p_rate',
					        	'partners.p_close_time',
					        	'partners.p_open_time',
					        	'products.*'
					        )
          			->get();


          			if(sizeof($results) > 0){
          						 return [
		                	'response'=> array(
		                    	'results' => $results,
		                    	'status'=> '200',
		               			 )
		            		];
          			}else{
            			return response()->json(['error'=>  'no se encontraron resultados']);
          		  }
      }
}

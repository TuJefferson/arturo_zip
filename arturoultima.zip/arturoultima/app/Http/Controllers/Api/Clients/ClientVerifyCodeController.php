<?php

namespace App\Http\Controllers\Api\Clients;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use GuzzleHttp\Client;


class ClientVerifyCodeController extends Controller
{


      public function sendcode(Request $request) {

          	// dd($request->phone);
         	  $client = new Client();


	        $res = $client->request('GET', 'https://mensajesms.com.ve/sms2/API/api.php', [
	            'params' => [
	                'cel' => $request->phone,
	                'men' => 'controlador',
	                'u' => 'LUISEMILIOH',
	                't' => '74772d4',
	                'tr' => 'json',
	            ]
	        ]);
	         echo $res->getStatusCode();
        // 200
        echo $res->getHeader('content-type');
        // 'application/json; charset=utf8'
        echo $res->getBody();
      }
}

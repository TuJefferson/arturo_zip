<?php

namespace App\Http\Controllers\Api\Clients;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use GuzzleHttp\Client;
use App\Segmentatios;

class SegmentatiosController extends Controller
{


      public function segmentatios() {
      		$segmentos = Segmentatios::select('id','seg_description')->get();
      		 if ($segmentos) {
      		 		 try {
	      		 		return [
		                	'response'=> array(
		                    	'status'=> '200',
		                    		'segmentos' => $segmentos,
		               			 )
		            		];
	      		 	} catch (Exception $e) {
	      		 			return response()->json(['error'=>  'no se han encontrado resultados']); 
	      		  }
      		 	}else{

      		 		return response()->json(['error'=>  'algo a pasado']); 
      		 	}
	      		

      }
     
}

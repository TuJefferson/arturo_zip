<?php

namespace App\Http\Controllers\Api\Clients;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use GuzzleHttp\Client;
use App\Products;
use DB;

class ClientProductsController extends Controller
{


      public function allProducts() {

          	// dd($request);
          	$all_products = DB::table('products')->get();

         	 // dd($all_products);
          	 if ($all_products) {

		         	try {

		         	 	return [

		                	'response'=> array(
		                    	'all_products' =>$all_products,
		                    	'status'=> '200',
		               			 )
		            		];
		    		}catch (Throwable $e) {
		       			return response()->json(['error'=>  report($e)]);
		    		}
            }
      }
       public function ProductExtra($id) {
       	 $product = Products::find($id);
       	 // dd($product);
       	 	if ($product) {
       	 	
		         	try {
		         			$prod_extras = DB::table('prod_extras')
          					->join('products','prod_extras.prod_id', '=','products.id')
          				 	->where('products.id', '=', $id)
          				 	->whereNull('prod_extras.deleted_at')
          					->select('prod_extras.id AS extra_id',
          					 'prod_extras.pe_name AS extra_name', 
          					 'prod_extras.pe_price_usd AS extra_price_usd',
          					  'prod_extras.prod_type AS extra_type', 
          					  'products.id AS product_id' )
         	 				->get();
		         	 	return [

		                	'response'=> array(
		                    	'status'=> '200',
		                    	'prod_extras' =>$prod_extras,
		               			 )
		            		];
		    		}catch (Throwable $e) {
		       			return response()->json(['error'=>  report($e)]);
		    		}
       	 	}else{

                return response()->json(['error'=>  'producto no existe o a ocurrido un problema']);
            }

      }


}

<?php
namespace App\Http\Controllers\Api\Clients;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use GuzzleHttp\Client;
use App\Orders;
use App\Payments;
use App\OrderItems;
use DB;
use App\Products;
use App\ProductsExtras;
use App\OrderItemsExtra;
use App\Currencies;
use Carbon\Carbon;
use App\UsageAppPercentage;
use Illuminate\Support\Facades\Log;
class ClientNewOrderController extends Controller
{

    public function storeOrderClient(Request $request)
    {
        $entrada = $request->all();


        $entrada_json = json_encode($request->all());


       


        $order = DB::table('orders')->where('orders.ref_pay', '=', $request->ref_pay)
            ->select('orders.id')
            ->first();
        $cur_value = Currencies::select('cur_name', 'cur_value')->first();
        $app_percentage = UsageAppPercentage::first();
          // dd($app_percentage->use_percentage);
        if (!$order)
        {

            try
            {

                if ($request->hasFile('ref_pay_image'))
                {

                    $client_id = DB::table('clients_address')
                        ->where('clients_address.id', '=', $request->ord_address)
                        ->select('clients_address.ca_cl_id')
                        ->first();

                    $order_file = $request->file('ref_pay_image');
                    $path = public_path() . '/images/orders/client_id/' . $client_id->ca_cl_id;
                    $fileName = uniqid() .'.'.'jpg';

                    $order_file->move($path, $fileName);

                    $productsjson = json_decode($request->products);
                    $ord_total_price_usd = 0;
                    $ord_total_price_bs = 0;
                    $dot[] = ',';
                    $point[] = '.';

                    foreach ($productsjson as $ord_prod)
                    {

                        $prod = DB::table('products')
                            ->join('partners','products.prod_partner_id', '=','partners.id')
                            ->where('products.id', '=', $ord_prod->prod_id)
                            ->select('products.id', 'products.prod_price_usd', 
                               'products.prod_partner_id',
                               'partners.id AS p_id', 
                               'partners.percent_up AS p_percent',
                               'partners.percent_amount AS p_percent_amount' )
                            ->first();
                         // dd($prod);   

                            //aplica porcentaje por arriba a los productos para monto total de orden. 
                              if ($prod->p_percent == 'on') {
                                      $prod_price_usd = $prod->prod_price_usd;



                                      $percent_value = $prod->p_percent_amount;


                                      $products_percent = round($percent_value*$prod_price_usd / 100,4);

                                      $prod_w_percent =  $prod_price_usd + $products_percent;
                                      $prod->prod_price_usd = $prod_w_percent;
                        
                              }







                        $prod_bs = str_replace($dot, $point, $prod->prod_price_usd) * $cur_value->cur_value;
                        $ord_total_price_usd += str_replace($dot, $point, $prod->prod_price_usd) * $ord_prod->quantity;


                        $ord_total_price_bs += $prod_bs * $ord_prod->quantity;

                        foreach ($ord_prod->extras as $prod_extra)
                        {
                            $extra = DB::table('prod_extras')
                                    ->where('prod_extras.id', '=', $prod_extra)
                                    ->select('prod_extras.id', 'prod_extras.pe_price_usd')
                                    ->first();
                            $extra_bs = str_replace($dot, $point, $extra->pe_price_usd) * $cur_value->cur_value;
                            $extra_price_usd = str_replace($dot, $point, $extra->pe_price_usd);
                            $extra_price_bs = str_replace($dot, $point, $extra_bs);

                            $ord_total_price_usd += $extra_price_usd;
                            $ord_total_price_bs += $extra_price_bs;

                        }

                    }
                    $date_order = Carbon::now()->format('H:i');

                    if ($date_order > '13:00')
                    {
                        $order_horario = 'pm';
                    }
                    else
                    {
                        $order_horario = 'am';
                    }

                    $order = new Orders;
                    $order->ord_status = '1';
                    $order->ord_address = $request->ord_address;
                    $order->ord_description = $request->ord_description;
                    $order->ref_pay = $request->ref_pay;
                    $order->ref_pay_image = $fileName;
                    $order->current_ex_price = $cur_value->cur_value;
                    $order->order_dm_val = $request->order_dm_val;
                    $order->order_use_percent = $app_percentage->use_percentage;
                    if ($request->pay_by_zelle == 1) {
                       $order->zelle_name = $request->zelle_name;
                       $order->pay_by_zelle = $request->pay_by_zelle;
                       $order->zelle_email = $request->zelle_email;
                       $order->order_amount_usd = $ord_total_price_usd;
                    }else{
                      $order->bank_name = $request->bank_name;
                      $order->bank_id = $request->bank_id;
                      $order->order_amount_bs = $ord_total_price_bs;

                    }                  
                    $order->order_horario = $order_horario;
                    $order->save();

                    foreach ($productsjson as $product)
                    {
                        $prod_extras = json_encode($product->extras);
                        $extras = json_decode($prod_extras);
                        $prod_id = $product->prod_id;
                        $quantity = $product->quantity;

                        $product = new OrderItems;
                        $product->ord_id = $order->id;
                        $product->prod_id = $prod_id;
                        $product->quantity = $quantity;
                        $product->order_partner_id = $prod->prod_partner_id;
                        $product->save();

                        if (count($extras) > 0)
                        {

                            foreach ($extras as $photo)
                            {
                                $photo_id_array[$photo] = ['order_items_extra_id' => $photo];
                            }
                            $product->OrderItemsExtra()
                                ->sync($photo_id_array, false);

                        }

                    }
                }

                  //orden sin imagen
                else
                {

                    $productsjson = json_decode($request->products);
                    $ord_total_price_usd = 0;
                    $ord_total_price_bs = 0;
                    $dot[] = ',';
                    $point[] = '.';

                     //foreach de productos para monto total de la orden
                    foreach ($productsjson as $ord_prod)
                    {

                        $prod = DB::table('products')
                            ->where('products.id', '=', $ord_prod->prod_id)
                            ->select('products.id', 'products.prod_price_usd', 'products.prod_partner_id')
                            ->first();

                        $prod_bs = str_replace($dot, $point, $prod->prod_price_usd) * $cur_value->cur_value;
                        $ord_total_price_usd += str_replace($dot, $point, $prod->prod_price_usd) * $ord_prod->quantity;
                        $ord_total_price_bs += $prod_bs * $ord_prod->quantity;

                        foreach ($ord_prod->extras as $prod_extra)
                        {
                            $extra = DB::table('prod_extras')
                                    ->where('prod_extras.id', '=', $prod_extra)
                                    ->select('prod_extras.id', 'prod_extras.pe_price_usd')
                                    ->first();
                            $extra_bs = str_replace($dot, $point, $extra->pe_price_usd) * $cur_value->cur_value;
                            $extra_price_usd = str_replace($dot, $point, $extra->pe_price_usd);
                            $extra_price_bs = str_replace($dot, $point, $extra_bs);

                            $ord_total_price_usd += $extra_price_usd;
                            $ord_total_price_bs += $extra_price_bs;

                        }

                    }
                    $date_order = Carbon::now()->format('H:i');

                    if ($date_order > '13:00')
                    {
                        $order_horario = 'pm';
                    }
                    else
                    {
                        $order_horario = 'am';
                    }

                    $order = new Orders;
                    $order->ord_status = '1';
                  
                    $order->ord_address = $request->ord_address;
                    $order->ord_description = $request->ord_description;
                    $order->ref_pay = $request->ref_pay;
                    $order->current_ex_price = $cur_value->cur_value;
                    $order->order_dm_val = $request->order_dm_val;
                    $order->order_use_percent = $app_percentage->use_percentage;
                     if ($request->pay_by_zelle == 1) {
                       $order->zelle_name = $request->zelle_name;
                       $order->pay_by_zelle = $request->pay_by_zelle;
                       $order->zelle_email = $request->zelle_email;
                       $order->order_amount_usd = $ord_total_price_usd;
                    }else{
                      $order->bank_name = $request->bank_name;
                      $order->bank_id = $request->bank_id;
                      $order->order_amount_bs = $ord_total_price_bs;

                    }
                    $order->order_horario = $order_horario;
                    $order->save();

                    $productsjson = json_decode($request->products);

                    foreach ($productsjson as $product)
                    {
                        $prod_extras = json_encode($product->extras);
                        // $extras = $product->extras;
                        $extras = json_decode($prod_extras);
                        $prod_id = $product->prod_id;
                        $quantity = $product->quantity;

                        $product = new OrderItems;
                        $product->ord_id = $order->id;
                        $product->prod_id = $prod_id;
                        $product->quantity = $quantity;
                        $product->order_partner_id = $prod->prod_partner_id;
                        $product->save();

                        if (count($extras) > 0)
                        {

                            foreach ($extras as $photo)
                            {
                                $photo_id_array[$photo] = ['order_items_extra_id' => $photo];
                            }
                            $product->OrderItemsExtra()
                                ->sync($photo_id_array, false);

                        }
                    }
                }

                return ['response' => array(
                    'order' => $order,
                    'status' => '200',
                    'json_entrada' => $entrada
                ) ];
            }
            catch(Throwable $e)
            {
                return response()->json(['error' => report($e) ]);
            }
        }
        else
        {
            return response()->json(['error' => 'orden ya registrada']);
        }

    }
}


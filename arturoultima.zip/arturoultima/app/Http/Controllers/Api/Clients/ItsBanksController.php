<?php
namespace app\Http\Controllers\Api\Clients;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Redirect;
use Config;
use Response;
use App\ItsBanks;
use App\UsageAppPercentage;
use App\DeliveryPrice;
use App\BanksPlatforms;
class ItsBanksController extends Controller
{

    public function banks()
    {

        $banks = ItsBanks::all();

        return ['status' => '200', 'response' => array(
            'banks' => $banks,
        ) ];
    }

    public function appPercentage()
    {

        $app_percentage = UsageAppPercentage::first();
        return ['status' => '200', 'response' => array(
            'app_percentage' => $app_percentage,
        ) ];
    }
   

     public function banks_platforms()
    {

        $banks_platforms = BanksPlatforms::select('id',
            'method',
            'bank_person',
            'bank_name',
            'bank_account',
            'bank_dni',
            'type_method',
            'account_type',
            'qr')->get()->groupBy('type_method');




        return ['status' => '200', 
                'response' => array(
                'banks' => $banks_platforms,
                'bancaribe_qr'=> asset('appImgs/qr-bancaribe.png'),
        ) ];
    }
}

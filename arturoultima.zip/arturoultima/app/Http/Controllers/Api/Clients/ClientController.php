<?php
namespace App\Http\Controllers\Api\Clients;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use GuzzleHttp\Client;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use Redirect;
use DB;
use App\Orders;
use App\Partners;
use App\Products;
use App\DeliveryMan;
use Config;
use Response;
use App\Clients;
use App\AviableZones;
use App\Address;
use App\ClientAddress;
use App\AviableZonesMarkers;
// use App\Mail\VerifyEmail;
use App\OrderItems;
use App\OrderItemsExtra;
use Illuminate\Support\Facades\Mail;
use App\Currencies;
class ClientController extends Controller
{

    public function __construct()
    {
        Config::set('jwt.user', 'App\Clients');
        Config::set('auth.providers.users.model', \App\Clients::class);
    }

    public function authenticate(Request $request)
    {

        $credentials = $request->only('cl_email', 'password');

        try
        {
            if (!$token = JWTAuth::attempt($credentials))
            {

                return response()->json(['error' => 'Usuario o clave incorrecta'], 400);
            }
        }
        catch(JWTException $e)
        {
            return response()->json(['error' => 'could_not_create_token'], 500);
        }

        $client_info = DB::table('clients')
            ->where('clients.cl_email', '=', $request->cl_email)
            ->select('clients.id', 
                'clients.cl_last_name',
                'clients.cl_name', 
                'clients.cl_phone_1', 
                'clients.cl_dni', 
                'clients.cl_email')
            ->first();

        $all_products = DB::table('products')
            ->join('partners', 'products.prod_partner_id', '=', 'partners.id')
            ->whereNull('products.deleted_at')
            ->select('products.*', 'partners.p_user AS partner_user')
            ->inRandomOrder()
            ->get();

        $partners_home = DB::table('partners')
            ->select('partners.p_user', 'partners.id AS p_id', 'partners.profile_pic')
            ->whereNull('partners.deleted_at')
            ->inRandomOrder()
            ->take(5)
            ->get();

        return [

        'token' => $token, 
            'response' => array(
            'status' => '200',
            'client_info' => $client_info,
            'all_products' => $all_products,
            'partners_home' => $partners_home
         )

        ];
    }

    public function getAuthenticatedUser()
    {
        try
        {
            if (!$user = JWTAuth::parseToken()->authenticate())
            {
                return response()
                    ->json(['user_not_found'], 404);
            }
        }
        catch(Tymon\JWTAuth\Exceptions\TokenExpiredException $e)
        {
            return response()->json(['token_expired'], $e->getStatusCode());
        }
        catch(Tymon\JWTAuth\Exceptions\TokenInvalidException $e)
        {
            return response()->json(['token_invalid'], $e->getStatusCode());
        }
        catch(Tymon\JWTAuth\Exceptions\JWTException $e)
        {
            return response()->json(['token_absent'], $e->getStatusCode());
        }
        return response()
            ->json(compact('user'));
    }

    public function logout(Request $request)
    {

        $this->validate($request, ['token' => 'required']);

        try
        {
            JWTAuth::invalidate($request->input('token'));
            return response(['status' => 'success', 'msg' => 'Has cerrado sesión']);

        }
        catch(JWTException $e)
        {
            return response(['status' => 'error', 'msg' => 'Ha ocurrido un error por favor intenta de nuevo']);
        }
    }

    public function refresh()
    {

        try {
            $all_products = DB::table('products')
            ->join('partners', 'products.prod_partner_id', '=', 'partners.id')
            ->whereNull('products.deleted_at')
            ->select('products.*', 'partners.p_user AS partner_user')
            ->inRandomOrder()
            ->get();

        $partners_home = DB::table('partners')
            ->select('partners.p_user', 'partners.id AS p_id', 'partners.profile_pic')
            ->whereNull('partners.deleted_at')
            ->inRandomOrder()
            ->take(5)
            ->get();
         return [
                'response' => array(
                'status' => '200',
                'all_products' => $all_products,
                'partners_home' => $partners_home
             )

        ];
        } catch (Exception $e) {
             return response()->json(['error' => $e], 500);
        }

        
    }

    public function saveClient(Request $request)
    {
        $clients = Clients::where('cl_email', $request->cl_email)
            ->first();

        if (!$clients)
        {

            try
            {

                $to_name = $request->cl_name;
                $to_email = $request->cl_email;
                $data = array(
                    'name' => $request->cl_name,
                    "body" => "Por favor, inserta este codigo para confirmar tu cuenta",
                    'confirmation_code' => mt_rand(10000000, 99999999)
                );

                $client = new Clients;
                $client->cl_name = $request->cl_name;
                $client->cl_email = $request->cl_email;
                $client->confirmation_code = $data['confirmation_code'];
                $client->cl_last_name = $request->cl_last_name;
                // $client->cl_user = $request->cl_user;
                $client->cl_dni = $request->cl_dni;
                $client->cl_verified = $request->cl_verified;
                $client->password = Hash::make($request->password);
                $client->cl_phone_1 = $request->cl_phone_1;
                $client->cl_phone_2 = $request->cl_phone_2;

                $client->save();
                Mail::send('emails.verifyemail', $data, function ($message) use ($to_name, $to_email)
                {
                    $message->to($to_email, $to_name)->subject('Confirma tu cuenta por favor');
                    $message->from('itsOnTheWay@no-reply.com', 'Its on the way ');
                });

                return response()
                    ->json(['success' => 'cliente  registrado, con exito', $client]);
            }
            catch(Throwable $e)
            {

                return response()->json(['error' => report($e) ]);
            }
        }
        else
        {

            return response()->json(['error' => 'correo ya en uso']);
        }

    }

    public function editClient(Request $request){
             $credentials = $request->only('cl_email', 'password');

                try
                {
                    if (!$token = JWTAuth::attempt($credentials))
                    {

                        return response()->json(['error' => 'invalid_credentials'], 400);
                    }
                    $clients = Clients::find($request->cl_id);
                }
                catch(JWTException $e)
                {
                    return response()->json(['error' => 'could_not_create_token'], 500);
                }


                     if ($clients) {

                            if($request->cl_name) {
                                 $clients->cl_name = $request->cl_name;
                            }  
                            if ($request->cl_last_name) {
                                 # code...
                                $clients->cl_last_name = $request->cl_last_name;
                             } 
                             if ($request->new_cl_email) {
                                 # code...
                                  $clients->cl_email = $request->new_cl_email;
                             } 
                             if ($request->new_cl_password) {
                                 # code...
                               $clients->password = Hash::make($request->password);
                             } 
                             if ($request->cl_phone_1) {
                                 # code...
                               $clients->cl_phone_1 = $request->cl_phone_1;
                             }
                     $clients->save();
                         return ['status' => '200', 
                                    'response' => array(
                                    'clients' => $clients,
                                    'msg' => 'actualizado con exito'
                                    ) 
                                ];
                    }else{
                            return response()->json(['error' => 'a ocurrido un problema'], 500);
                    }
   
               

    }
    public function verifyClient($code)
    {
        $clients = Clients::where('confirmation_code', $code)->first();

        if (!$clients)
        {
            return response()->json(['error' => 'codigo de confirmación no valido']);
        }

        $clients->cl_verified = true;
        $clients->confirmation_code = null;
        $clients->save();
        return ['response' => array(
            'client_info' => $clients,
            'status' => '200',
        ) ];

    }

    public function ResetPassword(Request $request)
    {

        $client = Clients::where('cl_email', $request->cl_email)
            ->first();
        $password = decrypt($client->password);

        $to_name = $request->cl_name;
        $to_email = $request->cl_email;
        $data = array(
            'name' => $request->cl_name,
            "body" => "Este es tu password:",
            'password' => $password
        );

        Mail::send('emails.resetPassword', $data, function ($message) use ($to_name, $to_email)
        {
            $message->to($to_email, $to_name)->subject('Reinicia tu clave');
            $message->from('itsOnTheWay@no-reply.com', 'Its on the way ');
        });

        return response()
            ->json(['success' => 'cliente  reinicio de clave , con exito', $client]);
    }

    public function addressClient($id)
    {

        $client = Clients::find($id);
        if ($client)
        {
            try
            {
                $address_client = DB::table('clients_address')->join('address', 'clients_address.ca_address_id', '=', 'address.id')
                    ->join('clients', 'clients_address.ca_cl_id', '=', 'clients.id')
                    ->join('municipios', 'address.mun_id', '=', 'municipios.id')
                    ->join('aviable_zones', 'address.zon_id', '=', 'aviable_zones.id')
                    ->where('clients_address.ca_cl_id', '=', $id)->whereNull('clients_address.deleted_at')
                    ->select('clients.cl_name AS client_name', 'address.description', 'address.mun_id AS mun_id', 'municipios.mun_name', 'address.zon_id AS zone_id', 'aviable_zones.zone_name AS zone_name', 'clients_address.id AS client_address_id', 'address.address_lon', 'address.address_lat')
                    ->get();

                return ['status' => '200', 'response' => array(
                    'address_client' => $address_client,
                ) ];
            }
            catch(JWTException $e)
            {
                return response(['status' => 'error', 'msg' => 'Ha ocurrido un error por favor intenta de nuevo']);
            }
        }
        else
        {
            return ['status' => '200', 'response' => array(
                'error' => 'cliente no tiene direcciones o no existe',
            ) ];

        }

    }

    public function saveAndressClient(Request $request)
    {
        $client = Clients::find($request->cl_id);
        if ($client)
        {
            try
            {
                $address = new Address();
                $address->st_id = '4';
                $address->mun_id = $request->mun_id;
                $address->description = $request->description;
                $address->zon_id = $request->zone_id;
                $address->address_lon = $request->address_lon;
                $address->address_lat = $request->address_lat;
                $address->save();

                $client_address = new ClientAddress;
                $client_address->ca_cl_id = $request->cl_id;
                $client_address->ca_address_id = $address->id;
                $client_address->save();

                return ['status' => '200', 'response' => ' direccion guardada con exito', ];
            }
            catch(JWTException $e)
            {
                return response(['status' => 'error', 'msg' => 'Ha ocurrido un error por favor intenta de nuevo']);
            }
        }
        else
        {
            return ['status' => '200', 'response' => array(
                'error' => 'cliente no tiene direcciones o no existe',
            ) ];

        }

    }

    public function editAdressClient(Request $request)
    {

        $client_addresss = ClientAddress::find($request->client_address_id);

        if ($client_addresss)
        {

            try
            {
                $address = Address::find($client_addresss->ca_address_id);

                if ($address)
                {
                    try
                    {

                        $address->st_id = '4';
                        $address->mun_id = $request->mun_id;
                        $address->description = $request->description;
                        $address->zon_id = $request->zone_id;
                        $address->address_lon = $request->address_lon;
                        $address->address_lat = $request->address_lat;
                        $address->save();

                        return ['status' => '200', 'response' => ' direccion actualizada con exito', ];

                    }
                    catch(Exception $e)
                    {
                        return response(['status' => 'error', 'msg' => 'Ha ocurrido un error actualizando el address por favor intenta de nuevo']);
                    }
                }

            }
            catch(Exception $e)
            {
                return response(['status' => 'error', 'msg' => 'Ha ocurrido un error por favor intenta de nuevo']);
            }

        }
        else
        {
            return ['status' => '200', 'response' => array(
                'error' => 'direccion no existe ',
            ) ];
        }

    }

    public function deleteAdressClient($id)
    {

        ClientAddress::find($id)->delete($id);

        return ['status' => '200', 'response' => array(
            'success' => 'direccion borrada con exito',
        ) ];

    }
    public function aviableZones()
    {

        $zones = AviableZones::with('zones_markers')->get();

        return response()
            ->json(['zones_aviables' => $zones->values()
            ->toArray() ]);
    }

    public function allOrdersClient($id)
    {

        $client = Clients::find($id);

        if ($client)
        {

            try
            {
                $orders = DB::table('orders')->join('clients_address', 'orders.ord_address', '=', 'clients_address.id')
                    ->where('clients_address.ca_cl_id', '=', $id)->select('orders.id AS ord_id', 'orders.ord_description', 'orders.ord_status', 'orders.ord_dm_id', 'orders.ref_pay')
                    ->orderBy('orders.created_at', 'desc')
                    ->get();

                return ['status' => '200', 'response' => array(
                    'orders' => $orders,
                ) ];

            }
            catch(Exception $e)
            {

                return response(['status' => 'error', 'msg' => 'Ha ocurrido un error por favor intenta de nuevo']);
            }

        }
        else
        {
            return ['status' => '200', 'response' => array(
                'error' => 'cliente no encontrado',
            ) ];

        }
    }

    public function orderDetail($id)
    {

        $order = Orders::find($id);
        if ($order)
        {

            try
            {
                $order = DB::table('orders')
                    ->leftJoin('delivery_man', 'orders.ord_dm_id', '=', 'delivery_man.id')
                    ->where('orders.id', '=', $order->id)
                    ->select('orders.id AS ord_id', 
                    		'orders.ord_description', 
                    		'orders.ord_status', 'orders.ord_dm_id',
                    	    'orders.ref_pay', 
                            'orders.ord_rate',
                            'orders.order_dm_val',
                            'orders.ord_dm_rate',
                            'orders.order_use_percent',
                            'orders.current_ex_price', 
                    	    'delivery_man.id as dm_id', 
                    	    'delivery_man.dm_name',
                    	    'delivery_man.dm_last_name',
                    	    'delivery_man.dm_email',
                    	    'delivery_man.dm_phone_1',      
                    	    'delivery_man.dm_phone_2',
                    	    'delivery_man.dm_dni',
                            'delivery_man.dm_profile_pic AS dm_profile_pic',
                    		'orders.order_time AS ord_time_min')
                    ->first();
          

                    $order_productos = DB::table('order_items')
                    ->join('products', 'order_items.prod_id', '=', 'products.id')
                    ->join('partners', 'products.prod_partner_id', '=', 'partners.id')

                    ->where('order_items.ord_id', '=', $order->ord_id)
                    ->select('order_items.id AS item_id', 
                        'order_items.quantity AS prod_quantity', 
                         'products.prod_name',
                         'products.prod_price_usd', 
                         'products.prod_description', 
                         'products.prod_image', 
                         'products.prod_price_usd', 
                         'partners.p_user')
                    ->get();
                    foreach ($order_productos as $product)
                     {

                    $prod_ids = $product->item_id;
                    $extras = DB::table('prod_extras')
                        ->join('order_items_order_items_extra', 'prod_extras.id', '=', 'order_items_order_items_extra.order_items_extra_id')
                        ->join('order_items', 'order_items_order_items_extra.order_items_id', '=', 'order_items.id')
                        ->where('order_items_order_items_extra.order_items_id', '=', $prod_ids)
                        ->select('prod_extras.pe_name', 
                            'prod_extras.id', 
                            'prod_extras.pe_price_usd AS extra_price', 
                            'prod_extras.prod_type AS extra_type')
                        ->get();

                    $a = 0;
                    $array_empty = [];
                    if (count($extras) <= $a)
                    {
                        $product->extras = $array_empty;

                    }
                    else
                    {
                        $product->extras = $extras;
                    }

                     }


                $partner =   DB::table('order_items')
                    ->join('partners', 'order_items.order_partner_id', '=', 'partners.id')
                    ->where('order_items.ord_id', '=', $order->ord_id)  
                    ->select('partners.percent_up', 
                            'partners.id AS p_id', 
                            'partners.p_user',
                            'partners.p_phone_1',
                            'partners.p_description',
                            'partners.p_shipping',
                            'partners.profile_pic',
                            'partners.percent_amount',
                        )
                     ->first();
              

               if ($partner->percent_up == 'on') { 
                
                        foreach ($order_productos as $prod) {
                                            $prod_price_usd = $prod->prod_price_usd;
                                            $percent_value = $partner->percent_amount;
                                            $products_percent = round($percent_value*$prod_price_usd / 100,4);
                                            $sum =  $prod_price_usd + $products_percent;
                                            $sums = strval($sum);
                                            $prod->prod_price_usd = $sums;
                                    }
               }    
                $all_deliveries = DeliveryMan::select('id', 'dm_name', 'dm_last_name')->get();
                $currency_valor = Currencies::all()->first();
                $search[] = ',';
                $replace[] = '.';


                

                return ['status' => '200', 'response' => array(
                    'order' => $order,
                    'order_productos' => $order_productos,
                    'partner' => $partner,
                    // 'order_delivery_guy'  => $order_delivery_guy,
                    
                ) ];

            }
            catch(Exception $e)
            {

                return response(['status' => 'error', 'msg' => 'Ha ocurrido un error por favor intenta de nuevo']);
            }

        }
        else
        {
            return ['status' => '200', 'response' => array(
                'error' => 'orden no encontrada',
            ) ];

        }
    }


    public function RateOrder(Request $request)
    {

        $order = Orders::find($request->ord_id);
        if ($order) {
            try {
               $order->ord_rate = $request->ord_rate;
               $order->save();
            return [
                'status' => '200', 
                'response' => array(
                'order' => $order,
                'msg' => 'calificada con exito'
            ) ]; 
            } catch (Exception $e) {
              return response(['status' => 'error', 'msg' => $e]);
            }

        }else
        {
            return [
                'status' => '400', 
                'response' => array(
                'msg' => 'orden no encontrada con exito'
            ) ];
        }
    }  

     public function RateDm(Request $request)
        {

            $order = Orders::find($request->ord_id);
            if ($order) {
                try {
                   $order->ord_dm_rate = $request->ord_dm_rate;
                   $order->save();
                return [
                    'status' => '200', 
                    'response' => array(
                    'order' => $order,
                    'msg' => 'calificada con exito'
                ) ]; 
                } catch (Exception $e) {
                  return response(['status' => 'error', 'msg' => $e]);
                }

            }else
            {
                return [
                    'status' => '400', 
                    'response' => array(
                    'msg' => 'orden no encontrada con exito'
                ) ];
            }
        }
}


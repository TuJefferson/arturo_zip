<?php

namespace app\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use Redirect;
use DB;
use App\Orders;
use App\Partners;
use App\Products;
use App\DeliveryMan;
use Config;
use Response;

class PartnerController extends Controller
{


		public function __construct()
	    {
			    Config::set('jwt.user', 'App\Partners');
	        	Config::set('auth.providers.users.model', \App\Partners::class);
		}



      public function authenticate(Request $request)
	    {


			$credentials = $request->only('p_email', 'password');
	        try {
	            if (! $token = JWTAuth::attempt($credentials)) {
	                return response()->json(['error' => 'Usuario o clave incorrecta'], 200);
	            }
	        } catch (JWTException $e) {
	            return response()->json(['error' => 'could_not_create_token'], 500);
	        }

	        $partner_info = DB::table('partners')
	        ->where('partners.p_email', '=', $request->p_email)
	        ->select('partners.*')
	        ->first();

	         return [

                'token' => $token,
                'response'=> array(
                    'partner_info' =>$partner_info,
                    'partner_banner'=> asset('images/socios/'.$partner_info->id.'/'.$partner_info->profile_pic),
                    'status'=> '200',
                )

            ];

	    }





    public function getAuthenticatedUser()
	    {
	        try {
	            if (!$user = JWTAuth::parseToken()->authenticate()) {
	                    return response()->json(['user_not_found'], 404);
	            }
	            } catch (Tymon\JWTAuth\Exceptions\TokenExpiredException $e) {
	                    return response()->json(['token_expired'], $e->getStatusCode());
	            } catch (Tymon\JWTAuth\Exceptions\TokenInvalidException $e) {
	                    return response()->json(['token_invalid'], $e->getStatusCode());
	            } catch (Tymon\JWTAuth\Exceptions\JWTException $e) {
	                    return response()->json(['token_absent'], $e->getStatusCode());
	            }
	            return response()->json(compact('user'));
	    }

    public function logout(Request $request){

    	$this->validate($request, ['token' => 'required']);

    	try{
    		 JWTAuth::invalidate($request->input('token'));
    		 return response([
    		 	'status' => 'success',
    		 	'msg' => 'Has cerrado sesión']);

    	   }
    	   catch(JWTException $e) {
    	   		 return response([
    	   		 	'status' => 'error',
    	   		 	'msg' => 'Ha ocurrido un error por favor intenta de nuevo']);
    	   }


    }

    public function refresh(){
          return response([
          	'status' => 'success'
          ]);
      }


    public function RatePartner($id){



    	$partner = Partners::find($id);

    	if ($partner) {
    		try {
    			$total_orders = DB::table('orders')
    	  			->join('order_items', 'order_items.ord_id', '=', 'orders.id')
                    ->join('products', 'order_items.prod_id', '=', 'products.id')
                    ->join('partners', 'products.prod_partner_id', '=', 'partners.id',)
                    ->where('partners.id', '=', $partner->id)
                    ->count();

    	  			$orders_rates_total = DB::table('orders')
    	  			->join('order_items', 'order_items.ord_id', '=', 'orders.id')
                    ->join('products', 'order_items.prod_id', '=', 'products.id')
                    ->join('partners', 'products.prod_partner_id', '=', 'partners.id',)
                    ->where('partners.id', '=', $partner->id,)
                    ->sum('orders.ord_rate');

    				$prom = $orders_rates_total / $total_orders;

    				
    				 return [
		                'response'=> array(
		                    'status'=> '200',
		                    'prom' => $prom
		                )
            		];



    		} catch (Exception $e) {
    				 return response([
    	   		 	'status' => 'error',
    	   		 	'msg' => $e]);
    		}
    	}else
    	{

    			return [
		                'response'=> array(
		                    'status'=> '400',
		                    'msg' => 'socio no encontrado'
		                )
            		];

    	}

    	  
    	
                    
    }

}
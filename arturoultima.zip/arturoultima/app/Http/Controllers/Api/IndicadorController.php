<?php 
namespace app\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use Redirect;
use DB;
use App\Orders;
use App\Partners;
use App\DeliveryMan;
use Config;
use Response;

class IndicadorController extends Controller{
  
  public function getVentasSemanales(Request $request,$id){
    $partner = Partners::find($id);
    if($partner){
      try{
        //todo ok
        $result=DB::select("SELECT DISTINCT order_items.ord_id,order_items.order_partner_id,order_items.quantity, orders.id,orders.pay_by_zelle,orders.bank_name,orders.bank_id,orders.order_amount_bs,orders.order_amount_usd,partners.id,partners.percent_amount,partners.percent_up FROM order_items INNER JOIN orders ON order_items.ord_id=orders.id INNER JOIN partners ON order_items.order_partner_id=partners.id WHERE order_items.order_partner_id=$id and YEARWEEK(order_items.created_at) = YEARWEEK(NOW()) AND  orders.ord_status=4 ");
        

        $data=[];
        $total_bs=0;
        $total_bs_cuenta=0;
        $total_usd=0;
        $total_usd_cuenta=0;
        $porcentaje_usd=0;
        $porcentaje_bs=0;
        foreach($result as $r){

          if(intval($r->pay_by_zelle)==0){
            if(floatval($r->order_amount_bs)>0){
              $total_bs_cuenta=$this->sumar(floatval($total_bs_cuenta),floatval($r->order_amount_bs));
              if($r->percent_up=="off"){
                $porcentaje_bs+=$this->calcularPorcentaje(floatval($r->order_amount_bs),floatval($r->percent_amount));
              }else if($r->percent_up=="on"){
                $porcentaje_bs=$this->sumar(floatval($porcentaje_bs),floatval($r->order_amount_bs));
              }
            }
          }else if(intval($r->pay_by_zelle)==1){
            if(floatval($r->order_amount_usd)>0){
              $total_usd_cuenta=$this->sumar(floatval($total_usd_cuenta),floatval($r->order_amount_usd));
              if($r->percent_up=="off"){
                $porcentaje_usd+=$this->calcularPorcentaje(floatval($r->order_amount_usd),floatval($r->percent_amount));
              }else if($r->percent_up=="on"){
                $porcentaje_usd=$this->sumar(floatval($porcentaje_usd),floatval($r->order_amount_usd));
              }
            }
          }
          $monto_tmp_usd=floatval($r->order_amount_usd);
          $monto_tmp_bs=floatval($r->order_amount_bs);
          array_push(
            $data,
            array(
              'metodo_pago'=>$this->checkMetodoPago($r->pay_by_zelle,$r->bank_name),
              // 'result'=>$result,
              'ord_id'=>$r->ord_id,
              'order_amount_bs'=>$monto_tmp_bs,
              'order_amount_usd'=>$monto_tmp_usd,
              'percent_amount'=>$r->percent_amount,
              'percent_up'=>$r->percent_up,
              'pay_by_zelle'=>$r->pay_by_zelle,
            )
          );
        }
        $total_usd=floatval($total_usd_cuenta);
        $porcentaje_usd=floatval($porcentaje_usd);
        $total_bs=floatval($total_bs_cuenta);
        $porcentaje_bs=floatval($porcentaje_bs);
        if(count($data)>0){
          return [
            'response'=> array(
              // 'partner'=>$id,
              // 'result'=>$result,
              'total_usd'=>$total_usd,
              'porcentaje_usd'=>$porcentaje_usd,
              'total_bs'=>$total_bs,
              'porcentaje_bs'=>$porcentaje_bs,
              'rows'=>$data,
              'status'=> '200',
            )
          ];
        }else{
          return [
            'response'=> array(
              'status'=> '400',
              'msg'=>'No data'
            )
          ];
        }
      }catch (Exception $e){
        //retornar errores en la consulta
        return response([
    	   	'status' => 'error',
          'msg' => $e
        ]);
      }
    }else{
      //socio no encontrado
      return [
		      'response'=> array(
		      'status'=> '400',
		      'msg' => 'socio no encontrado'
		    )
      ];
    }
  }

  public function checkMetodoPago($pay_by_zelle,$bank_name){
    if(intval($pay_by_zelle)==0){
      //se pago en bs
      return $bank_name;
    }elseif(intval($pay_by_zelle)==1){
      //se pago en dolares
      return "zelle";
    }
  }

  public function sumar($a,$b){
    return $a+$b;
  }

  public function calcularPorcentaje($valor,$porcentaje_socio){
    $porcentaje=($valor*$porcentaje_socio)/100;
    return $valor-$porcentaje;
  }

  public function getVentasMensuales(Request $request,$id){
    $partner = Partners::find($id);
    if($partner){
      try{
        //todo ok
        //  
        $result=DB::select("SELECT DISTINCT order_items.ord_id,order_items.order_partner_id,order_items.quantity, orders.id,orders.pay_by_zelle,orders.bank_name,orders.bank_id,orders.order_amount_bs,orders.order_amount_usd,partners.id,partners.percent_amount,partners.percent_up FROM order_items INNER JOIN orders ON order_items.ord_id=orders.id INNER JOIN partners ON order_items.order_partner_id=partners.id WHERE order_items.order_partner_id=$id and MONTH(order_items.created_at) =  MONTH(CURRENT_DATE()) AND YEAR(order_items.created_at) = YEAR(CURRENT_DATE()) AND  orders.ord_status=4");
        
        $data=[];
        $total_bs=0;
        $total_bs_cuenta=0;
        $total_usd=0;
        $total_usd_cuenta=0;
        $porcentaje_usd=0;
        $porcentaje_bs=0;
        foreach($result as $r){

          if(intval($r->pay_by_zelle)==0){
            if(floatval($r->order_amount_bs)>0){
              $total_bs_cuenta=$this->sumar(floatval($total_bs_cuenta),floatval($r->order_amount_bs));
              if($r->percent_up=="off"){
                $porcentaje_bs+=$this->calcularPorcentaje(floatval($r->order_amount_bs),floatval($r->percent_amount));
              }else if($r->percent_up=="on"){
                $porcentaje_bs=$this->sumar(floatval($porcentaje_bs),floatval($r->order_amount_bs));
              }
            }
          }else if(intval($r->pay_by_zelle)==1){
            if(floatval($r->order_amount_usd)>0){
              $total_usd_cuenta=$this->sumar(floatval($total_usd_cuenta),floatval($r->order_amount_usd));
              if($r->percent_up=="off"){
                $porcentaje_usd+=$this->calcularPorcentaje(floatval($r->order_amount_usd),floatval($r->percent_amount));
              }else if($r->percent_up=="on"){
                $porcentaje_usd=$this->sumar(floatval($porcentaje_usd),floatval($r->order_amount_usd));
              }
            }
          }

          $monto_tmp_usd=floatval($r->order_amount_usd);
          $monto_tmp_bs=floatval($r->order_amount_bs);
          array_push(
            $data,
            array(
              'metodo_pago'=>$this->checkMetodoPago($r->pay_by_zelle,$r->bank_name),
              // 'result'=>$result,
              'ord_id'=>$r->ord_id,
              'order_amount_bs'=>$monto_tmp_bs,
              'order_amount_usd'=>$monto_tmp_usd,
              'percent_amount'=>$r->percent_amount,
              'percent_up'=>$r->percent_up,
              'pay_by_zelle'=>$r->pay_by_zelle,
            )
          );
        }
        $total_usd=floatval($total_usd_cuenta);
        $porcentaje_usd=floatval($porcentaje_usd);
        $total_bs=floatval($total_bs_cuenta);
        $porcentaje_bs=floatval($porcentaje_bs);
        if(count($data)>0){
          return [
            'response'=> array(
              // 'partner'=>$id,
              // 'result'=>$result,
              'total_bs'=>$total_bs,
              'total_usd'=>$total_usd,
              'porcentaje_bs'=>$porcentaje_bs,
              'porcentaje_usd'=>$porcentaje_usd,
              'rows'=>$data,
              'status'=> '200',
            )
          ];
        }else{
          return [
            'response'=> array(
              'status'=> '400',
              'msg'=>'No data'
            )
          ];
        }
      }catch (Exception $e){
        //retornar errores en la consulta
        return response([
    	   	'status' => 'error',
          'msg' => $e
        ]);
      }
    }else{
      //socio no encontrado
      return [
		      'response'=> array(
		      'status'=> '400',
		      'msg' => 'socio no encontrado'
		    )
      ];
    }
  }

  public function getestadisticasActividadSemanal(Request $request,$id){
    $partner = Partners::find($id);
    if($partner){
      try{
        //todo ok
        $result=DB::table('order_items')
        ->where('order_items.order_partner_id','=',$id)
        ->join('orders','orders.id','=','order_items.ord_id')
        ->whereRaw('YEARWEEK(orders.created_at) = YEARWEEK(NOW())')
        ->get();

        $lun=0;
        $mar=0;
        $mie=0;
        $jue=0;
        $vie=0;
        $sab=0;
        $dom=0;
        foreach($result as $r){
          $dia=$this->getNameDay($r->created_at);
          if ($dia=="Mon"){
            $lun++;
          }elseif ($dia=="Tue"){
            $mar++;
          }elseif ($dia=="Wed"){
            $mie++;
          }elseif ($dia=="Thu"){
            $jue++;
          }elseif ($dia=="Fri"){
            $vie++;
          }elseif ($dia=="Sat"){
            $sab++;
          }elseif ($dia=="Sun"){
            $dom++;
          }
        }
        if(count($result)>0){
          return [
            'response'=> array(
              // 'partner'=>$id,
              // 'result'=>$result,
              'dias'=>array(
                array(
                // 'lun'=>$lun,
                'lun'=>10,
                // 'mar'=>$mar,
                'mar'=>20,
                // 'mie'=>$mie,
                'mie'=>30,
                // 'jue'=>$jue,
                'jue'=>10,
                // 'vie'=>$vie,
                'vie'=>8,
                // 'sab'=>$sab,
                'sab'=>75,
                // 'dom'=>$dom,)
                'dom'=>90,)
              ),
              'status'=> '200',
              )
          ];
        }else{
          return [
            'response'=> array(
              'status'=> '400',
              'msg'=>'No data'
            )
          ];
        }
      }catch (Exception $e){
        //retornar errores en la consulta
        return response([
    	   	'status' => 'error',
          'msg' => $e
        ]);
      }
    }else{
      //socio no encontrado
      return [
		      'response'=> array(
		      'status'=> '400',
		      'msg' => 'socio no encontrado'
		    )
      ];
    }
  }

  public function getNameDay($date){
    return date('D', strtotime($date));
  }

  public function getProductosMasVendidos(Request $request,$id){
    $partner = Partners::find($id);
    if($partner){
      try{
        //todo ok
        $result=DB::select('select order_items.id,order_items.prod_id,SUM(order_items.quantity) as cant, products.id, products.prod_name FROM order_items INNER JOIN products ON order_items.prod_id = products.id WHERE order_items.order_partner_id='.$id.' GROUP BY order_items.prod_id ORDER BY SUM(order_items.quantity) DESC LIMIT 10 '); 
        return [
          'response'=> array(
            // 'partner'=>$id,
            'productos'=>$result,
            'status'=> '200',
            )
          ];
      }catch (Exception $e){
        //retornar errores en la consulta
        return response([
    	   	'status' => 'error',
          'msg' => $e
        ]);
      }
    }else{
      //socio no encontrado
      return [
		      'response'=> array(
		      'status'=> '400',
		      'msg' => 'socio no encontrado'
		    )
      ];
    }
  }

  public function getGananciasSemanales(Request $request,$id){
    $dm = DeliveryMan::find($id);
    if ($dm){
      try {
        $result=DB::select("SELECT o.id, o.created_at,((o.current_ex_price * o.order_dm_val) * dm.dm_percent_amount) /100 as sum,DATE_FORMAT(o.created_at,'%d - %b - %Y') AS fecha FROM orders o inner join delivery_man dm on (o.ord_dm_id=dm.id) WHERE o.ord_dm_id=$id and o.ord_status='4' AND YEARWEEK(o.created_at) = YEARWEEK(NOW()) ");
        $sum_general=0;
        foreach($result as $r){
          $sum_general=floatval($r->sum)+floatval($sum_general);
        }

        return [
          'response'=> array(
            'ganancia'=>$sum_general,
            'historial'=>$result,
            'status'=> '200',
          )
        ];
      }catch (Exception $e) {
    		return response([
    	    'status' => 'error',
          'msg' => $e
        ]);
    	}
    }else{
    	return [
		    'response'=> array(
		      'status'=> '400',
		      'msg' => 'socio no encontrado'
		    )
      ];
    }
  }
  
  public function getGananciasMensuales(Request $request,$id){
    $dm = DeliveryMan::find($id);
    if ($dm){
      try {
        $result=DB::select("SELECT o.id, o.created_at,((o.current_ex_price * o.order_dm_val) * dm.dm_percent_amount) /100 as sum,DATE_FORMAT(o.created_at,'%d - %b - %Y') AS fecha FROM orders o inner join delivery_man dm on (o.ord_dm_id=dm.id) WHERE o.ord_dm_id =$id and o.ord_status='4' AND MONTH(o.created_at) =  MONTH(CURRENT_DATE()) AND YEAR(o.created_at) = YEAR(CURRENT_DATE())");
        $sum_general=0;
        foreach($result as $r){
          $sum_general=floatval($r->sum)+floatval($sum_general);
        }
        return [
          'response'=> array(
            'ganancia'=>$sum_general,
            'historial'=>$result,
            'status'=> '200',
          )
        ];
      }catch (Exception $e) {
    		return response([
    	    'status' => 'error',
          'msg' => $e
        ]);
    	}
    }else{
    	return [
		    'response'=> array(
		      'status'=> '400',
		      'msg' => 'socio no encontrado'
		    )
      ];
    }
  }
}
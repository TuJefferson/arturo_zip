<?php
namespace app\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use Redirect;
use DB;
use App\Orders;
use App\Partners;
use App\Products;
use App\DeliveryMan;
use Config;
use Response;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
class PartnerOrdersController extends Controller
{

    public function __construct()
    {
        Config::set('jwt.user', 'App\Partners');
        Config::set('auth.providers.users.model', \App\Partners::class);
    }

    public function delivered($id)
    {
        // dd($id);
        if ($id)
        {
            try
            {
                $ordersDelivered = DB::table('orders')->join('order_items', 'order_items.ord_id', '=', 'orders.id')
                    ->join('products', 'order_items.prod_id', '=', 'products.id')
                    ->join('partners', 'products.prod_partner_id', '=', 'partners.id',)
                    ->join('clients_address', 'orders.ord_address', '=', 'clients_address.id')
                    ->join('address', 'clients_address.ca_address_id', '=', 'address.id')
                    ->join('clients', 'clients_address.ca_cl_id', '=', 'clients.id')
                    ->join('municipios', 'address.mun_id', '=', 'municipios.id')
                    ->join('orders_status_type', 'orders.ord_status', '=', 'orders_status_type.id')
                    ->where('partners.id', '=', $id,)
                    ->where('orders.ord_status', '=', 4)
                    ->select('orders.id AS ord_id', 'clients.cl_name', 'clients.cl_email', 'clients.cl_phone_1', 'clients.cl_phone_2', 'orders_status_type.status_name', 'orders.ord_description', 'ord_dm_id', 'orders.ord_address', 'address.description', 'municipios.mun_name')
                    ->groupBy('order_items.ord_id')
                    ->orderBy('orders.created_at', 'desc')
                    ->get();

                return [

                'response' => array(
                    'ordersDelivered' => $ordersDelivered,
                    'status' => '200',
                ) ];

            }
            catch(Throwable $e)
            {
                report($e);

                return false;
            }

        }

    }

    public function orders($id)
    {

        if ($id)
        {
            try
            {
                $orders = DB::table('orders')->join('order_items', 'order_items.ord_id', '=', 'orders.id')
                    ->join('products', 'order_items.prod_id', '=', 'products.id')
                    ->join('partners', 'products.prod_partner_id', '=', 'partners.id',)
                    ->join('clients_address', 'orders.ord_address', '=', 'clients_address.id')
                    ->join('address', 'clients_address.ca_address_id', '=', 'address.id')
                    ->join('clients', 'clients_address.ca_cl_id', '=', 'clients.id')
                    ->join('municipios', 'address.mun_id', '=', 'municipios.id')
                    ->join('orders_status_type', 'orders.ord_status', '=', 'orders_status_type.id')
                    ->where('partners.id', '=', $id,)
                    ->where('orders.ord_status', '=', 2)
                    ->select('orders.id AS ord_id', 'clients.cl_name', 'clients.cl_email', 'clients.cl_phone_1', 'clients.cl_phone_2', 'orders_status_type.status_name', 'orders.ord_description', 'ord_dm_id', 'orders.ord_address', 'address.description', 'municipios.mun_name')
                    ->groupBy('order_items.ord_id')
                    ->orderBy('orders.created_at', 'desc')
                    ->get();

                return [

                'response' => array(
                    'partner_orders' => $orders,
                    'status' => '200',
                ) ];

            }
            catch(Throwable $e)
            {
                report($e);

                return false;
            }

        }
    }

    public function orderDetail($id)
    {

        $order = Orders::find($id);
        if ($order)
        {

            try
            {
                $order = DB::table('orders')
                    ->join('orders_status_type', 'orders.ord_status', '=', 'orders_status_type.id')
                    ->join('clients_address', 'orders.ord_address', '=', 'clients_address.id')
                    ->join('address', 'clients_address.ca_address_id', '=', 'address.id')
                    ->join('aviable_zones', 'address.zon_id', '=', 'aviable_zones.id')
                    ->join('clients', 'clients_address.ca_cl_id', '=', 'clients.id')
                    ->join('municipios', 'address.mun_id', '=', 'municipios.id')
                    ->leftJoin('delivery_man', 'orders.ord_dm_id', '=', 'delivery_man.id')
                    ->where('orders.id', '=', $order->id)
                    ->select('orders.id AS ord_id', 
                        'orders.ord_description',
                        'orders.ord_status',
                        'orders.ref_pay',
                        'orders.pay_by_zelle', 
                        'clients.cl_name',
                        'clients.cl_email',
                        'clients.cl_phone_1',
                        'clients.cl_phone_2', 
                        'clients.id AS cl_id', 
                        'orders_status_type.status_name', 
                        'orders.ord_status AS ord_status',
                        'address.description AS address_description', 
                        'address.address_lon AS address_lon', 
                        'address.address_lat AS address_lat', 
                        'municipios.mun_name AS municipio', 
                        'aviable_zones.zone_name AS zone_name', 
                        'orders.order_time AS ord_time_min',
                        'delivery_man.id as dm_id', 
                        'delivery_man.dm_name',
                        'delivery_man.dm_last_name',
                        'delivery_man.dm_email',
                        'delivery_man.dm_phone_1', 
                        'delivery_man.dm_profile_pic',      
                        'delivery_man.dm_phone_2',
                        'delivery_man.dm_dni',
                        )
                    ->first();

                    if ($order->pay_by_zelle  == 1) {

                        $order->pay_type = 'pagado por zelle';
                    }else{
                        $order->pay_type = 'pagado por transferencia bancaria';
                    }


                $order_productos = DB::table('order_items')->join('products', 'order_items.prod_id', '=', 'products.id')
                    ->join('partners', 'products.prod_partner_id', '=', 'partners.id')
                    ->where('order_items.ord_id', '=', $order->ord_id)
                    ->select('order_items.id AS item_id', 'order_items.quantity AS prod_quantity', 'products.prod_name', 'products.prod_price_usd', 'products.prod_description', 'products.prod_image', 'partners.p_user')
                    ->get();

                $order_partner = DB::table('order_items')->join('products', 'order_items.prod_id', '=', 'products.id')
                    ->join('partners', 'products.prod_partner_id', '=', 'partners.id')
                    ->where('order_items.ord_id', '=', $order->ord_id)
                    ->select('partners.p_user', 'partners.profile_pic', 'partners.id AS p_id')
                    ->first();
                foreach ($order_productos as $product)
                {

                    $prod_ids = $product->item_id;

                    // var_dump($product);
                    $extras = DB::table('prod_extras')->join('order_items_order_items_extra', 'prod_extras.id', '=', 'order_items_order_items_extra.order_items_extra_id')
                        ->join('order_items', 'order_items_order_items_extra.order_items_id', '=', 'order_items.id')
                        ->where('order_items_order_items_extra.order_items_id', '=', $prod_ids)->select('prod_extras.pe_name', 'prod_extras.id', 'prod_extras.pe_price_usd AS extra_price', 'prod_extras.prod_type AS extra_type')
                        ->get();

                    $a = 0;
                    $array_empty = [];
                    // var_dump($extras);
                    if (count($extras) <= $a)
                    {
                        $product->extras = $array_empty;

                    }
                    else
                    {
                        $product->extras = $extras;
                    }

                }
                return ['status' => '200', 'response' => array(
                    'order' => $order,
                    'order_productos' => $order_productos,
                    'order_partner' => $order_partner
                ) ];

            }
            catch(Exception $e)
            {

                return response(['status' => 'error', 'msg' => 'Ha ocurrido un error por favor intenta de nuevo']);
            }

        }
        else
        {
            return ['status' => '400', 'response' => array(
                'error' => 'orden no encontrada',
            ) ];

        }
    }

    public function acceptOrder(Request $request)
    {
        $json_entrada = Log::info(json_encode($request->all()));
        $order = Orders::find($request->ord_id);
        $order_status = $request->ord_status;

        $order_approved = Carbon::now()->format('Y-m-d H:i');
        if ($order->ord_status = 2)
        {
            // $order->ord_dm_id = $request->dm_id;
            $order->order_time =  $request->order_time;
            $order->order_approved =  $order_approved;
            $order->ord_status =  $order_status;
            $order->save();
            // return back();
            return ['status' => '200', 'response' => array(
                'order' => $order,
                'msg' => 'aceptada con exito'
            ) ];
        }
        else
        {
            return response()->json('error');
        }

    }


    public function PartnerCurrentOrders($id){




      $p_id = Partners::find($id);
      // dd($p_id);


      if ($p_id) {
        

        try {
             $orders = DB::table('orders')->join('order_items', 'order_items.ord_id', '=', 'orders.id')
                    ->join('products', 'order_items.prod_id', '=', 'products.id')
                    ->join('partners', 'products.prod_partner_id', '=', 'partners.id',)
                    ->join('clients_address', 'orders.ord_address', '=', 'clients_address.id')
                    ->join('address', 'clients_address.ca_address_id', '=', 'address.id')
                    ->join('clients', 'clients_address.ca_cl_id', '=', 'clients.id')
                    ->join('municipios', 'address.mun_id', '=', 'municipios.id')
                    ->join('orders_status_type', 'orders.ord_status', '=', 'orders_status_type.id')
                    ->where('partners.id', '=', $id,)
                    ->where('ord_status','!=',4)
                    ->where('ord_status','!=',1)
                    ->select('orders.id AS ord_id', 
                        'clients.cl_name', 
                        'clients.cl_email', 
                        'clients.cl_phone_1', 
                        'clients.cl_phone_2', 
                        'clients.id AS cl_id', 
                        'orders_status_type.status_name', 
                        'orders.ord_description', 
                        'ord_dm_id',
                        'orders.ord_address', 'address.description', 
                        'municipios.mun_name')
                    ->groupBy('order_items.ord_id')
                    ->orderBy('orders.created_at', 'desc')
                    ->get();

                        return [
                              'status'=> '200',
                              'response'=> array(
                              'orders' =>$orders,

                            )
                        ]; 
        } catch (Exception $e) {
                          return [
                              'status'=> '300',
                              'response'=> array(
                              'error' =>$e,

                            )
                        ]; 
        }

      }else
      {

             return [
                    'status'=> '400',
                    'response'=> array(
                    'error' =>'socio no encontrado',
                )
            ]; 
      }

           
    }
    public function deliveredToday($id)
    {
        // dd($id);
        if ($id)
        {
            try
            {

                $date = Carbon::now()->format('Y-m-d');
                $orders_d_today = DB::table('orders')
                    ->join('order_items', 'order_items.ord_id', '=', 'orders.id')
                    ->join('products', 'order_items.prod_id', '=', 'products.id')
                    ->join('partners', 'products.prod_partner_id', '=', 'partners.id',)
                    ->join('clients_address', 'orders.ord_address', '=', 'clients_address.id')
                    ->join('address', 'clients_address.ca_address_id', '=', 'address.id')
                    ->join('clients', 'clients_address.ca_cl_id', '=', 'clients.id')
                    ->join('municipios', 'address.mun_id', '=', 'municipios.id')
                    ->join('orders_status_type', 'orders.ord_status', '=', 'orders_status_type.id')
                    ->where('partners.id', '=', $id,)
                    ->where('orders.ord_status', '=', 4)
                    ->whereBetween('orders.updated_at', [$date.' 00:00:00',$date.' 23:59:59'])
                    ->select('orders.id AS ord_id', 'clients.cl_name', 'clients.cl_email', 'clients.cl_phone_1', 'clients.cl_phone_2', 'orders_status_type.status_name', 'orders.ord_description', 'ord_dm_id', 'orders.ord_address', 'address.description', 'municipios.mun_name')
                    ->groupBy('order_items.ord_id')
                    ->orderBy('orders.created_at', 'desc')
                    ->get();

                return [
                    'response' => array(
                    'orders_d_today' => $orders_d_today,
                    'status' => '200',
                ) ];

            }
            catch(Throwable $e)
            {
                report($e);

                return false;
            }

        }else
        {  
                return [
                    'response' => array(
                    'error' => 'socio no encontrado',
                    'status' => '400',
                ) ]; 
        }

    }    
}


<?php

namespace app\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Redirect;
use Config;
use Response;
use App\WorkingStatus;
class WorkingStatusController extends Controller
{


      public function workingStatus()
	    { 
	    		$working_status = WorkingStatus::select('status')->first();
	    		if ($working_status) {

	    			try {
	    				if($working_status->status > '0'){
	    					$gen_open = true;
			    		}else{
		                   $gen_open = false;
		                    $gen_open = false;
			    		}

						return response()->json(['success'=> array('status' => $gen_open )]);


	    			} catch (Exception $e) {
	    					return response()->json(['error'=> $e ]);
	    			}

	    		}

	    }

}

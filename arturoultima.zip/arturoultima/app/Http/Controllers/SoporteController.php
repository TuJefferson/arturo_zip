<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use Hash;
class SoporteController extends Controller



{

	public function index(){

      		$users_admin = User::all();
				
			 return view('soporte')->with([
	            'users_admin' => $users_admin,
	        ]);
  	  }


  	    public function createUserAdmin(Request $request)
   			 {   

        // dd($request);

          $user = User::find($request->email);

          if(!$user){

                $user  = new User;
                $user->name = $request->name;
                $user->email = $request->email;
                $user->password = Hash::make($request->password);
                $user->save();
                return back();  

          }else{

             return response()->json(['error'=>  'usuario  ya registrado']);
          }

   			 }
}

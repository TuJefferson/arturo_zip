<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Products;
use App\Partners;
use DB;
use App\ProductExtras;
use App\Segmentatios;
class ProductosController extends Controller
{
     public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('products');
    }

    public function saveProduct(Request $request){

         $product = Products::find($request->id);

         if (!$product) {
                $product = new Products;
                $product->prod_name = $request->prod_name;
                $product->prod_partner_id = $request->prod_partner_id;
                $product->prod_price_usd = $request->prod_price_usd;
                // $product->prod_price_bs = $request->prod_price_bs;
                $product->prod_description= $request->prod_description;
                $product->prod_category = $request->prod_category;
                $product->prod_suges = $request->prod_suges;
                $product->prod_recome = $request->prod_recome;
                 $product->prod_seg_id = $request->prod_seg_id;
                $product->save();

                return back();
                // return response()->json(['success'=>  $product]);
            }
            else{

                return response()->json(['error'=>  'producto de socio ya registrado']);
            }
    }

    public function deleteProduct($id){
            // dd($id);

            Products::find($id)->delete($id);

                return response()->json([
                    'success' => 'Record deleted successfully!'
                ]);
    }


    public function editarProduct(Request $request){

         // dd($request);
         $product = Products::find($request->prod_id);
         if ($product) {
                $product->prod_name = $request->prod_name;
                $product->prod_partner_id = $request->prod_partner_id;
                $product->prod_price_usd = $request->prod_price_usd;
                $product->prod_description= $request->prod_description;
                $product->prod_category = $request->prod_category;
                $product->prod_suges = $request->prod_suges;
                $product->prod_recome = $request->prod_recome;
                $product->prod_seg_id = $request->prod_seg_id;
                if ($request->prod_aviable) {
                 $product->prod_aviable = 0;
                }else{
                    $product->prod_aviable = 1;
                }
                $product->save();
                return back();
            }
            else{

                return response()->json(['error'=>  'no sé encuentra el producto, por favor verifica nuevamente']);
            }
    }

     public function saveProductExtra(Request $request){


            $productsjson = $request->prod_id;

                foreach ($productsjson as  $product) {
                                  
                                    $prod_id = $product;

                                    $extra = new ProductExtras;
                                    $extra->pe_partner_id = $request->pe_partner_id;
                                    $extra->prod_id = $prod_id;
                                    $extra->pe_name = $request->prod_extra;
                                    $extra->pe_price_usd = $request->pe_price_usd;
                                    $extra->prod_type = $request->prod_type;
                                    $extra->save();


                                }

                return back();                

        

    }

    public function deleteProductExtra($id){
            // dd($id);

                ProductExtras::find($id)->delete($id);
            // ;

                return response()->json([
                    'success' => 'Record deleted successfully!'
                ]);
    }


    public function editarProductExtra(Request $request){

         // dd($request);
         $prod_extra = ProductExtras::find($request->extra_id);
         if ($prod_extra) {
                $prod_extra->pe_name = $request->pe_name;
                $prod_extra->pe_price_usd = $request->pe_price_usd;
                $prod_extra->pe_price_bs = '10';
                $prod_extra->prod_id= $request->prod_id;
                $prod_extra->pe_partner_id= $request->pe_partner_id;
                $prod_extra->prod_type = $request->prod_type;
                $prod_extra->save();
                return back();
                // return response()->json(['success'=>  $product]);
            }
            else{

                return response()->json(['error'=>  'no sé encuentra el producto, por favor verifica nuevamente']);
            }
    }

    
}

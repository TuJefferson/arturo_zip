<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\States;
use App\Municipios;
use App\AviableZones;
use Redirect;
use DB;
class ZoneController extends Controller
{
    	public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {

    	$estados = States::all();


        $zones =   DB::table('aviable_zones')
             ->join('municipios', 'aviable_zones.mun_id', '=','municipios.id')
             ->whereNull('aviable_zones.deleted_at')
             ->select('aviable_zones.*', 'municipios.mun_name AS mun_name', 'municipios.id AS mun_id')
             ->get();
         return view('zones')->with([
            'estados' => $estados,
            'zones' => $zones
          
        ]);
    }

    public function municipios($id){

        return Municipios::where('states_id','=',$id)->get();

    }
    public function NewZone(Request $request){
        // dd($request);
             $zone = new AviableZones;
             $zone->zone_name = $request->zone_name;
             $zone->mun_id = $request->p_municipio;
             $zone->delivery_price_usd = $request->delivery_price_usd;
             $zone->save();
            return Redirect::to('aviablezones');
     }

     public function DeleteZone($id){
            // dd($id);

            AviableZones::find($id)->delete($id);

                return response()->json([
                    'success' => 'Record deleted successfully!'
                ]);
    }

     public function updateZone(Request $request){

            $zone = AviableZones::find($request->zone_id);

            $zone->zone_name = $request->zone_name;
            $zone->mun_id = $request->p_municipio;
            $zone->delivery_price_usd = $request->delivery_price_usd;
            $zone->save();
            return Redirect::to('aviablezones');
     }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Currencies;
use App\DeliveryPrice;
use Illuminate\Support\Facades\Input;
use Redirect;
use App\UsageAppPercentage;
use Carbon\Carbon;
use App\Segmentatios;
class MiscellaneousController extends Controller
{
   public function __construct()
    {
        $this->middleware('auth');
    }


     public function index()
	    {
	    	$usd = Currencies::where('id','=', '1')->first();
	    	$bs = Currencies::where('id','=', '2')->first();

	    	$date = Carbon::now()->format('H:i');
	    	// dd($date);
	        return view('currencies')->with([
	            'usd' => $usd,
	            'bs' => $bs,
	        ]);
	    }

	 public function updatePriceCurrencie(Request $request){

	 		$currency = Currencies::find($request->cur_id);
            $currency->cur_value = Input::get('usd_value');
            $currency->save();
            return Redirect::to('currencies');
	 }


	  public function indexDeliveryPrice()
	    {
	    	$usd = DeliveryPrice::where('id','=', '1')->first();
	        return view('delivery_price')->with([
	            'delivery_price' => $usd,
	        ]);
	    }

	 public function updatePriceDelivery(Request $request){

	 		$price = DeliveryPrice::find($request->cur_id);
            $price->delivery_price = Input::get('usd_value');
            $price->save();
            return Redirect::to('delivery_price');
	 }


	 public function indexUsageAppPercentage()
	    {
	    	$percet = UsageAppPercentage::first();
	        return view('use_percentage_app')->with([
	            'percet' => $percet,
	        ]);
	    }

	 public function updateUsageAppPercentage(Request $request){
	 		$percent = UsageAppPercentage::find($request->percent_id);
	 			// dd($percent);


            $percent->use_percentage = $request->use_percentage;
            $percent->save();
            return Redirect::to('use_percentage_app');
	 }


	 public function indexSegmentatios()
	    {
	    	$segme = Segmentatios::all();
	        return view('segmentatios')->with([
	            'segme' => $segme,
	        ]);
	    }


	     public function NewSegmentatios(Request $request){
        // dd($request);
             $seg = new Segmentatios;
             $seg->seg_description = $request->seg_description;
             $seg->save();
            return Redirect::to('segmentatios');
     }
     
     public function DeleteSegmentatios($id){
            // dd($id);

            Segmentatios::find($id)->forceDelete($id);

                return response()->json([
                    'success' => 'Record deleted successfully!'
                ]);
    }
      public function updateSegme(Request $request){
	 		$segme = Segmentatios::find($request->seg_id);
            $segme->seg_description = $request->seg_description;
            $segme->save();
            // dd($segme);
            return Redirect::to('segmentatios');
	 }
}

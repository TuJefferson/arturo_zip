<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Partners;
use App\RoleUsers;
use Hash;
use DB;
use App\DeliveryMan;
use App\DmPayments;
use App\Orders;
class RepartidorInfoController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

     public function index($id)

    {


            // $roles = RoleUsers::all();

             $dm_info = DeliveryMan::find($id);
            
            $orders_dm = DB::table('orders')
                         ->join('delivery_man', 'delivery_man.id', '=', 'orders.ord_dm_id')
                         ->join('orders_status_type', 'orders.ord_status', '=', 'orders_status_type.id')
                         ->where('delivery_man.id', '=', $dm_info->id)
                         ->select('orders.*',
                            'orders_status_type.status_name')
                         ->get();

                
             // $prod_price_usd = $prod->prod_price_usd;

             foreach ($orders_dm as $ord_dm) {

                    $dm_percent_value = $dm_info->dm_percent_amount;
                         $ord_dm_percent = round($dm_info->dm_percent_amount*$ord_dm->order_dm_val / 100,4);

                         $dm_sum =  $ord_dm->order_dm_val - $dm_percent_value;            
                         $ord_dm->amount_to_pay = $dm_sum;
                         }            

                                           

                                            



             $order_payto_dm =  DB::table('dm_payments')
                               ->join('delivery_man', 'delivery_man.id', '=', 'dm_payments.dm_id') 
                               ->join('orders' , 'orders.ord_dm_id', '=', 'dm_payments.dm_id')
                               ->join('orders_status_type', 'orders.ord_status', '=', 'orders_status_type.id')
                               ->where('delivery_man.id', '=', $dm_info->id)
                               ->where('orders.order_payto_dm', '=', 1)
                               ->select('orders.*',
                                        'dm_payments.dm_pay_amount AS dm_pay_amount',
                                        'dm_payments.dm_pay_bank AS dm_pay_bank',
                                        'dm_payments.dm_payref AS dm_pay_ref',
                                        'dm_payments.created_at AS dm_pay_created_At',
                                        'orders_status_type.status_name')
                               ->get();         

            $search[]= ',';
            $replace[] = '.';


            return view('repartidores_info')->with([
            'dm_info' => $dm_info,
            'orders_dm' => $orders_dm,
            'search' => $search,
            'replace' => $replace,
            'order_payto_dm' => $order_payto_dm
        ]);
    }

    public function editDm(Request $request){
        // $data = $request->all();
          
         // dd($request);   

        $dm_info = DeliveryMan::find($request->dm_id);  


        if ($dm_info) {
                $dm_info->dm_name = $request->dm_name;
                $dm_info->dm_last_name = $request->dm_last_name;
                $dm_info->dm_email = $request->dm_email;
                $dm_info->password= Hash::make($request->password);
                $dm_info->dm_phone_1 = $request->phone_1;
                $dm_info->dm_phone_2 = $request->phone_2;
                $dm_info->dm_dni = $request->dm_dni;
                $dm_info->dm_percent_amount = $request->dm_percent_amount;
                
                    
                   if ($request->hasFile('dm_profile_pic')) {
                    $dm_profile_pic = $request->file('dm_profile_pic');
                    $fileName = uniqid() . $dm_profile_pic->getClientOriginalName();
                    $dm_info->dm_profile_pic = $fileName;    
                    $path = public_path() . '/images/repartidores/'.$dm_info->id.'/';
                    $dm_profile_pic->move($path, $fileName);
                   }
                $dm_info->save();
                    
                return back();
        }   
        else{
                     // dd('si  ');
                return response()->json(['error'=>  'user de repartidor no registrado']);
            }

         
    }
    public function ChangeDmPassword(Request $request){

        $data = $request->all();

        // dd($data);
       $dm_info = DeliveryMan::find($request->dm_id);  

         if ($dm_info) {
                
               $dm_info->password= Hash::make($request->password);
                $dm_info->save();
                 return back();
            }
            else{

                return response()->json(['error'=>  'user de socio ']);
            }
    }

    public function UploadDmImagen($id, Request $request){


        $dm = DeliveryMan::find($id);
        $file = $request->file('file');
        $path = public_path() . '/images/repartidores/'.$dm->id;
        $fileName = uniqid() . $file->getClientOriginalName();
        $file->move($path, $fileName);


         if ($dm) {
                $dm->avatar = $fileName;
                $dm->save();
                 return back();
            }
            else{

                return response()->json(['error'=>  'user de socio ']);
            }
    }

     public function deleteDm($id){
            DeliveryMan::find($id)->delete($id);

                return response()->json([
                    'success' => 'Record deleted successfully!'
                ]);
    }

    public function PayOrderDm(Request $request){
            
        // dd($request);
            $dm_id = DeliveryMan::find($request->dm_id);

            if ($dm_id) {
                    $payment = DmPayments::find($request->dm_payment_ref);
                    $ord_to_pay = Orders::find($request->ord_id);
                    // dd($ord_to_pay);
                    if(!$payment){


                        try {
                            $payment = new DmPayments;
                            $payment->ord_id = $ord_to_pay->id;
                            $payment->dm_id = $request->dm_id;
                            $payment->dm_pay_amount = $request->dm_pay_amount;
                            $payment->dm_pay_bank = $request->dm_payment_bank;
                            $payment->dm_payref = $request->dm_payment_ref;
                            $payment->save();
                    
                                $ord_to_pay->order_payto_dm = 1;
                                $ord_to_pay->save();
                             return back();
                        } catch (Exception $e) {
                             return response()->json([
                                     'error' => $e
                                    ]);
                        }


                        
                    }

            }else{

                return response()->json([
                    'error' => 'algo a ocurrido por favor regresa e intenta de nuevo'
                ]);
            }


    }
}



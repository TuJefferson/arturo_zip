<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Hash;
use DB;
use App\DeliveryMan;
use App\Partners;
use App\RoleUsers;

class RepartidoresController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {

        $dms = DeliveryMan::all()->sortByDesc('created_at');
        $partners = Partners::all();
        $roles = RoleUsers::all();



        return view('repartidores')->with([
            'dms' => $dms,
            'partners' => $partners,
            'roles' => $roles
        ]);
    }

     public function storeDm(Request $request){

        $data = $request->all();
        $dm = DB::table('delivery_man')
              ->select('delivery_man.id')  
              ->where('delivery_man.dm_email' , '=', $request->dm_email)
              ->first();
         if (!$dm) {
                $dm = new DeliveryMan;
                $dm->dm_name = $request->dm_name;
                $dm->dm_last_name = $request->dm_last_name;
                $dm->dm_email = $request->dm_email;
                $dm->password= Hash::make($request->password);
                $dm->dm_phone_1 = $request->phone_1;
                $dm->dm_phone_2 = $request->phone_2;
                $dm->dm_dni = $request->dm_dni;
                $dm->dm_percent_amount = $request->dm_percent_amount;

                    $request->hasFile('dm_profile_pic');
                    $dm_profile_pic = $request->file('dm_profile_pic');
                    $fileName = uniqid() . $dm_profile_pic->getClientOriginalName();
                $dm->dm_profile_pic = $fileName;    
                $dm->save();
                    $path = public_path() . '/images/repartidores/'.$dm->id.'/';
                    $dm_profile_pic->move($path, $fileName);
                return back();
            }
            else{
                     // dd('si  ');
                return response()->json(['error'=>  'user de repartidor ya registrado']);
            }

    }


}

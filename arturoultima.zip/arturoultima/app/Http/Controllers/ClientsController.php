<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Clients;
use App\States;
use App\Municipios;
use App\RoleUsers;
use Hash;
use DB;
class ClientsController extends Controller
{
   public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {


    	$all_clientes = Clients::paginate(8);
        return view('clients')->with([
            'all_clientes' => $all_clientes,
        ]);
    }
}

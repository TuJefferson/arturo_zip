<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Partners;
use App\States;
use App\Municipios;
use App\RoleUsers;
use App\CategoriesPartners;
use App\Products;
use App\ProductsExtras;
use App\Orders;
use Hash;
use DB;
use App\Currencies;
use App\PartnerAccounts;
use App\Segmentatios;
class SocioInfoController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index($id)

    {

            $estados = States::all();
            $roles = RoleUsers::all();
            $categorias_p = CategoriesPartners::all();

            $partner_info = Partners::find($id);
            $segme = Segmentatios::all();
            // dd($segme);
            $partner_cat = DB::table('partners')
             ->join('categories', 'partners.p_cat_id', '=','categories.id')
             ->join('subcategory', 'categories.id', '=', 'subcategory.cat_id')
             ->select('categories.cat_name', 'categories.id AS cat_id', 'subcategory.sub_cat_name', 'subcategory.id AS sub_cat_id' )
             ->where('partners.p_cat_id', '=', $partner_info->p_cat_id)
             ->first();

            $partner_products = DB::table('partners')
             ->join('products', 'products.prod_partner_id', '=', 'partners.id')
             ->leftJoin('segmentatios', 'segmentatios.id', '=', 'products.prod_seg_id')
             ->where('products.prod_partner_id', '=', $partner_info->id, )
             ->whereNull('products.deleted_at')
             ->select('products.*', 'segmentatios.id AS seg_id', 'segmentatios.seg_description')
             ->get();
             // dd($partner_products);
               $prod_extras = DB::table('prod_extras')
              ->join('products', 'products.id', '=', 'prod_extras.prod_id')
              ->where('products.prod_partner_id', '=', $partner_info->id, )
              ->whereNull('prod_extras.deleted_at')
              ->select('prod_extras.*', 'products.prod_name AS nombre_producto')
              ->get();

             $partner_address = DB::table('partners')
             ->join('municipios', 'partners.p_mun_id', '=', 'municipios.id')
             ->join('states', 'municipios.states_id', '=', 'states.id')
             ->where('municipios.id', '=', $partner_info->p_mun_id)
              ->select('states.st_name as edo_name', 'states.id as states_id','municipios.mun_name as mun_name','municipios.id as municipio_id')
              ->first();


            $parter_accounts = DB::table('partner_accounts_partners')
             ->join('partners', 'partner_accounts_partners.partners_id', '=', 'partners.id')
             ->where('partner_accounts_partners.partners_id', '=', $partner_info->id)
             ->whereNull('partner_accounts_partners.deleted_at')
             ->select('partner_accounts_partners.id AS ac_id', 
                      'partner_accounts_partners.bank_name',
                      'partner_accounts_partners.bank_account',
                      'partner_accounts_partners.account_type',
                      'partner_accounts_partners.document_account')
             ->get();

           
            $currency_valor = Currencies::all()->first();



            $search[]= ',';
            $replace[] = '.';



           
            return view('partner_info')->with([
            'partner_info' => $partner_info,
            'estados' => $estados,
            'partner_cat' => $partner_cat,
            'categorias_p' => $categorias_p,
            'partner_products' => $partner_products,
            'partner_address' => $partner_address,
            'prod_extras'=> $prod_extras,
            'roles' => $roles,
            'prod_extras' => $prod_extras,
             'currency_valor' => $currency_valor,
             'search' => $search,
             'replace' => $replace,
             'segme' => $segme,
             'parter_accounts' => $parter_accounts

        ]);
    }

    // public function update(Request $request, $id){


    // }

    public function editPartner(Request $request){

        $data = $request->all();

        // dd($data);
        $partner = Partners::find($request->socio_id);
         if ($partner) {
                
                $percent_type  = $request->percent_up;
                $p_shiping_tpye   = $request->p_shipping;
                $p_is_close =  $request->p_is_close;



                $partner->p_user = $request->p_user;
                $partner->p_name = $request->p_name;
                $partner->p_last_name = $request->p_last_name;
                $partner->p_email = $request->p_email;
                $partner->zelle = $request->zelle;
                $partner->p_mun_id = $request->p_municipio;
                $partner->p_adrress = $request->p_address;
                $partner->p_description = $request->p_description;
                $partner->p_cat_id = $request->p_category;
                $partner->sub_cat_id = $request->p_sub_category;
                $partner->p_open_time = $request->open_time;
                $partner->p_close_time = $request->close_time;
                $partner->p_phone_1 = $request->phone_1;
                $partner->p_phone_2 = $request->phone_2;
                $partner->percent_amount = $request->percent_amount;
                $partner->p_lat = $request->p_lat;
                $partner->p_lng = $request->p_lng;
                 if ($percent_type) {
                     $partner->percent_up = $request->percent_up;
                    }else{
                      $partner->percent_up = 'off';
                    }

                 if ($p_shiping_tpye) {
                        $partner->p_shipping = 1;
                    }else{
                        $partner->p_shipping = 0;
                    }   
                 
                 if ($p_is_close) {
                        $partner->p_is_close = 1;
                    }else{
                        $partner->p_is_close = 0;
                    }       
                    
                $partner->p_rif = $request->p_rif;
                $partner->p_dni = $request->p_dni;
                $partner->save();


                    // $speakers  = $request->bank_name; // related ids
                    // $pivotData = $request->bank_account;
                    // $syncData  = array_combine($speakers, $pivotData);

                    // $partner->PartnerAccounts()->sync($syncData);
                 return back();
            }
            else{

                return response()->json(['error'=>  'user de socio ']);
            }
    }
    public function ChangePassword(Request $request){

        $data = $request->all();

        // dd($data);
        $partner = Partners::find($request->socio_id);
         if ($partner) {
                
               $partner->password= Hash::make($request->password);
                $partner->save();
                 return back();
            }
            else{

                return response()->json(['error'=>  'user de socio ']);
            }
    }
    public function editAccountsPartner(Request $request){


       $parter_accounts = PartnerAccounts::find($request->account_id);

        if ($parter_accounts) {
           try {
              
                $parter_accounts->bank_name = $request->bank_name;
                $parter_accounts->bank_account = $request->bank_account;
                $parter_accounts->account_type = $request->account_type;
                $parter_accounts->document_account= $request->document_account;
                $parter_accounts->save();
                return back();
            }catch (Exception $e) {
                return response()->json(['error'=>  $e]);
           }
        }
        else{

             return response()->json(['error'=>  'no sé encuentra la cuenta, por favor verifica nuevamente']);
        }



    }


    public function uploadImagen($id, Request $request){


        $partner = Partners::find($id);
        $file = $request->file('file');
        $path = public_path() . '/images/socios/'.$partner->id;
        $fileName = uniqid() . $file->getClientOriginalName();
        $file->move($path, $fileName);


         if ($partner) {
                $partner->profile_pic = $fileName;
                $partner->save();
                 return back();
            }
            else{

                return response()->json(['error'=>  'user de socio ']);
            }
    }


    public function uploadImagenProduct($id, Request $request)
     {

        $producto = Products::find($id);

        $file = $request->file('file');
        $path = public_path() . '/images/productos/'.$producto->prod_partner_id;
        $fileName = uniqid() . $file->getClientOriginalName();
        $file->move($path, $fileName);


         if ($producto) {
                $producto->prod_image = $fileName;
                $producto->save();
                 return back();
            }
            else{

                return response()->json(['error'=>  'user de socio ']);
            }
    }

     public function deletePartner($id){
            Partners::find($id)->delete($id);

                return response()->json([
                    'success' => 'Record deleted successfully!'
                ]);
    }
}


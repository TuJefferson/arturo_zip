<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Orders;
use DB;
use App\DeliveryMan;
use Response;
use App\Currencies;
use GuzzleHttp\Client;
class OrdersController extends Controller
{

    public function index()
    {


        //script para recargar la pagina. 

        echo "<script>";
        echo "setInterval(function(){
        window.location.reload(1);
        }, 30000);";
        echo "</script>";


        // // $order_partner = DB::table('order_items')
        //     ->join('orders', 'order_items.ord_id', '=', 'orders.id')
        //     ->join('products', 'order_items.prod_id', '=', 'products.id')
        //     ->join('partners', 'products.prod_partner_id', '=', 'partners.id',)
        //     ->where('order_items.ord_id', '=', $request->ord_id)
        //     ->select('partners.p_user', 'partners.id')
        //     ->first();


        $orders_unsigned = DB::table('orders')
            ->join('orders_status_type', 'orders.ord_status', '=', 'orders_status_type.id')
            ->join('clients_address', 'orders.ord_address', '=', 'clients_address.id')
            ->join('address', 'clients_address.ca_address_id', '=', 'address.id')
            ->join('aviable_zones', 'address.zon_id', '=', 'aviable_zones.id')
            ->join('clients', 'clients_address.ca_cl_id', '=', 'clients.id')
            ->join('municipios', 'address.mun_id', '=', 'municipios.id')
            ->join('order_items', 'order_items.ord_id', '=', 'orders.id')
            ->join('partners', 'order_items.order_partner_id', '=', 'partners.id',)
            ->where('orders.ord_status', '=', 1)
            ->select('orders.id',
                     'orders.created_at', 
                     'orders.bank_name', 
                     'orders.zelle_name', 
                     'orders.pay_by_zelle', 
                     'orders.zelle_email', 
                     'orders.ref_pay', 
                     'clients.cl_name', 
                     'clients.cl_email', 
                     'orders_status_type.status_name', 
                     'orders.ord_status AS ord_status', 
                     'address.description AS address_description', 
                     'municipios.mun_name AS municipio', 
                     'aviable_zones.zone_name AS zone_name',
                     'partners.p_user', 'partners.id AS p_id')
            ->orderBy('created_at', 'desc')
            ->distinct()
            ->get();
            // dd($orders_unsigned);
        $orders_aproved_by_admin = DB::table('orders')->join('orders_status_type', 'orders.ord_status', '=', 'orders_status_type.id')
            ->join('clients_address', 'orders.ord_address', '=', 'clients_address.id')
            ->join('address', 'clients_address.ca_address_id', '=', 'address.id')
            ->join('aviable_zones', 'address.zon_id', '=', 'aviable_zones.id')
            ->join('clients', 'clients_address.ca_cl_id', '=', 'clients.id')
            ->join('municipios', 'address.mun_id', '=', 'municipios.id')
            ->join('order_items', 'order_items.ord_id', '=', 'orders.id')
            ->join('partners', 'order_items.order_partner_id', '=', 'partners.id')
            ->where('orders.ord_status', '=', 2)
            ->select('orders.id', 
                'orders.created_at', 
                'orders.bank_name', 
                'orders.zelle_name', 
                'orders.pay_by_zelle', 
                'orders.zelle_email', 
                'orders.ref_pay', 
                'clients.cl_name', 
                'clients.cl_email', 
                'orders_status_type.status_name', 
                'orders.ord_status AS ord_status', 
                'address.description AS address_description', 
                'municipios.mun_name AS municipio', 
                'aviable_zones.zone_name AS zone_name',
                'partners.p_user', 'partners.id AS p_id')
            ->orderBy('created_at', 'desc')
            ->distinct()
            ->get();

        $orders_aproved_by_partner = DB::table('orders')->join('orders_status_type', 'orders.ord_status', '=', 'orders_status_type.id')
            ->join('clients_address', 'orders.ord_address', '=', 'clients_address.id')
            ->join('address', 'clients_address.ca_address_id', '=', 'address.id')
            ->join('aviable_zones', 'address.zon_id', '=', 'aviable_zones.id')
            ->join('clients', 'clients_address.ca_cl_id', '=', 'clients.id')
            ->join('municipios', 'address.mun_id', '=', 'municipios.id')
            ->join('order_items', 'order_items.ord_id', '=', 'orders.id')
            ->join('partners', 'order_items.order_partner_id', '=', 'partners.id')
            ->where('orders.ord_status', '=', 3)
            ->select('orders.id', 
                'orders.created_at', 
                'orders.bank_name', 
                'orders.zelle_name', 
                'orders.pay_by_zelle', 
                'orders.zelle_email', 
                'orders.ref_pay', 
                'clients.cl_name', 
                'clients.cl_email', 
                'orders_status_type.status_name', 
                'orders.ord_status AS ord_status', 
                'address.description AS address_description', 
                'municipios.mun_name AS municipio', 
                'aviable_zones.zone_name AS zone_name',
                'partners.p_user', 'partners.id AS p_id')
            ->orderBy('created_at', 'desc')
            ->distinct()
            ->get();

        $orders_on_the_way = DB::table('orders')->join('orders_status_type', 'orders.ord_status', '=', 'orders_status_type.id')
            ->join('clients_address', 'orders.ord_address', '=', 'clients_address.id')
            ->join('address', 'clients_address.ca_address_id', '=', 'address.id')
            ->join('aviable_zones', 'address.zon_id', '=', 'aviable_zones.id')
            ->join('clients', 'clients_address.ca_cl_id', '=', 'clients.id')
            ->join('municipios', 'address.mun_id', '=', 'municipios.id')
            ->join('order_items', 'order_items.ord_id', '=', 'orders.id')
            ->join('partners', 'order_items.order_partner_id', '=', 'partners.id')
            ->where('orders.ord_status', '=', 5)
            ->select('orders.id', 
                'orders.created_at', 
                'orders.bank_name', 
                'orders.zelle_name', 
                'orders.pay_by_zelle', 
                'orders.zelle_email', 
                'orders.ref_pay', 
                'clients.cl_name', 
                'clients.cl_email', 
                'orders_status_type.status_name', 
                'orders.ord_status AS ord_status', 
                'address.description AS address_description', 
                'municipios.mun_name AS municipio', 
                'aviable_zones.zone_name AS zone_name',
                'partners.p_user', 'partners.id AS p_id')
            ->orderBy('created_at', 'desc')
            ->distinct()
            ->get();

        $orders_aprov_dm = DB::table('orders')->join('orders_status_type', 'orders.ord_status', '=', 'orders_status_type.id')
            ->join('clients_address', 'orders.ord_address', '=', 'clients_address.id')
            ->join('address', 'clients_address.ca_address_id', '=', 'address.id')
            ->join('aviable_zones', 'address.zon_id', '=', 'aviable_zones.id')
            ->join('clients', 'clients_address.ca_cl_id', '=', 'clients.id')
            ->join('municipios', 'address.mun_id', '=', 'municipios.id')
            ->join('order_items', 'order_items.ord_id', '=', 'orders.id')
            ->join('partners', 'order_items.order_partner_id', '=', 'partners.id')
            ->where('orders.ord_status', '=', 0)
            ->select('orders.id', 
                'orders.created_at', 
                'orders.bank_name', 
                'orders.zelle_name', 
                'orders.pay_by_zelle',
                'orders.zelle_email', 
                'orders.ref_pay', 
                'clients.cl_name', 
                'clients.cl_email', 
                'orders_status_type.status_name', 
                'orders.ord_status AS ord_status', 
                'address.description AS address_description', 
                'municipios.mun_name AS municipio', 
                'aviable_zones.zone_name AS zone_name',
                'partners.p_user', 'partners.id AS p_id')
            ->orderBy('created_at', 'desc')
            ->distinct()
            ->get();
        $orders_delivered = DB::table('orders')->join('orders_status_type', 'orders.ord_status', '=', 'orders_status_type.id')
            ->join('clients_address', 'orders.ord_address', '=', 'clients_address.id')
            ->join('address', 'clients_address.ca_address_id', '=', 'address.id')
            ->join('aviable_zones', 'address.zon_id', '=', 'aviable_zones.id')
            ->join('clients', 'clients_address.ca_cl_id', '=', 'clients.id')
            ->join('municipios', 'address.mun_id', '=', 'municipios.id')
            ->join('order_items', 'order_items.ord_id', '=', 'orders.id')
            ->join('partners', 'order_items.order_partner_id', '=', 'partners.id')
            ->where('orders.ord_status', '=', 4)
            ->select('orders.id', 
                     'orders.created_at', 
                     'orders.bank_name', 
                     'orders.zelle_name', 
                     'orders.pay_by_zelle',
                     'orders.zelle_email', 
                     'orders.ref_pay', 
                     'clients.cl_name', 
                     'clients.cl_email', 
                     'orders_status_type.status_name', 
                     'orders.ord_status AS ord_status', 
                     'address.description AS address_description', 
                     'municipios.mun_name AS municipio', 
                     'aviable_zones.zone_name AS zone_name',
                     'partners.p_user', 'partners.id AS p_id')
            ->orderBy('created_at', 'desc')
            ->distinct()
            ->get();

        return view('orders')
            ->with(['orders_delivered' => $orders_delivered, 'orders_on_the_way' => $orders_on_the_way, 'orders_aproved_by_admin' => $orders_aproved_by_admin, 'orders_unsigned' => $orders_unsigned, 'orders_aproved_by_partner' => $orders_aproved_by_partner, 'orders_aprov_dm' => $orders_aprov_dm]);
    }

    public function orderDetail(Request $request)
    {

        $orders_detail = DB::table('orders')
            ->join('orders_status_type', 'orders.ord_status', '=', 'orders_status_type.id')
            ->join('clients_address', 'orders.ord_address', '=', 'clients_address.id')
            ->join('address', 'clients_address.ca_address_id', '=', 'address.id')
            ->join('aviable_zones', 'address.zon_id', '=', 'aviable_zones.id')
            ->join('clients', 'clients_address.ca_cl_id', '=', 'clients.id')
            ->join('municipios', 'address.mun_id', '=', 'municipios.id')
            ->leftJoin('its_banks', 'orders.bank_id', '=', 'its_banks.id')
            ->where('orders.id', '=', $request->ord_id)
            ->select('orders.id', 
              'its_banks.id AS from_bank_id', 
              'its_banks.bank_name AS from_bank_name', 
              'orders.bank_name', 'orders.created_at', 
              'orders.zelle_name', 'orders.pay_by_zelle', 
              'orders.zelle_email',
              'orders.ref_pay', 
              'orders.ref_pay_image',
              'orders.ord_description', 
              'orders.order_dm_val',
              'orders.order_time',
              'orders.order_use_percent',
              'orders.current_ex_price',
              'clients.cl_name AS name_client', 
              'clients.cl_email AS email_client', 
              'clients.cl_phone_1 AS cl_phone_1',
              'clients.id AS cl_id', 
              'orders_status_type.status_name', 
              'orders.ord_status AS ord_status',
              'address.description AS address_description', 
              'address.address_lon AS address_lon',
              'address.address_lat AS address_lat',
              'municipios.mun_name AS municipio',
              'aviable_zones.zone_name AS zone_name',
                )       
            ->first();

        $all_deliveries = DeliveryMan::select('id', 'dm_name', 'dm_last_name')->get();
        $currency_valor = Currencies::all()->first();

        $order_delivery_guy = DB::table('orders')->leftJoin('delivery_man', 'orders.ord_dm_id', '=', 'delivery_man.id')
            ->select('delivery_man.id AS dm_id', 
                     'delivery_man.dm_name',
                     'delivery_man.dm_last_name',  
                     'delivery_man.dm_email AS dm_email')
            ->where('orders.id', '=', $orders_detail->id)
            ->first();

        $order_items = DB::table('order_items')->join('orders', 'order_items.ord_id', '=', 'orders.id')
            ->join('products', 'order_items.prod_id', '=', 'products.id')
            ->join('partners', 'products.prod_partner_id', '=', 'partners.id',)
            ->where('order_items.ord_id', '=', $request->ord_id)
            ->select('products.prod_name AS name_product', 
               'partners.p_user AS partner_name', 
               'orders.ord_description',
               'products.prod_description AS desc_product', 
               'products.prod_price_usd AS prod_price', 
               'order_items.quantity AS prod_quantity',
               'order_items.id AS item_id',)
            ->get();
        $dot[] = ',';
        $point[] = '.';
        foreach ($order_items as $product)
        {

            $prod_ids = $product->item_id;
            $extras = DB::table('prod_extras')
                    ->join('order_items_order_items_extra', 'prod_extras.id', '=', 'order_items_order_items_extra.order_items_extra_id')
                    ->join('order_items', 'order_items_order_items_extra.order_items_id', '=', 'order_items.id')
                     ->where('order_items_order_items_extra.order_items_id', '=', $prod_ids)
                     ->select('prod_extras.pe_name AS extra_name', 
                              'prod_extras.id',
                              'prod_extras.pe_price_usd AS extra_price', 
                              'prod_extras.prod_type AS extra_type')
                ->get();

            $a = 0;
            $array_empty = [];
            if (count($extras) <= $a)
            {
                $product->extras = $array_empty;

            }
            else
            {
                $product->extras = $extras;
            }

        }
        

        $order_subtotal_price = 0;
        $order_total = 0;
         $search[] = ',';
        $replace[] = '.';
        foreach ($order_items as $num)
        {

            $order_subtotal_price += str_replace($dot, $point, $num->prod_price * $num->prod_quantity) ;

            foreach ($num->extras as $prod_extra)
            {
                $order_subtotal_price += str_replace($dot, $point, $prod_extra->extra_price);
            }
        }
        $order_total += str_replace($dot, $point, $orders_detail->order_dm_val + $order_subtotal_price);


        $order_total += str_replace($dot, $point, round($orders_detail->order_use_percent*$order_subtotal_price / 100,3));


        // $order_total += str_replace($dot, $point, $orders_detail->order_use_percent + $order_subtotal_price);
        



        $order_status = DB::table('orders_status_type')->select('orders_status_type.id', 'orders_status_type.status_name')
            ->get();

        $order_partner = DB::table('order_items')
            ->join('orders', 'order_items.ord_id', '=', 'orders.id')
            ->join('products', 'order_items.prod_id', '=', 'products.id')
            ->join('partners', 'products.prod_partner_id', '=', 'partners.id',)
            ->where('order_items.ord_id', '=', $request->ord_id)
            ->select('partners.p_user', 'partners.id')
            ->first();

        return view('order_detail')
            ->with(['orders_detail' => $orders_detail, 
                    'order_items' => $order_items,
                    'order_delivery_guy' => $order_delivery_guy,
                    'order_partner' => $order_partner, 
                    'all_deliveries' => $all_deliveries, 
                    'currency_valor' => $currency_valor, 
                    'order_status' => $order_status, 
                    'search' => $search, 
                    'replace' => $replace, 
                    'order_subtotal_price' => $order_subtotal_price,
                    'order_total' =>  $order_total

        ]);

    }

    public function updateOrderDeliveryMan(Request $request)
    {

        $order = Orders::find($request->ord_id);
        if ($order)
        {

            $order->ord_dm_id = $request->dm_id;
            $order->save();
            $Response = array(
                'success' => '1',
            );
            return response()->json('success');
        }
        else
        {

            return response()
                ->json(['error' => 'no sé encuentra el repartidor, por favor verifica nuevamente']);
        }

    }

    public function updateStatusOrderDetail(Request $request)
    {

        // dd($request);
        $order = Orders::find($request->order_id);

        if ($order)
        {


            $order->ord_status = $request->order_status;
            $order->save();

            if ($request->order_status  ==  2) {
            


                $client = new Client();
                $res = $client->request('POST', 'http://push-notificacion.itsontheway.com.ve/order-approved', [
                'json' => [
                    'clientId' => $request->clientId,
                    'orderId' => $request->order_id,
                    'partnerId' => $request->partnerId,
                    ]
                 ]);

            }
            
            return response()->json('success');
        }
        else
        {
            return response()->json('asda');
        }
    }
}


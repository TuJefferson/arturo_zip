<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Partners;
use App\States;
use App\Municipios;
use App\RoleUsers;
use App\CategoriesPartners;
use Hash;
use App\PartnerAccounts;

use App\SubCategory;

class SociosController extends Controller
{

	public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {

    	$partners = Partners::orderBy('created_at','desc')->get();
        $estados = States::all();
        $roles = RoleUsers::all();
        $categorias_p = CategoriesPartners::all();
    	// dd($partners);

        return view('partners')->with([
            'partners' => $partners,
            'estados' => $estados,
            'roles' => $roles,
            'categorias_p' => $categorias_p,
        ]);
    }

    public function municipios($id){

        return Municipios::where('states_id','=',$id)->get();

    }
    public function subcategory($id){

        return SubCategory::where('cat_id','=',$id)->get();

    }

    public function storePartner(Request $request){

        $data = $request->all();

        // dd($data);
        
        $partner = Partners::find($request->p_email);
         if (!$partner) {
                $partner = new Partners;
                $partner->p_user = $request->p_user;
                $partner->p_name = $request->p_name;
                $partner->p_last_name = $request->p_last_name;
                $partner->p_email = $request->p_email;
                $partner->password= Hash::make($request->password);
                $partner->zelle = $request->zelle;
                $partner->p_mun_id = $request->p_municipio;
                $partner->p_adrress = $request->p_address;
                $partner->p_description = $request->p_description;
                $partner->p_cat_id = $request->p_category;
                $partner->sub_cat_id = $request->p_sub_category;
                $partner->p_open_time = $request->open_time;
                $partner->p_close_time = $request->close_time;
                $partner->p_phone_1 = $request->phone_1;
                $partner->p_phone_2 = $request->phone_2;
                $partner->percent_amount = $request->percent_amount;
                $partner->percent_up = $request->percent_up;
                $partner->p_rif = $request->p_rif;
                $partner->p_lat = $request->p_lat;
                $partner->p_lng = $request->p_lng;
                 $partner->save();

                   $p_accounts = json_decode($request->input('bankAcountJSON'));
                    foreach ($p_accounts->value as $p_account_p)
                    {

                        $p_account = new PartnerAccounts;
                        $p_account->partners_id =  $partner->id;
                        $p_account->bank_name =    $p_account_p->name;
                        $p_account->account_type = $p_account_p->account_type;
                        $p_account->document_account = $p_account_p->document_account;
                        $p_account->bank_account = $p_account_p->bank_account;
                        $p_account->save();

                    }


               
               return back();
            }
            else{

                return response()->json(['error'=>  'user de socio ya registrado']);
            }

    }



}

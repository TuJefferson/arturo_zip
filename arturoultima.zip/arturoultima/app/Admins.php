<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Tymon\JWTAuth\Contracts\JWTSubject;
use Illuminate\Foundation\Auth\Admins as Authenticatable;
use Illuminate\Notifications\Notifiable;

class Admins extends Authenticatable implements JWTSubject
{

    use Notifiable;

    	 protected $fillable = [
            'ad_name', 'email',
            'ad_last_name',
            'ad_user_name',
            'ad_rs_id',
            'password'
        ];


        protected $hidden = [
            'password', 'remember_token',
        ];

        /*
            Añadiremos estos dos métodos
        */

        public function getJWTIdentifier()
        {
            return $this->getKey();
        }
        public function getJWTCustomClaims()
        {
            return [];
        }

}

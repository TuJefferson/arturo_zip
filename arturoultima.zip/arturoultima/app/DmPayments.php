<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class DmPayments extends Model
{
    use SoftDeletes;
    protected $table = 'dm_payments';
}

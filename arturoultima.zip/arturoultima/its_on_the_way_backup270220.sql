/*
Navicat MySQL Data Transfer

Source Server         : local_host
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : its_on_the_way

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2020-02-27 11:30:27
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for address
-- ----------------------------
DROP TABLE IF EXISTS `address`;
CREATE TABLE `address` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `st_id` bigint(20) unsigned DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `address_st_id_foreign` (`st_id`),
  CONSTRAINT `address_st_id_foreign` FOREIGN KEY (`st_id`) REFERENCES `states` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for admins
-- ----------------------------
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ad_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ad_last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ad_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ad_user_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ad_intents` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ad_blocked` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ad_pass_exp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ad_rs_id` bigint(20) unsigned DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admins_ad_email_unique` (`ad_email`),
  UNIQUE KEY `admins_ad_user_name_unique` (`ad_user_name`),
  KEY `admins_ad_rs_id_foreign` (`ad_rs_id`),
  CONSTRAINT `admins_ad_rs_id_foreign` FOREIGN KEY (`ad_rs_id`) REFERENCES `roles_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for categories
-- ----------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for clients
-- ----------------------------
DROP TABLE IF EXISTS `clients`;
CREATE TABLE `clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cl_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_user` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_rs_id` bigint(20) unsigned DEFAULT NULL,
  `cl_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_verified` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_dni` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_intents` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_blocked` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_pass_exp` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clients_cl_email_unique` (`cl_email`),
  KEY `clients_cl_rs_id_foreign` (`cl_rs_id`),
  CONSTRAINT `clients_cl_rs_id_foreign` FOREIGN KEY (`cl_rs_id`) REFERENCES `roles_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for clients_address
-- ----------------------------
DROP TABLE IF EXISTS `clients_address`;
CREATE TABLE `clients_address` (
  `ca_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ca_cl_id` bigint(20) unsigned DEFAULT NULL,
  `ca_address_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`ca_id`),
  KEY `clients_address_ca_cl_id_foreign` (`ca_cl_id`),
  KEY `clients_address_ca_address_id_foreign` (`ca_address_id`),
  CONSTRAINT `clients_address_ca_address_id_foreign` FOREIGN KEY (`ca_address_id`) REFERENCES `address` (`id`),
  CONSTRAINT `clients_address_ca_cl_id_foreign` FOREIGN KEY (`ca_cl_id`) REFERENCES `clients` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for curriencies
-- ----------------------------
DROP TABLE IF EXISTS `curriencies`;
CREATE TABLE `curriencies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cur_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cur_value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for delivery_man
-- ----------------------------
DROP TABLE IF EXISTS `delivery_man`;
CREATE TABLE `delivery_man` (
  `dm_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dm_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_rs_id` bigint(20) unsigned DEFAULT NULL,
  `dm_user` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_intents` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_blocked` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_pass_exp` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_rate` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`dm_id`),
  UNIQUE KEY `delivery_man_dm_user_unique` (`dm_user`),
  UNIQUE KEY `delivery_man_dm_email_unique` (`dm_email`),
  KEY `delivery_man_dm_rs_id_foreign` (`dm_rs_id`),
  CONSTRAINT `delivery_man_dm_rs_id_foreign` FOREIGN KEY (`dm_rs_id`) REFERENCES `roles_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for migrations
-- ----------------------------
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for municipios
-- ----------------------------
DROP TABLE IF EXISTS `municipios`;
CREATE TABLE `municipios` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `states_id` bigint(20) unsigned NOT NULL,
  `mun_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `municipios_states_id_foreign` (`states_id`),
  CONSTRAINT `municipios_states_id_foreign` FOREIGN KEY (`states_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=336 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ord_prod_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_prod_id` bigint(20) unsigned DEFAULT NULL,
  `ord_price_bs` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_price_usd` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_delivered` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_extras` bigint(20) unsigned DEFAULT NULL,
  `ord_rate` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_dm_rate` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_ord_prod_id_foreign` (`ord_prod_id`),
  KEY `orders_ord_extras_foreign` (`ord_extras`),
  CONSTRAINT `orders_ord_extras_foreign` FOREIGN KEY (`ord_extras`) REFERENCES `prod_extras` (`id`),
  CONSTRAINT `orders_ord_prod_id_foreign` FOREIGN KEY (`ord_prod_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for partners
-- ----------------------------
DROP TABLE IF EXISTS `partners`;
CREATE TABLE `partners` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `p_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_rs_id` bigint(20) unsigned DEFAULT NULL,
  `p_st_id` bigint(20) unsigned DEFAULT NULL,
  `p_mun_id` bigint(20) NOT NULL,
  `p_adrress` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_user` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_cat_id` bigint(20) unsigned DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_intents` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_blocked` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_pass_exp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_rate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `partners_p_user_unique` (`p_user`),
  UNIQUE KEY `partners_p_email_unique` (`p_email`),
  KEY `partners_p_rs_id_foreign` (`p_rs_id`),
  KEY `partners_p_st_id_foreign` (`p_st_id`),
  KEY `partners_p_cat_id_foreign` (`p_cat_id`),
  CONSTRAINT `partners_p_cat_id_foreign` FOREIGN KEY (`p_cat_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `partners_p_rs_id_foreign` FOREIGN KEY (`p_rs_id`) REFERENCES `roles_users` (`id`),
  CONSTRAINT `partners_p_st_id_foreign` FOREIGN KEY (`p_st_id`) REFERENCES `states` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for password_resets
-- ----------------------------
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for products
-- ----------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `prod_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prod_partner_id` bigint(20) unsigned DEFAULT NULL,
  `prod_price_bs` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prod_price_usd` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prod_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `products_prod_partner_id_foreign` (`prod_partner_id`),
  CONSTRAINT `products_prod_partner_id_foreign` FOREIGN KEY (`prod_partner_id`) REFERENCES `partners` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for prod_extras
-- ----------------------------
DROP TABLE IF EXISTS `prod_extras`;
CREATE TABLE `prod_extras` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pe_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pe_price_bs` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pe_price_usd` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pe_partner_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prod_extras_pe_partner_id_foreign` (`pe_partner_id`),
  CONSTRAINT `prod_extras_pe_partner_id_foreign` FOREIGN KEY (`pe_partner_id`) REFERENCES `partners` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for rates
-- ----------------------------
DROP TABLE IF EXISTS `rates`;
CREATE TABLE `rates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rt_value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for rate_list
-- ----------------------------
DROP TABLE IF EXISTS `rate_list`;
CREATE TABLE `rate_list` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rate_order_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rate_list_rate_order_id_foreign` (`rate_order_id`),
  CONSTRAINT `rate_list_rate_order_id_foreign` FOREIGN KEY (`rate_order_id`) REFERENCES `orders` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for roles_permissions
-- ----------------------------
DROP TABLE IF EXISTS `roles_permissions`;
CREATE TABLE `roles_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for roles_users
-- ----------------------------
DROP TABLE IF EXISTS `roles_users`;
CREATE TABLE `roles_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rs_perms_id` bigint(20) unsigned NOT NULL,
  `rs_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `roles_users_rs_perms_id_foreign` (`rs_perms_id`),
  CONSTRAINT `roles_users_rs_perms_id_foreign` FOREIGN KEY (`rs_perms_id`) REFERENCES `roles_permissions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for states
-- ----------------------------
DROP TABLE IF EXISTS `states`;
CREATE TABLE `states` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `st_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `st_iso` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

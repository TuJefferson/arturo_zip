/*
Navicat MySQL Data Transfer

Source Server         : local_host
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : its_on_the_way

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2020-03-16 12:44:23
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for address
-- ----------------------------
DROP TABLE IF EXISTS `address`;
CREATE TABLE `address` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `st_id` bigint(20) unsigned DEFAULT NULL,
  `mun_id` bigint(20) unsigned DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `address_st_id_foreign` (`st_id`),
  KEY `address_mun_id_foreign` (`mun_id`),
  CONSTRAINT `address_mun_id_foreign` FOREIGN KEY (`mun_id`) REFERENCES `municipios` (`id`),
  CONSTRAINT `address_st_id_foreign` FOREIGN KEY (`st_id`) REFERENCES `states` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of address
-- ----------------------------
INSERT INTO `address` VALUES ('1', '2', '1', 'tenetur', null, null, null);
INSERT INTO `address` VALUES ('2', '3', '2', 'ab', null, null, null);
INSERT INTO `address` VALUES ('3', '14', '1', 'harum', null, null, null);
INSERT INTO `address` VALUES ('4', '19', '2', 'tempora', null, null, null);
INSERT INTO `address` VALUES ('5', '17', '1', 'modi', null, null, null);
INSERT INTO `address` VALUES ('6', '12', '1', 'illo', null, null, null);
INSERT INTO `address` VALUES ('7', '12', '1', 'odit', null, null, null);
INSERT INTO `address` VALUES ('8', '19', '2', 'necessitatibus', null, null, null);
INSERT INTO `address` VALUES ('9', '4', '1', 'exercitationem', null, null, null);
INSERT INTO `address` VALUES ('10', '5', '1', 'placeat', null, null, null);

-- ----------------------------
-- Table structure for admins
-- ----------------------------
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ad_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ad_last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ad_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ad_user_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ad_rs_id` bigint(20) unsigned DEFAULT NULL,
  `ad_intents` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ad_blocked` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ad_pass_exp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admins_ad_email_unique` (`ad_email`),
  UNIQUE KEY `admins_ad_user_name_unique` (`ad_user_name`),
  KEY `admins_ad_rs_id_foreign` (`ad_rs_id`),
  CONSTRAINT `admins_ad_rs_id_foreign` FOREIGN KEY (`ad_rs_id`) REFERENCES `roles_users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of admins
-- ----------------------------

-- ----------------------------
-- Table structure for categories
-- ----------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of categories
-- ----------------------------
INSERT INTO `categories` VALUES ('1', 'quidem', null, null, null);
INSERT INTO `categories` VALUES ('2', 'ea', null, null, null);
INSERT INTO `categories` VALUES ('3', 'molestias', null, null, null);
INSERT INTO `categories` VALUES ('4', 'occaecati', null, null, null);
INSERT INTO `categories` VALUES ('5', 'est', null, null, null);
INSERT INTO `categories` VALUES ('6', 'suscipit', null, null, null);
INSERT INTO `categories` VALUES ('7', 'tempore', null, null, null);
INSERT INTO `categories` VALUES ('8', 'architecto', null, null, null);
INSERT INTO `categories` VALUES ('9', 'officiis', null, null, null);
INSERT INTO `categories` VALUES ('10', 'aut', null, null, null);

-- ----------------------------
-- Table structure for clients
-- ----------------------------
DROP TABLE IF EXISTS `clients`;
CREATE TABLE `clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cl_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_user` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_dni` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_phone_1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_phone_2` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_rs_id` bigint(20) unsigned DEFAULT NULL,
  `cl_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_verified` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_intents` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cl_blocked` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cl_pass_exp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clients_cl_user_unique` (`cl_user`),
  UNIQUE KEY `clients_cl_email_unique` (`cl_email`),
  KEY `clients_cl_rs_id_foreign` (`cl_rs_id`),
  CONSTRAINT `clients_cl_rs_id_foreign` FOREIGN KEY (`cl_rs_id`) REFERENCES `roles_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of clients
-- ----------------------------
INSERT INTO `clients` VALUES ('1', 'Margaret Weber', 'Hackett', 'quis', '6', '(585) 634-9588', '(564) 653-4598 x444', null, 'alvina.jast@yahoo.com', null, '$2y$10$zsmvSSKlvKCIXPt8jAvgc.9aqzzvr8fLFdQPQfOacIUWn8H2dl572', null, null, null, null, null, null, null);
INSERT INTO `clients` VALUES ('2', 'Skyla Anderson', 'Huels', 'eius', '7', '448.551.9863', '1-593-208-8989 x84829', null, 'hugh20@gmail.com', null, '$2y$10$iWJHuYZYQrrOe3d72mfn2OKlNHArekIwg8gIIKH2pQKpz9iqQKkOy', null, null, null, null, null, null, null);
INSERT INTO `clients` VALUES ('3', 'Yadira Dicki', 'Collins', 'illum', '1', '1-247-838-9043', '608.495.3273', null, 'yherman@yahoo.com', null, '$2y$10$xZtC.mAzMU6zcKS99FJ/6eonfrJrkjFPO14wIKVooCo0p0NL.vTym', null, null, null, null, null, null, null);
INSERT INTO `clients` VALUES ('4', 'Viva Windler DDS', 'Hintz', 'inventore', '4', '402.836.1609', '368-327-3639', null, 'ernestina.christiansen@gmail.com', null, '$2y$10$pH3NF8xCfwm6zCKyqWcvZ.M7hO1iJHTC2P5O9aHq/yhzJ3p2QUBMG', null, null, null, null, null, null, null);
INSERT INTO `clients` VALUES ('5', 'Jeramie Kassulke', 'Beahan', 'tempore', '9', '+1.678.969.0706', '619.490.0240 x80000', null, 'fleuschke@hotmail.com', null, '$2y$10$aSKkIuyXX385/QRJoKd6FueVYu9jVp7hShzYOyFy5bJVCmNIHP3WS', null, null, null, null, null, null, null);
INSERT INTO `clients` VALUES ('6', 'Jarvis Rowe', 'Altenwerth', 'facilis', '1', '1-437-856-9571 x3886', '926-572-5218 x4436', null, 'godfrey22@yahoo.com', null, '$2y$10$hHSyqkix99NcdRxf392os.zv1DYrYz7e8aVEaEPJMNBGlllwINw32', null, null, null, null, null, null, null);
INSERT INTO `clients` VALUES ('7', 'Rosalind Steuber', 'Wuckert', 'sit', '6', '+1.789.818.6021', '1-652-351-7639 x29776', null, 'tyreek71@pagac.info', null, '$2y$10$XvLh6p/lw1igLEg8VPZGaOOJbL8AwEAVPNYnepXcH.aCbjUTLOCOq', null, null, null, null, null, null, null);
INSERT INTO `clients` VALUES ('8', 'Royal Ryan', 'Dooley', 'consequatur', '4', '+1-660-348-1141', '+14685305817', null, 'deckow.heather@stoltenberg.com', null, '$2y$10$DLSPc.8qpGnEfi16HvY2demSVvI1TqiQoqKKkrioUslccGKI.cjUy', null, null, null, null, null, null, null);
INSERT INTO `clients` VALUES ('9', 'Prof. Jadon Lowe IV', 'Boehm', 'sed', '5', '+1-578-909-0560', '+17288414962', null, 'malachi.schinner@vonrueden.com', null, '$2y$10$s98hx1zBad.VwlqjA.9QwOUCJKX8Fq7v2I702.ig4hw3vBYi5PFGq', null, null, null, null, null, null, null);
INSERT INTO `clients` VALUES ('10', 'Spencer Ernser', 'Harber', 'nostrum', '6', '327.417.6567 x274', '(697) 518-7168 x6333', null, 'alessandra81@hotmail.com', null, '$2y$10$jB0nYXwJ3jUBtnyBl0gFJOwuh.vBcyO/6bceyQhGaRdqM5lVAeoiq', null, null, null, null, null, null, null);

-- ----------------------------
-- Table structure for clients_address
-- ----------------------------
DROP TABLE IF EXISTS `clients_address`;
CREATE TABLE `clients_address` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ca_cl_id` bigint(20) unsigned DEFAULT NULL,
  `ca_address_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clients_address_ca_cl_id_foreign` (`ca_cl_id`),
  KEY `clients_address_ca_address_id_foreign` (`ca_address_id`),
  CONSTRAINT `clients_address_ca_address_id_foreign` FOREIGN KEY (`ca_address_id`) REFERENCES `address` (`id`),
  CONSTRAINT `clients_address_ca_cl_id_foreign` FOREIGN KEY (`ca_cl_id`) REFERENCES `clients` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of clients_address
-- ----------------------------
INSERT INTO `clients_address` VALUES ('1', '1', '1', '2020-03-12 23:52:32', null, null);

-- ----------------------------
-- Table structure for curriencies
-- ----------------------------
DROP TABLE IF EXISTS `curriencies`;
CREATE TABLE `curriencies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cur_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cur_value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of curriencies
-- ----------------------------

-- ----------------------------
-- Table structure for delivery_man
-- ----------------------------
DROP TABLE IF EXISTS `delivery_man`;
CREATE TABLE `delivery_man` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dm_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_user` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user.jpg',
  `dm_phone_1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_phone_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dm_rs_id` bigint(20) unsigned DEFAULT NULL,
  `dm_rate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dm_intents` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dm_blocked` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dm_pass_exp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `delivery_man_dm_user_unique` (`dm_user`),
  UNIQUE KEY `delivery_man_dm_email_unique` (`dm_email`),
  KEY `delivery_man_dm_rs_id_foreign` (`dm_rs_id`),
  CONSTRAINT `delivery_man_dm_rs_id_foreign` FOREIGN KEY (`dm_rs_id`) REFERENCES `roles_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of delivery_man
-- ----------------------------
INSERT INTO `delivery_man` VALUES ('1', 'Dr. Jayden McDermott', 'Yost', 'adipisci', 'legros.lafayette@hotmail.com', '$2y$10$3RD5YPzZFKYtCUHUhCEw.eypUGOdNI/9OgRKHnRbpLCKjVC89Lnke', 'user.jpg', '1-642-717-2788', '(405) 244-9433', null, null, null, null, null, null, null, null, null);
INSERT INTO `delivery_man` VALUES ('2', 'Karianne Ziemann', 'Kessler', 'dolore', 'tyshawn39@haley.org', '$2y$10$K0K6qx02kTvZ2EOIJHlWCe9uFfiOyxzgztIhKEDQvjX1imwWWMixW', 'user.jpg', '914-561-1040', '+1-718-433-5653', null, null, null, null, null, null, null, null, null);
INSERT INTO `delivery_man` VALUES ('3', 'Dr. Michale Bruen', 'Altenwerth', 'provident', 'jesus.orn@hotmail.com', '$2y$10$pPXB0EEEWE67h/v67Nt3BuSB2S/s8O4o.ddspegjx7DO3g7Mn.tFy', 'user.jpg', '240.542.1368 x2782', '(390) 289-5442 x8452', null, null, null, null, null, null, null, null, null);
INSERT INTO `delivery_man` VALUES ('4', 'Gonzalo Hamill', 'Gutmann', 'consequuntur', 'uriah.dibbert@yahoo.com', '$2y$10$1cV8QPvpk5YLglLXh9lrEOw239rVyMgwMj8/PtOz2sbhEwrgL3NZO', 'user.jpg', '1-741-204-5184 x110', '+1-237-335-9316', null, null, null, null, null, null, null, null, null);
INSERT INTO `delivery_man` VALUES ('5', 'Prof. Chloe McGlynn Jr.', 'Crooks', 'maxime', 'kobe.bayer@hotmail.com', '$2y$10$h.jwMDqJMODtZ/kr7LN2DOsIUv26n80ifSTn8xl/0JjvyxWnhcYSa', 'user.jpg', '(517) 216-3592 x5324', '463.839.0368', null, null, null, null, null, null, null, null, null);
INSERT INTO `delivery_man` VALUES ('6', 'Dennis Rowe', 'Pfannerstill', 'et', 'sporer.lysanne@gmail.com', '$2y$10$5LBwKCsJFVutGkYUMriXQeCeMqSMhxUT7KV5/zU/A/LEnqxT79myS', 'user.jpg', '552.859.1576', '1-915-873-8085', null, null, null, null, null, null, null, null, null);
INSERT INTO `delivery_man` VALUES ('7', 'Lyla Green', 'Collins', 'voluptatibus', 'botsford.katrina@welch.com', '$2y$10$PBZ2rR1WT4qx35qf7.xSGOWqtehaKqZZQXpAts5MdPG1AEjCoOMS.', 'user.jpg', '1-893-417-2197', '469.889.0914', null, null, null, null, null, null, null, null, null);
INSERT INTO `delivery_man` VALUES ('8', 'Miss Dixie Schultz', 'Baumbach', 'autem', 'emmerich.izabella@yahoo.com', '$2y$10$t4H7rPhoTCfsWYXL5s5Bdu28S0frU/BCFIcfQwIr2jTmyp9hxzP6q', 'user.jpg', '1-482-398-1512', '(972) 634-2299 x413', null, null, null, null, null, null, null, null, null);
INSERT INTO `delivery_man` VALUES ('9', 'Derick Schaefer', 'Ward', 'unde', 'roderick60@lind.com', '$2y$10$XNkJQmVDoyKxDRQ2mQ2ZoujOP/eZKRH61UksH8goffxo2a0NAjH9u', 'user.jpg', '(876) 702-5412 x69768', '+1-935-390-7022', null, null, null, null, null, null, null, null, null);
INSERT INTO `delivery_man` VALUES ('10', 'Ms. Stephanie Walker MD', 'Hilpert', 'totam', 'elaina91@treutel.biz', '$2y$10$vtfbAuX06gqt2XUjfbm7deQuEs7mdhyAwb/9s68K8Dd0AsYA57b8C', 'user.jpg', '1-629-660-0333', '(816) 790-6752 x6520', null, null, null, null, null, null, null, null, null);

-- ----------------------------
-- Table structure for migrations
-- ----------------------------
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of migrations
-- ----------------------------
INSERT INTO `migrations` VALUES ('23', '2010_02_15_173332_roles_permissions', '1');
INSERT INTO `migrations` VALUES ('24', '2010_03_15_173530_roles_users', '1');
INSERT INTO `migrations` VALUES ('25', '2010_12_14_152344_states', '1');
INSERT INTO `migrations` VALUES ('26', '2010_12_14_152345_municipios', '1');
INSERT INTO `migrations` VALUES ('27', '2010_12_14_152346_address', '1');
INSERT INTO `migrations` VALUES ('28', '2010_12_14_153708_admins', '1');
INSERT INTO `migrations` VALUES ('29', '2010_12_15_155728_categories', '1');
INSERT INTO `migrations` VALUES ('30', '2010_12_15_160800_currencies', '1');
INSERT INTO `migrations` VALUES ('31', '2013_02_14_152612_partners', '1');
INSERT INTO `migrations` VALUES ('32', '2013_02_14_152637_delivery_man', '1');
INSERT INTO `migrations` VALUES ('33', '2014_10_12_000000_create_clients_table', '1');
INSERT INTO `migrations` VALUES ('34', '2014_10_12_000000_create_users_table', '1');
INSERT INTO `migrations` VALUES ('35', '2014_10_12_100000_create_password_resets_table', '1');
INSERT INTO `migrations` VALUES ('36', '2015_01_14_152445_clients_address', '1');
INSERT INTO `migrations` VALUES ('37', '2020_02_14_152501_products', '1');
INSERT INTO `migrations` VALUES ('38', '2020_02_14_152652_prod_extras', '1');
INSERT INTO `migrations` VALUES ('39', '2020_02_14_152653_rates', '1');
INSERT INTO `migrations` VALUES ('40', '2020_02_14_152654_payments', '1');
INSERT INTO `migrations` VALUES ('41', '2020_02_14_152716_orders', '1');
INSERT INTO `migrations` VALUES ('42', '2020_02_14_152804_rate_list', '1');
INSERT INTO `migrations` VALUES ('43', '2020_03_09_141029_transaction_history', '1');
INSERT INTO `migrations` VALUES ('44', '2020_03_10_200438_products_tags', '1');

-- ----------------------------
-- Table structure for municipios
-- ----------------------------
DROP TABLE IF EXISTS `municipios`;
CREATE TABLE `municipios` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `states_id` bigint(20) unsigned NOT NULL,
  `mun_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `municipios_states_id_foreign` (`states_id`),
  CONSTRAINT `municipios_states_id_foreign` FOREIGN KEY (`states_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=336 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of municipios
-- ----------------------------
INSERT INTO `municipios` VALUES ('1', '1', 'Alto Orinoco', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('2', '1', 'Atabapo', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('3', '1', 'Atures', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('4', '1', 'Autana', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('5', '1', 'Manapiare', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('6', '1', 'Maroa', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('7', '1', 'Río Negro', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('8', '2', 'Anaco', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('9', '2', 'Aragua', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('10', '2', 'Manuel Ezequiel Bruzual', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('11', '2', 'Diego Bautista Urbaneja', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('12', '2', 'Fernando Peñalver', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('13', '2', 'Francisco Del Carmen Carvajal', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('14', '2', 'General Sir Arthur McGregor', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('15', '2', 'Guanta', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('16', '2', 'Independencia', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('17', '2', 'José Gregorio Monagas', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('18', '2', 'Juan Antonio Sotillo', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('19', '2', 'Juan Manuel Cajigal', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('20', '2', 'Libertad', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('21', '2', 'Francisco de Miranda', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('22', '2', 'Pedro María Freites', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('23', '2', 'Píritu', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('24', '2', 'San José de Guanipa', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('25', '2', 'San Juan de Capistrano', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('26', '2', 'Santa Ana', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('27', '2', 'Simón Bolívar', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('28', '2', 'Simón Rodríguez', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('29', '3', 'Achaguas', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('30', '3', 'Biruaca', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('31', '3', 'Muñóz', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('32', '3', 'Páez', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('33', '3', 'Pedro Camejo', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('34', '3', 'Rómulo Gallegos', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('35', '3', 'San Fernando', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('36', '4', 'Atanasio Girardot', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('37', '4', 'Bolívar', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('38', '4', 'Camatagua', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('39', '4', 'Francisco Linares Alcántara', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('40', '4', 'José Ángel Lamas', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('41', '4', 'José Félix Ribas', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('42', '4', 'José Rafael Revenga', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('43', '4', 'Libertador', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('44', '4', 'Mario Briceño Iragorry', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('45', '4', 'Ocumare de la Costa de Oro', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('46', '4', 'San Casimiro', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('47', '4', 'San Sebastián', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('48', '4', 'Santiago Mariño', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('49', '4', 'Santos Michelena', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('50', '4', 'Sucre', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('51', '4', 'Tovar', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('52', '4', 'Urdaneta', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('53', '4', 'Zamora', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('54', '5', 'Alberto Arvelo Torrealba', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('55', '5', 'Andrés Eloy Blanco', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('56', '5', 'Antonio José de Sucre', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('57', '5', 'Arismendi', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('58', '5', 'Barinas', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('59', '5', 'Bolívar', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('60', '5', 'Cruz Paredes', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('61', '5', 'Ezequiel Zamora', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('62', '5', 'Obispos', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('63', '5', 'Pedraza', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('64', '5', 'Rojas', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('65', '5', 'Sosa', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('66', '6', 'Caroní', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('67', '6', 'Cedeño', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('68', '6', 'El Callao', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('69', '6', 'Gran Sabana', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('70', '6', 'Heres', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('71', '6', 'Piar', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('72', '6', 'Angostura (Raúl Leoni)', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('73', '6', 'Roscio', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('74', '6', 'Sifontes', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('75', '6', 'Sucre', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('76', '6', 'Padre Pedro Chien', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('77', '7', 'Bejuma', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('78', '7', 'Carlos Arvelo', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('79', '7', 'Diego Ibarra', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('80', '7', 'Guacara', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('81', '7', 'Juan José Mora', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('82', '7', 'Libertador', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('83', '7', 'Los Guayos', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('84', '7', 'Miranda', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('85', '7', 'Montalbán', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('86', '7', 'Naguanagua', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('87', '7', 'Puerto Cabello', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('88', '7', 'San Diego', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('89', '7', 'San Joaquín', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('90', '7', 'Valencia', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('91', '8', 'Anzoátegui', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('92', '8', 'Tinaquillo', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('93', '8', 'Girardot', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('94', '8', 'Lima Blanco', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('95', '8', 'Pao de San Juan Bautista', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('96', '8', 'Ricaurte', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('97', '8', 'Rómulo Gallegos', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('98', '8', 'San Carlos', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('99', '8', 'Tinaco', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('100', '9', 'Antonio Díaz', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('101', '9', 'Casacoima', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('102', '9', 'Pedernales', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('103', '9', 'Tucupita', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('104', '10', 'Acosta', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('105', '10', 'Bolívar', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('106', '10', 'Buchivacoa', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('107', '10', 'Cacique Manaure', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('108', '10', 'Carirubana', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('109', '10', 'Colina', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('110', '10', 'Dabajuro', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('111', '10', 'Democracia', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('112', '10', 'Falcón', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('113', '10', 'Federación', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('114', '10', 'Jacura', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('115', '10', 'José Laurencio Silva', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('116', '10', 'Los Taques', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('117', '10', 'Mauroa', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('118', '10', 'Miranda', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('119', '10', 'Monseñor Iturriza', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('120', '10', 'Palmasola', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('121', '10', 'Petit', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('122', '10', 'Píritu', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('123', '10', 'San Francisco', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('124', '10', 'Sucre', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('125', '10', 'Tocópero', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('126', '10', 'Unión', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('127', '10', 'Urumaco', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('128', '10', 'Zamora', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('129', '11', 'Camaguán', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('130', '11', 'Chaguaramas', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('131', '11', 'El Socorro', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('132', '11', 'José Félix Ribas', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('133', '11', 'José Tadeo Monagas', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('134', '11', 'Juan Germán Roscio', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('135', '11', 'Julián Mellado', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('136', '11', 'Las Mercedes', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('137', '11', 'Leonardo Infante', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('138', '11', 'Pedro Zaraza', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('139', '11', 'Ortíz', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('140', '11', 'San Gerónimo de Guayabal', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('141', '11', 'San José de Guaribe', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('142', '11', 'Santa María de Ipire', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('143', '11', 'Sebastián Francisco de Miranda', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('144', '12', 'Andrés Eloy Blanco', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('145', '12', 'Crespo', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('146', '12', 'Iribarren', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('147', '12', 'Jiménez', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('148', '12', 'Morán', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('149', '12', 'Palavecino', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('150', '12', 'Simón Planas', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('151', '12', 'Torres', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('152', '12', 'Urdaneta', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('153', '13', 'Alberto Adriani', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('154', '13', 'Andrés Bello', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('155', '13', 'Antonio Pinto Salinas', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('156', '13', 'Aricagua', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('157', '13', 'Arzobispo Chacón', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('158', '13', 'Campo Elías', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('159', '13', 'Caracciolo Parra Olmedo', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('160', '13', 'Cardenal Quintero', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('161', '13', 'Guaraque', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('162', '13', 'Julio César Salas', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('163', '13', 'Justo Briceño', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('164', '13', 'Libertador', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('165', '13', 'Miranda', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('166', '13', 'Obispo Ramos de Lora', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('167', '13', 'Padre Noguera', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('168', '13', 'Pueblo Llano', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('169', '13', 'Rangel', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('170', '13', 'Rivas Dávila', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('171', '13', 'Santos Marquina', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('172', '13', 'Sucre', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('173', '13', 'Tovar', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('174', '13', 'Tulio Febres Cordero', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('175', '13', 'Zea', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('176', '14', 'Acevedo', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('177', '14', 'Andrés Bello', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('178', '14', 'Baruta', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('179', '14', 'Brión', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('180', '14', 'Buroz', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('181', '14', 'Carrizal', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('182', '14', 'Chacao', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('183', '14', 'Cristóbal Rojas', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('184', '14', 'El Hatillo', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('185', '14', 'Guaicaipuro', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('186', '14', 'Independencia', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('187', '14', 'Lander', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('188', '14', 'Los Salias', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('189', '14', 'Páez', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('190', '14', 'Paz Castillo', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('191', '14', 'Pedro Gual', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('192', '14', 'Plaza', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('193', '14', 'Simón Bolívar', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('194', '14', 'Sucre', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('195', '14', 'Urdaneta', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('196', '14', 'Zamora', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('197', '15', 'Acosta', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('198', '15', 'Aguasay', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('199', '15', 'Bolívar', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('200', '15', 'Caripe', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('201', '15', 'Cedeño', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('202', '15', 'Ezequiel Zamora', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('203', '15', 'Libertador', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('204', '15', 'Maturín', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('205', '15', 'Piar', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('206', '15', 'Punceres', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('207', '15', 'Santa Bárbara', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('208', '15', 'Sotillo', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('209', '15', 'Uracoa', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('210', '16', 'Antolin del Campo', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('211', '16', 'Arismendi', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('212', '16', 'García', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('213', '16', 'Gómez', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('214', '16', 'Maneiro', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('215', '16', 'Marcano', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('216', '16', 'Mariño', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('217', '16', 'Península de Macanao', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('218', '16', 'Tubores', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('219', '16', 'Villalba', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('220', '16', 'Díaz', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('221', '17', 'Agua Blanca', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('222', '17', 'Araure', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('223', '17', 'Esteller', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('224', '17', 'Guanare', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('225', '17', 'Guanarito', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('226', '17', 'Monseñor José Vicente de Unda', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('227', '17', 'Ospino', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('228', '17', 'Páez', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('229', '17', 'Papelón', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('230', '17', 'San Genaro de Boconoíto', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('231', '17', 'San Rafael de Onoto', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('232', '17', 'Santa Rosalía', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('233', '17', 'Sucre', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('234', '17', 'Turén', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('235', '18', 'Andrés Eloy Blanco', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('236', '18', 'Andrés Mata', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('237', '18', 'Arismendi', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('238', '18', 'Benítez', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('239', '18', 'Bermúdez', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('240', '18', 'Bolívar', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('241', '18', 'Cajigal', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('242', '18', 'Cruz Salmerón Acosta', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('243', '18', 'Libertador', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('244', '18', 'Mariño', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('245', '18', 'Mejía', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('246', '18', 'Montes', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('247', '18', 'Ribero', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('248', '18', 'Sucre', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('249', '18', 'Valdéz', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('250', '19', 'Andrés Bello', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('251', '19', 'Antonio Rómulo Costa', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('252', '19', 'Ayacucho', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('253', '19', 'Bolívar', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('254', '19', 'Cárdenas', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('255', '19', 'Córdoba', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('256', '19', 'Fernández Feo', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('257', '19', 'Francisco de Miranda', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('258', '19', 'García de Hevia', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('259', '19', 'Guásimos', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('260', '19', 'Independencia', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('261', '19', 'Jáuregui', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('262', '19', 'José María Vargas', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('263', '19', 'Junín', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('264', '19', 'Libertad', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('265', '19', 'Libertador', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('266', '19', 'Lobatera', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('267', '19', 'Michelena', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('268', '19', 'Panamericano', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('269', '19', 'Pedro María Ureña', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('270', '19', 'Rafael Urdaneta', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('271', '19', 'Samuel Darío Maldonado', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('272', '19', 'San Cristóbal', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('273', '19', 'Seboruco', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('274', '19', 'Simón Rodríguez', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('275', '19', 'Sucre', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('276', '19', 'Torbes', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('277', '19', 'Uribante', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('278', '19', 'San Judas Tadeo', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('279', '20', 'Andrés Bello', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('280', '20', 'Boconó', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('281', '20', 'Bolívar', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('282', '20', 'Candelaria', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('283', '20', 'Carache', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('284', '20', 'Escuque', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('285', '20', 'José Felipe Márquez Cañizalez', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('286', '20', 'Juan Vicente Campos Elías', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('287', '20', 'La Ceiba', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('288', '20', 'Miranda', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('289', '20', 'Monte Carmelo', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('290', '20', 'Motatán', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('291', '20', 'Pampán', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('292', '20', 'Pampanito', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('293', '20', 'Rafael Rangel', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('294', '20', 'San Rafael de Carvajal', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('295', '20', 'Sucre', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('296', '20', 'Trujillo', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('297', '20', 'Urdaneta', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('298', '20', 'Valera', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('299', '21', 'Vargas', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('300', '22', 'Arístides Bastidas', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('301', '22', 'Bolívar', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('302', '22', 'Bruzual', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('303', '22', 'Cocorote', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('304', '22', 'Independencia', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('305', '22', 'José Antonio Páez', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('306', '22', 'La Trinidad', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('307', '22', 'Manuel Monge', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('308', '22', 'Nirgua', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('309', '22', 'Peña', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('310', '22', 'San Felipe', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('311', '22', 'Sucre', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('312', '22', 'Urachiche', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('313', '22', 'José Joaquín Veroes', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('314', '23', 'Almirante Padilla', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('315', '23', 'Baralt', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('316', '23', 'Cabimas', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('317', '23', 'Catatumbo', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('318', '23', 'Colón', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('319', '23', 'Francisco Javier Pulgar', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('320', '23', 'Páez', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('321', '23', 'Jesús Enrique Losada', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('322', '23', 'Jesús María Semprún', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('323', '23', 'La Cañada de Urdaneta', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('324', '23', 'Lagunillas', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('325', '23', 'Machiques de Perijá', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('326', '23', 'Mara', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('327', '23', 'Maracaibo', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('328', '23', 'Miranda', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('329', '23', 'Rosario de Perijá', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('330', '23', 'San Francisco', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('331', '23', 'Santa Rita', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('332', '23', 'Simón Bolívar', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('333', '23', 'Sucre', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('334', '23', 'Valmore Rodríguez', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `municipios` VALUES ('335', '24', 'Libertador', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ord_prod_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_prod_id` bigint(20) unsigned DEFAULT NULL,
  `ord_address` bigint(20) unsigned DEFAULT NULL,
  `ord_price_bs` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_price_usd` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_extras` bigint(20) unsigned DEFAULT NULL,
  `ord_rate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ord_dm_id` bigint(20) unsigned DEFAULT NULL,
  `ord_dm_rate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ord_payment_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_ord_prod_id_foreign` (`ord_prod_id`),
  KEY `orders_ord_address_foreign` (`ord_address`),
  KEY `orders_ord_extras_foreign` (`ord_extras`),
  KEY `orders_ord_dm_id_foreign` (`ord_dm_id`),
  KEY `orders_ord_payment_id_foreign` (`ord_payment_id`),
  CONSTRAINT `orders_ord_address_foreign` FOREIGN KEY (`ord_address`) REFERENCES `clients_address` (`id`),
  CONSTRAINT `orders_ord_dm_id_foreign` FOREIGN KEY (`ord_dm_id`) REFERENCES `delivery_man` (`id`),
  CONSTRAINT `orders_ord_extras_foreign` FOREIGN KEY (`ord_extras`) REFERENCES `prod_extras` (`id`),
  CONSTRAINT `orders_ord_payment_id_foreign` FOREIGN KEY (`ord_payment_id`) REFERENCES `payments` (`id`),
  CONSTRAINT `orders_ord_prod_id_foreign` FOREIGN KEY (`ord_prod_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES ('1', 'asdad', '1', '1', '52', '56', 'asdasd', 'op', null, null, null, null, '1', '2020-03-13 10:35:21', null, null);
INSERT INTO `orders` VALUES ('2', 'adasd', '2', null, '20', '26', '', 'as', '1', null, null, null, '1', '2020-03-13 10:35:25', null, null);
INSERT INTO `orders` VALUES ('3', 'zszdd', '3', '1', '51', '20', 'asdasd', 're', '1', null, null, null, '1', '2020-03-13 10:35:27', null, null);

-- ----------------------------
-- Table structure for partners
-- ----------------------------
DROP TABLE IF EXISTS `partners`;
CREATE TABLE `partners` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `p_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_user` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_phone_1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_phone_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_rif` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_rs_id` bigint(20) unsigned DEFAULT NULL,
  `p_mun_id` bigint(20) unsigned DEFAULT NULL,
  `p_adrress` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_cat_id` bigint(20) unsigned DEFAULT NULL,
  `p_intents` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_blocked` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_pass_exp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_open_time` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_close_time` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_rate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_shipping` bigint(20) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `partners_p_user_unique` (`p_user`),
  UNIQUE KEY `partners_p_email_unique` (`p_email`),
  KEY `partners_p_rs_id_foreign` (`p_rs_id`),
  KEY `partners_p_mun_id_foreign` (`p_mun_id`),
  KEY `partners_p_cat_id_foreign` (`p_cat_id`),
  CONSTRAINT `partners_p_cat_id_foreign` FOREIGN KEY (`p_cat_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `partners_p_mun_id_foreign` FOREIGN KEY (`p_mun_id`) REFERENCES `municipios` (`id`),
  CONSTRAINT `partners_p_rs_id_foreign` FOREIGN KEY (`p_rs_id`) REFERENCES `roles_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of partners
-- ----------------------------
INSERT INTO `partners` VALUES ('1', 'Darrell Blick', 'Doyle', 'corrupti', 'margret.mccullough@roberts.com', '1-594-417-5606', '248.773.6312 x4634', '$2y$10$/tHu2YTLO35AsGvUJdZthuurkCDYa9vfuwgMuCUjMVgR8hUsuyFty', '3', null, '2', '487 Koelpin Islands Apt. 274\nSouth Camilleberg, AL 14684', '1', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('2', 'Mr. Colton Deckow V', 'Oberbrunner', 'quaerat', 'murray19@yahoo.com', '1-270-217-1677', '+1 (732) 916-6715', '$2y$10$M6U6TCRYXu8i3SUSvp.zTuoIM6CjUFDKVEEdKTfIxiak5mMKX3BmK', '5', null, '2', '6717 Sporer Branch Apt. 454\nLake Anderson, OH 73208-9301', '3', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('3', 'Jaydon Oberbrunner', 'Purdy', 'quod', 'lucinda.balistreri@borer.net', '313-368-8018', '1-718-421-1153 x45000', '$2y$10$NZaBNmSda9TGc.1nGm4UbeZGR3n433W9MgP7R7m8GqcjhhYROj5Lq', '9', null, '1', '49996 Cristobal Isle\nLake Angelina, IN 74228-2415', '2', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('4', 'Albin Blanda V', 'Marks', 'quisquam', 'hans.sauer@kuphal.biz', '1-934-969-5327', '853.346.9328', '$2y$10$HJaW3NfHKw4Q5bwqZWLpgui9eiuSs1UN04RpLeOe5cx.32E2y9uTK', '1', null, '1', '2008 Edyth Villages\nLake Anniestad, NJ 42647', '3', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('5', 'Abdiel Johnston Sr.', 'Purdy', 'impedit', 'torrey90@hotmail.com', '440-473-4877 x7154', '1-370-335-8743 x71913', '$2y$10$0nyTM0ZZ0wxVLQS.GjtOa.ZCVjVRAK.Dmg3Yzcgaxa4G7pbYwlm3O', '1', null, '1', '150 Kay Park Apt. 675\nJettiemouth, OH 61509-2914', '1', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('6', 'Isaac Witting', 'Schaefer', 'qui', 'marguerite.goldner@gmail.com', '(215) 293-5691', '+1 (694) 755-3019', '$2y$10$H0MK8X4SEhOOQ5LNrv6bWuYCtTYZAYqrnjRobUZO79VztSu6aXvF2', '5', null, '2', '833 Jacobi Shores\nNorth Itzelview, VT 41052', '3', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('7', 'Dr. Alene Dicki MD', 'Howe', 'voluptas', 'frankie.lueilwitz@gmail.com', '498-333-7886 x500', '365.621.2711 x4354', '$2y$10$n2ndUb3KDxY5/I4xfXtp5OOtyLhFs0ZtEzevsDKoPR07oc08w/.zG', '6', null, '1', '936 Blanche Plain Apt. 012\nGerhardtown, ME 63096', '3', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('8', 'Prof. Santa Hand', 'Schmeler', 'illum', 'fbrekke@gmail.com', '446.922.8745', '+1-648-691-5564', '$2y$10$qLCkByrjZcFJqu4g/RtR3.qJuWWHaUUfv3S6UrTLyX5I0dRC7OYpu', '5', null, '1', '555 Schmidt Fork\nSouth Kathrynfort, OH 63630-4169', '3', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('9', 'Ahmad Blick', 'Hauck', 'est', 'alfredo16@yahoo.com', '1-601-222-6036 x967', '+1.940.265.7989', '$2y$10$vT/A6/AgWEIRhnEM3qKrpumuLbjKZOBN2n3FvF3pgOU3AqGp6Z.ry', '2', null, '1', '719 Ledner Harbor\nFelipaview, AL 52222-5971', '1', null, null, null, null, null, null, null, null, null, null, null, null);
INSERT INTO `partners` VALUES ('10', 'Kari Friesen', 'Murray', 'quis', 'olson.trystan@von.info', '1-365-797-8451', '(325) 606-0217 x5386', '$2y$10$cwdpsSnGVQEwSmYPmmjpMuM9an7kmXgLAl98o9ubEy8in2ZEnJuM.', '4', null, '1', '724 Ayana Union Suite 218\nHueltown, DE 62980-6106', '1', null, null, null, null, null, null, null, null, null, null, null, null);

-- ----------------------------
-- Table structure for password_resets
-- ----------------------------
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of password_resets
-- ----------------------------

-- ----------------------------
-- Table structure for payments
-- ----------------------------
DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pay_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pay_ref` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pay_type` bigint(20) NOT NULL,
  `pay_amount` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of payments
-- ----------------------------
INSERT INTO `payments` VALUES ('1', 'orden ral', '5452664', '1', '45', null, null, null);

-- ----------------------------
-- Table structure for products
-- ----------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `prod_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prod_partner_id` bigint(20) unsigned DEFAULT NULL,
  `prod_price_bs` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prod_price_usd` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prod_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `products_prod_partner_id_foreign` (`prod_partner_id`),
  CONSTRAINT `products_prod_partner_id_foreign` FOREIGN KEY (`prod_partner_id`) REFERENCES `partners` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of products
-- ----------------------------
INSERT INTO `products` VALUES ('1', 'Jessie Gleason', '8', '9029', '9269', 'aut', null, null, null);
INSERT INTO `products` VALUES ('2', 'Mr. Unique Blanda', '3', '6614', '1685', 'iusto', null, null, null);
INSERT INTO `products` VALUES ('3', 'Prof. Elian Braun', '2', '2515', '8535', 'impedit', null, null, null);
INSERT INTO `products` VALUES ('4', 'Nella Schulist', '8', '6972', '1747', 'dolorum', null, null, null);
INSERT INTO `products` VALUES ('5', 'Eryn Keebler IV', '3', '8997', '3987', 'occaecati', null, null, null);
INSERT INTO `products` VALUES ('6', 'Magdalen Bode', '2', '8064', '7980', 'odio', null, null, null);
INSERT INTO `products` VALUES ('7', 'Kayla Bergstrom', '6', '7952', '4617', 'ea', null, null, null);
INSERT INTO `products` VALUES ('8', 'Isadore Powlowski', '2', '485', '1631', 'dolores', null, null, null);
INSERT INTO `products` VALUES ('9', 'Ms. Virginia Graham', '4', '4045', '4826', 'libero', null, null, null);
INSERT INTO `products` VALUES ('10', 'Enrique Watsica', '9', '731', '2312', 'tenetur', null, null, null);

-- ----------------------------
-- Table structure for product_tags
-- ----------------------------
DROP TABLE IF EXISTS `product_tags`;
CREATE TABLE `product_tags` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of product_tags
-- ----------------------------

-- ----------------------------
-- Table structure for prod_extras
-- ----------------------------
DROP TABLE IF EXISTS `prod_extras`;
CREATE TABLE `prod_extras` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pe_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pe_price_bs` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pe_price_usd` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pe_partner_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prod_extras_pe_partner_id_foreign` (`pe_partner_id`),
  CONSTRAINT `prod_extras_pe_partner_id_foreign` FOREIGN KEY (`pe_partner_id`) REFERENCES `partners` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of prod_extras
-- ----------------------------
INSERT INTO `prod_extras` VALUES ('1', 'quesp', '50', '50', '1', null, null, null);

-- ----------------------------
-- Table structure for rates
-- ----------------------------
DROP TABLE IF EXISTS `rates`;
CREATE TABLE `rates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rt_value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of rates
-- ----------------------------

-- ----------------------------
-- Table structure for rate_list
-- ----------------------------
DROP TABLE IF EXISTS `rate_list`;
CREATE TABLE `rate_list` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rate_order_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rate_list_rate_order_id_foreign` (`rate_order_id`),
  CONSTRAINT `rate_list_rate_order_id_foreign` FOREIGN KEY (`rate_order_id`) REFERENCES `orders` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of rate_list
-- ----------------------------

-- ----------------------------
-- Table structure for roles_permissions
-- ----------------------------
DROP TABLE IF EXISTS `roles_permissions`;
CREATE TABLE `roles_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of roles_permissions
-- ----------------------------

-- ----------------------------
-- Table structure for roles_users
-- ----------------------------
DROP TABLE IF EXISTS `roles_users`;
CREATE TABLE `roles_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rs_perms_id` bigint(20) unsigned NOT NULL,
  `rs_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `roles_users_rs_perms_id_foreign` (`rs_perms_id`),
  CONSTRAINT `roles_users_rs_perms_id_foreign` FOREIGN KEY (`rs_perms_id`) REFERENCES `roles_permissions` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of roles_users
-- ----------------------------

-- ----------------------------
-- Table structure for states
-- ----------------------------
DROP TABLE IF EXISTS `states`;
CREATE TABLE `states` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `st_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `st_iso` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of states
-- ----------------------------
INSERT INTO `states` VALUES ('1', 'Amazonas', 'VE-X', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('2', 'Anzoátegui', 'VE-B', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('3', 'Apure', 'VE-C', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('4', 'Aragua', 'VE-D', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('5', 'Barinas', 'VE-E', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('6', 'Bolívar', 'VE-F', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('7', 'Carabobo', 'VE-G', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('8', 'Cojedes', 'VE-H', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('9', 'Delta Amacuro', 'VE-Y', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('10', 'Falcón', 'VE-I', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('11', 'Guárico', 'VE-J', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('12', 'Lara', 'VE-K', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('13', 'Mérida', 'VE-L', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('14', 'Miranda', 'VE-M', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('15', 'Monagas', 'VE-N', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('16', 'Nueva Esparta', 'VE-O', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('17', 'Portuguesa', 'VE-P', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('18', 'Sucre', 'VE-R', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('19', 'Táchira', 'VE-S', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('20', 'Trujillo', 'VE-T', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('21', 'Vargas', 'VE-W', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('22', 'Yaracuy', 'VE-U', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('23', 'Zulia', 'VE-V', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('24', 'Distrito Capital', 'VE-A', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);
INSERT INTO `states` VALUES ('25', 'Dependencias Federales', 'VE-Z', '2020-03-13 03:40:18', '2020-03-13 03:40:18', null);

-- ----------------------------
-- Table structure for transactions_history
-- ----------------------------
DROP TABLE IF EXISTS `transactions_history`;
CREATE TABLE `transactions_history` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of transactions_history
-- ----------------------------

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('1', 'gioanfranco', 'gioan2908@gmail.com', null, '$2y$10$lw7KXG/P0lbNFmcpN6wIJuC1QmqFvlUkL.O3CvtCaXzU2XQugRnEC', null, null, null, null);

/*
Navicat MySQL Data Transfer

Source Server         : local
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : itsonthe_way_test

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2020-06-25 00:20:02
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for order_items_order_items_extra
-- ----------------------------
DROP TABLE IF EXISTS `order_items_order_items_extra`;
CREATE TABLE `order_items_order_items_extra` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `order_items_id` bigint(20) DEFAULT NULL,
  `order_items_extra_id` bigint(20) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

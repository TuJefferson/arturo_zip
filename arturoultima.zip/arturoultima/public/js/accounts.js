

var AcountBankArray = [];

var AcountBankMsjErrorES = {
	  MSJ_1 : "Por favor Agregue un nombre de banco",
    MSJ_2 : "Por favor Agregue el tipo de cuenta",
    MSJ_3 : "Por favor incluya el CI o RIF de la cuenta",
    MSJ_4 : "Por favor incluya el número de cuenta",
};

var AcountBank = {

	name : null,
    account_type :  null,
    document_account :  null,
    bank_account : null,
    msj_error_name : null,
    msj_error_account_type :  null,
    msj_error_document_account :  null,
    msj_error_bank_account : null,
    
    addAcount : function(){
			
        if(AcountBank.validateForm()){
            AcountBankArray.push({
                name : AcountBank.name.value,
                account_type : AcountBank.account_type.value,
                document_account : AcountBank.document_account.value,
                bank_account : AcountBank.bank_account.value
            });
        }

    },
    /*
    metodo: validateForm
    descripcion: Metodo Utilizado para validar los inputs de costa rica
    */      
    validateForm : function(){
    
        let errorCount = 0;
   
        if(AcountBank.name.value == ''){ 
            AcountBank.msj_error_name.innerHTML = AcountBankMsjErrorES.MSJ_1;
            errorCount = errorCount + 1;    
        }else{
            AcountBank.msj_error_name.innerHTML = "";
        }
        
        if(AcountBank.account_type.value == ''){    
            AcountBank.msj_error_account_type.innerHTML = AcountBankMsjErrorES.MSJ_2;
            errorCount = errorCount + 1;
        }else{
            AcountBank.msj_error_account_type.innerHTML = "";
        }
        
        if(AcountBank.document_account.value == ''){ 
            AcountBank.msj_error_document_account.innerHTML = AcountBankMsjErrorES.MSJ_3;
            errorCount = errorCount + 1;
        }else{
            AcountBank.msj_error_document_account.innerHTML =  ""; 
        }
        
        if(AcountBank.bank_account.value == ''){ 
            AcountBank.msj_error_bank_account.innerHTML = AcountBankMsjErrorES.MSJ_4;
            errorCount = errorCount + 1;
        }else{
            AcountBank.msj_error_bank_account.innerHTML = "";
        }
        
        return	(errorCount == 0)?true:false;
      
    },
    /*
    metodo: updateHiddenInput
    descripcion: Metodo Utilizado para cargar los valores del array en un inputHidden
    */      
    updateHiddenInput : function (){
     
        let obj = JSON.stringify({ value : AcountBankArray });
        console.log(obj);
        document.getElementById("bankAcountJSON").value = obj;
        
    },
    /*
    metodo: showAcountList
    descripcion: Metodo Utilizado para mostrar los valores del array en la vista
    */    
	showAcountList(){

        let listaCuenta = "";
        let tmpId = "";

        AcountBankArray.forEach( (obj, index) => {

            tmpId = 'ID_'+obj.bank_account +'_'+index;
            let tmp =  "'"+obj.bank_account+"'";

            listaCuenta += 
            '<li class="list-group-item" data-toggle="collapse" href="#'+ tmpId +'" '+
            ' role="button" aria-expanded="false" aria-controls="'+ tmpId +'"> '+(index+1)+' ) - <a href="#"> Nro Cta: '+obj.bank_account+'</a> '+
            '<div class="collapse" id="'+ tmpId +'">'+
            '<ul class="list-group  mt-4 ml-3 mr-3">'+
            ' <li class="list-group-item">Nombre del Banco: '+obj.name+'</li>'+
            ' <li class="list-group-item">Tipo de Cta: '+obj.account_type+'</li>'+
            ' <li class="list-group-item">Cédula O Rif de la Cta: '+obj.document_account+'</li>'+
            ' <li class="list-group-item">Nro de Cta: '+obj.bank_account+'</li>'+
            '</ul>'+
            '<div class="text-center mt-4">'+
            '<button type="button" class="danger btn-danger" onclick="deleteAcount('+tmp+')">Eliminar Cuenta</button>'+
            '</div>'+
            '</div>'+
            '</li>';
       
        });

        document.getElementById("ListAcountCollapse").innerHTML = listaCuenta;
    }      
}
/*
  metodo: addAcount
  descripcion: Metodo Utilizado para almacenar los valores del formulario 
*/
function addAcount(){

    AcountBank.name = document.getElementById("bank_name");
    AcountBank.account_type = document.getElementById("account_type");
    AcountBank.document_account = document.getElementById("document_account");
    AcountBank.bank_account = document.getElementById("bank_account");
    
    AcountBank.msj_error_name = document.getElementById("msj_name");
    AcountBank.msj_error_account_type = document.getElementById("msj_account_type");
    AcountBank.msj_error_document_account = document.getElementById("msj_document_account");
    AcountBank.msj_error_bank_account = document.getElementById("msj_bank_account");
              
    AcountBank.addAcount();
    AcountBank.updateHiddenInput();
    AcountBank.showAcountList();
    
    console.log(AcountBankArray);
 
}
/*
  metodo: deleteAcount
  descripcion: Metodo Utilizado para eliminar los valores del array 
*/
function deleteAcount(value){
    
    const resultado = AcountBankArray.find( obj => obj.bank_account === value );
    var i = AcountBankArray.indexOf( resultado );

    AcountBankArray.splice( i, 1 );
    AcountBank.showAcountList();
    console.log(AcountBankArray);

}

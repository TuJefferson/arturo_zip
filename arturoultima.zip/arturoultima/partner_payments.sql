/*
Navicat MySQL Data Transfer

Source Server         : local_host
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : its_on_the_way

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2020-04-07 08:44:44
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for partner_payments
-- ----------------------------
DROP TABLE IF EXISTS `partner_payments`;
CREATE TABLE `partner_payments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `partner_id` bigint(20) unsigned DEFAULT NULL,
  `payment_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `partner_payments_partner_id_foreign` (`partner_id`),
  KEY `partner_payments_payment_id_foreign` (`payment_id`),
  CONSTRAINT `partner_payments_partner_id_foreign` FOREIGN KEY (`partner_id`) REFERENCES `partners` (`id`),
  CONSTRAINT `partner_payments_payment_id_foreign` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of partner_payments
-- ----------------------------
INSERT INTO `partner_payments` VALUES ('1', '1', '1', null, null, null);

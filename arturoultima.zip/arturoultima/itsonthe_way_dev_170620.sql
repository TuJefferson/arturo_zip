-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3306
-- Tiempo de generación: 17-06-2020 a las 23:01:48
-- Versión del servidor: 10.3.22-MariaDB-cll-lve
-- Versión de PHP: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `itsonthe_way_dev`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `address`
--

CREATE TABLE `address` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `st_id` bigint(20) UNSIGNED DEFAULT NULL,
  `mun_id` bigint(20) UNSIGNED DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `address`
--

INSERT INTO `address` (`id`, `st_id`, `mun_id`, `description`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 2, 1, 'tenetur', NULL, NULL, NULL),
(2, 3, 2, 'ab', NULL, NULL, NULL),
(3, 14, 1, 'harum', NULL, NULL, NULL),
(4, 19, 2, 'tempora', NULL, NULL, NULL),
(5, 17, 1, 'modi', NULL, NULL, NULL),
(6, 12, 1, 'illo', NULL, NULL, NULL),
(7, 12, 1, 'odit', NULL, NULL, NULL),
(8, 19, 2, 'necessitatibus', NULL, NULL, NULL),
(9, 4, 1, 'exercitationem', NULL, NULL, NULL),
(10, 5, 1, 'placeat', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ad_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ad_last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ad_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ad_user_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ad_rs_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ad_intents` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ad_blocked` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ad_pass_exp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cat_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `categories`
--

INSERT INTO `categories` (`id`, `cat_name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Restaurant', NULL, NULL, NULL),
(2, 'Farmacia', NULL, NULL, NULL),
(3, 'Tienda', NULL, NULL, NULL),
(4, 'Mercado', NULL, NULL, NULL),
(5, 'Mercado 2', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clients`
--

CREATE TABLE `clients` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cl_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_user` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_dni` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cl_phone_1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_phone_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cl_rs_id` bigint(20) UNSIGNED DEFAULT NULL,
  `cl_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_verified` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_intents` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cl_blocked` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cl_pass_exp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `confirmation_code` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `clients`
--

INSERT INTO `clients` (`id`, `cl_name`, `cl_last_name`, `cl_user`, `cl_dni`, `cl_phone_1`, `cl_phone_2`, `cl_rs_id`, `cl_email`, `cl_verified`, `password`, `cl_intents`, `cl_blocked`, `cl_pass_exp`, `confirmation_code`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Margaret Weber', 'Hackett', 'quis', '6', '(585) 634-9588', '(564) 653-4598 x444', NULL, 'alvina@yahoo.com', NULL, '$2y$10$zsmvSSKlvKCIXPt8jAvgc.9aqzzvr8fLFdQPQfOacIUWn8H2dl572', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'Skyla Anderson', 'Huels', 'eius', '7', '448.551.9863', '1-593-208-8989 x84829', NULL, 'hugh20@gmail.com', NULL, '$2y$10$iWJHuYZYQrrOe3d72mfn2OKlNHArekIwg8gIIKH2pQKpz9iqQKkOy', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'Yadira Dicki', 'Collins', 'illum', '1', '1-247-838-9043', '608.495.3273', NULL, 'yherman@yahoo.com', NULL, '$2y$10$xZtC.mAzMU6zcKS99FJ/6eonfrJrkjFPO14wIKVooCo0p0NL.vTym', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'Viva Windler DDS', 'Hintz', 'inventore', '4', '402.836.1609', '368-327-3639', NULL, 'ernestina.christiansen@gmail.com', NULL, '$2y$10$pH3NF8xCfwm6zCKyqWcvZ.M7hO1iJHTC2P5O9aHq/yhzJ3p2QUBMG', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 'Jeramie Kassulke', 'Beahan', 'tempore', '9', '+1.678.969.0706', '619.490.0240 x80000', NULL, 'fleuschke@hotmail.com', NULL, '$2y$10$aSKkIuyXX385/QRJoKd6FueVYu9jVp7hShzYOyFy5bJVCmNIHP3WS', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 'Jarvis Rowe', 'Altenwerth', 'facilis', '1', '1-437-856-9571 x3886', '926-572-5218 x4436', NULL, 'godfrey22@yahoo.com', NULL, '$2y$10$hHSyqkix99NcdRxf392os.zv1DYrYz7e8aVEaEPJMNBGlllwINw32', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 'Rosalind Steuber', 'Wuckert', 'sit', '6', '+1.789.818.6021', '1-652-351-7639 x29776', NULL, 'tyreek71@pagac.info', NULL, '$2y$10$XvLh6p/lw1igLEg8VPZGaOOJbL8AwEAVPNYnepXcH.aCbjUTLOCOq', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(101, 'Luis Emilio', 'Hernandez', 'user_default', NULL, '04144537395', NULL, NULL, 'Kin_79@hotmail.com', '1', '$2y$10$8RRvQE/FPzj0ze1t48XKSesCMP7s7a97hcDPKS1V0ys4oNJ6EGG9K', NULL, NULL, NULL, NULL, '2020-06-03 08:58:21', '2020-06-03 09:00:16', NULL),
(106, 'gioan', 'bnmbnmnxcvfghhj', 'AAAAASD', '2125412', '04511245', '211244521', NULL, 'grobles@teravisiontech.com', NULL, 'eyJpdiI6Im9lUXEwQ0J4dTJMNExlMEVUYmxaTmc9PSIsInZhbHVlIjoiSUkzbmlkVTBNOW9IMjZ3d2dJZHgwUT09IiwibWFjIjoiNjM1MzRkNzVmYmZjMzFlNWM1ZTQ2ZTlkMWE0MDBkMGNkMmMyZmU1OWYwNDYwYWNiYmVjNDAzZjRhYmYzNTYyNCJ9', NULL, NULL, NULL, 'sn8sHnDc', '2020-06-08 22:51:52', '2020-06-08 22:51:52', NULL),
(117, 'gioan', 'bnmbnmnxcvfghhj', 'asdasdfxvxcvcvbsddfgfghfgh', '2125412', '04511245', '211244521', NULL, 'sadfsfssdfsdfsfdf@gmail.com', NULL, 'eyJpdiI6IkpGc1hic2VMaXFWbmZ5dlBqR2lmZ3c9PSIsInZhbHVlIjoienY1RElDaGFkRTlrdUU0eGl4SkRcLzRmVm4rdWJqVWwzRmFXbXNRdmZoTlk9IiwibWFjIjoiOTkwYmIxODZjYmRlNmQzMTcxN2RlZTdhNTc3ODhjMmY5YmI3Yjk1OGZlYmMxMmIyMjdmODk1MGZhZjllYTZhZSJ9', NULL, NULL, NULL, 'dNBm3neC', '2020-06-11 22:00:52', '2020-06-11 22:00:52', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clients_address`
--

CREATE TABLE `clients_address` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ca_cl_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ca_address_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `clients_address`
--

INSERT INTO `clients_address` (`id`, `ca_cl_id`, `ca_address_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 1, '2020-03-13 03:52:32', NULL, NULL),
(2, 2, 2, '2020-04-29 17:44:20', NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `curriencies`
--

CREATE TABLE `curriencies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `cur_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cur_value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `curriencies`
--

INSERT INTO `curriencies` (`id`, `cur_name`, `cur_value`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Dólar', '194000', NULL, '2020-05-30 11:21:48', NULL),
(2, 'Bolivar', '', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `delivery_man`
--

CREATE TABLE `delivery_man` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `dm_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_user` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user.jpg',
  `dm_phone_1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_phone_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dm_rs_id` bigint(20) UNSIGNED DEFAULT NULL,
  `dm_rate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dm_intents` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dm_blocked` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dm_pass_exp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `mime` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `original_filename` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `delivery_man`
--

INSERT INTO `delivery_man` (`id`, `dm_name`, `dm_last_name`, `dm_user`, `dm_email`, `password`, `avatar`, `dm_phone_1`, `dm_phone_2`, `dm_rs_id`, `dm_rate`, `dm_intents`, `dm_blocked`, `dm_pass_exp`, `remember_token`, `created_at`, `updated_at`, `deleted_at`, `mime`, `original_filename`) VALUES
(1, 'Dr. Jayden McDermott', 'Yost', 'adipisci', 'legros.lafayette@hotmail.com', '$2y$10$3RD5YPzZFKYtCUHUhCEw.eypUGOdNI/9OgRKHnRbpLCKjVC89Lnke', 'user.jpg', '1-642-717-2788', '(405) 244-9433', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'Karianne Ziemann', 'Kessler', 'dolore', 'tyshawn39@haley.org', '$2y$10$K0K6qx02kTvZ2EOIJHlWCe9uFfiOyxzgztIhKEDQvjX1imwWWMixW', 'user.jpg', '914-561-1040', '+1-718-433-5653', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'Dr. Michale Bruen', 'Altenwerth', 'provident', 'jesus.orn@hotmail.com', '$2y$10$pPXB0EEEWE67h/v67Nt3BuSB2S/s8O4o.ddspegjx7DO3g7Mn.tFy', 'user.jpg', '240.542.1368 x2782', '(390) 289-5442 x8452', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(4, 'Gonzalo Hamill', 'Gutmann', 'consequuntur', 'uriah.dibbert@yahoo.com', '$2y$10$1cV8QPvpk5YLglLXh9lrEOw239rVyMgwMj8/PtOz2sbhEwrgL3NZO', 'user.jpg', '1-741-204-5184 x110', '+1-237-335-9316', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(5, 'Prof. Chloe McGlynn Jr.', 'Crooks', 'maxime', 'kobe.bayer@hotmail.com', '$2y$10$h.jwMDqJMODtZ/kr7LN2DOsIUv26n80ifSTn8xl/0JjvyxWnhcYSa', 'user.jpg', '(517) 216-3592 x5324', '463.839.0368', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(6, 'Dennis Rowe', 'Pfannerstill', 'et', 'sporer.lysanne@gmail.com', '$2y$10$5LBwKCsJFVutGkYUMriXQeCeMqSMhxUT7KV5/zU/A/LEnqxT79myS', 'user.jpg', '552.859.1576', '1-915-873-8085', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(7, 'Lyla Green', 'Collins', 'voluptatibus', 'botsford.katrina@welch.com', '$2y$10$PBZ2rR1WT4qx35qf7.xSGOWqtehaKqZZQXpAts5MdPG1AEjCoOMS.', 'user.jpg', '1-893-417-2197', '469.889.0914', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(8, 'Miss Dixie Schultz', 'Baumbach', 'autem', 'emmerich.izabella@yahoo.com', '$2y$10$t4H7rPhoTCfsWYXL5s5Bdu28S0frU/BCFIcfQwIr2jTmyp9hxzP6q', 'user.jpg', '1-482-398-1512', '(972) 634-2299 x413', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(9, 'Derick Schaefer', 'Ward', 'unde', 'roderick60@lind.com', '$2y$10$XNkJQmVDoyKxDRQ2mQ2ZoujOP/eZKRH61UksH8goffxo2a0NAjH9u', 'user.jpg', '(876) 702-5412 x69768', '+1-935-390-7022', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(10, 'Ms. Stephanie Walker MD', 'Hilpert', 'totam', 'elaina91@treutel.biz', '$2y$10$vtfbAuX06gqt2XUjfbm7deQuEs7mdhyAwb/9s68K8Dd0AsYA57b8C', 'user.jpg', '1-629-660-0333', '(816) 790-6752 x6520', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(11, 'fsdfsf', 'sdfssdf', 'qweqwe', 'adssdfsfa@gmai.com', '$2y$10$UV.edG4zliFMI.8E5tk05uVfOkbtLXREl8DzyEymzBWfbGvrnH1m6', 'user.jpg', '+584166944549', '04143944752', NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-20 03:37:50', '2020-04-20 03:37:50', NULL, NULL, NULL),
(12, 'fsdfsf', 'sdfssdf', 'qweqwea', 'adsssdfsfa@gmai.com', '$2y$10$uiU4wRSlaTS8yRTg0LlC9eA2G0xDBD0ugTaIzcbjT2wCmAkdVT49y', 'user.jpg', '+584166944549', '04143944752', NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-20 03:38:16', '2020-04-20 03:38:16', NULL, NULL, NULL),
(13, 'asdasd', 'dfsdsfsdf', 'asdasdadas', 'asdsf@gmail.cok', '$2y$10$ZxmA4e7leeRZcn4Kk02q1usnr4C4wj6JnWelQk9f5/XVtUGLGW0qu', 'user.jpg', '04143944752', '04143944752', NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-20 03:41:22', '2020-04-20 03:41:22', NULL, NULL, NULL),
(14, 'sdfsdfsdf', 'fdsdffsdfsdfsdfsfs', 'asfsdfddssdf', 'asdas@gmail.com', '$2y$10$0Uag4jcZYOo8UFItox1G9O0HVuNVF.lHr4gteMPOOhbXCqJrflnY.', 'user.jpg', '04143944752', '04143944752', NULL, NULL, NULL, NULL, NULL, NULL, '2020-04-20 03:50:03', '2020-04-20 03:50:03', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(23, '2010_02_15_173332_roles_permissions', 1),
(24, '2010_03_15_173530_roles_users', 1),
(25, '2010_12_14_152344_states', 1),
(26, '2010_12_14_152345_municipios', 1),
(27, '2010_12_14_152346_address', 1),
(28, '2010_12_14_153708_admins', 1),
(29, '2010_12_15_155728_categories', 1),
(30, '2010_12_15_160800_currencies', 1),
(31, '2013_02_14_152612_partners', 1),
(32, '2013_02_14_152637_delivery_man', 1),
(33, '2014_10_12_000000_create_clients_table', 1),
(34, '2014_10_12_000000_create_users_table', 1),
(35, '2014_10_12_100000_create_password_resets_table', 1),
(36, '2015_01_14_152445_clients_address', 1),
(37, '2020_02_14_152501_products', 1),
(38, '2020_02_14_152652_prod_extras', 1),
(39, '2020_02_14_152653_rates', 1),
(40, '2020_02_14_152654_payments', 1),
(41, '2020_02_14_152716_orders', 1),
(42, '2020_02_14_152804_rate_list', 1),
(43, '2020_03_09_141029_transaction_history', 1),
(44, '2020_03_10_200438_products_tags', 1),
(45, '2020_02_14_152655_partner_payments', 2),
(46, '2020_03_17_051047_service_tickets', 2),
(47, '2020_03_17_051121_valor_delicery', 2),
(48, '2020_03_17_051132_valor_delivery', 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `municipios`
--

CREATE TABLE `municipios` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `states_id` bigint(20) UNSIGNED NOT NULL,
  `mun_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `municipios`
--

INSERT INTO `municipios` (`id`, `states_id`, `mun_name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 'Alto Orinoco', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(2, 1, 'Atabapo', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(3, 1, 'Atures', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(4, 1, 'Autana', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(5, 1, 'Manapiare', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(6, 1, 'Maroa', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(7, 1, 'Río Negro', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(8, 2, 'Anaco', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(9, 2, 'Aragua', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(10, 2, 'Manuel Ezequiel Bruzual', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(11, 2, 'Diego Bautista Urbaneja', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(12, 2, 'Fernando Peñalver', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(13, 2, 'Francisco Del Carmen Carvajal', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(14, 2, 'General Sir Arthur McGregor', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(15, 2, 'Guanta', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(16, 2, 'Independencia', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(17, 2, 'José Gregorio Monagas', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(18, 2, 'Juan Antonio Sotillo', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(19, 2, 'Juan Manuel Cajigal', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(20, 2, 'Libertad', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(21, 2, 'Francisco de Miranda', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(22, 2, 'Pedro María Freites', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(23, 2, 'Píritu', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(24, 2, 'San José de Guanipa', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(25, 2, 'San Juan de Capistrano', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(26, 2, 'Santa Ana', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(27, 2, 'Simón Bolívar', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(28, 2, 'Simón Rodríguez', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(29, 3, 'Achaguas', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(30, 3, 'Biruaca', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(31, 3, 'Muñóz', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(32, 3, 'Páez', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(33, 3, 'Pedro Camejo', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(34, 3, 'Rómulo Gallegos', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(35, 3, 'San Fernando', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(36, 4, 'Atanasio Girardot', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(37, 4, 'Bolívar', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(38, 4, 'Camatagua', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(39, 4, 'Francisco Linares Alcántara', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(40, 4, 'José Ángel Lamas', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(41, 4, 'José Félix Ribas', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(42, 4, 'José Rafael Revenga', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(43, 4, 'Libertador', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(44, 4, 'Mario Briceño Iragorry', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(45, 4, 'Ocumare de la Costa de Oro', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(46, 4, 'San Casimiro', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(47, 4, 'San Sebastián', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(48, 4, 'Santiago Mariño', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(49, 4, 'Santos Michelena', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(50, 4, 'Sucre', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(51, 4, 'Tovar', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(52, 4, 'Urdaneta', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(53, 4, 'Zamora', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(54, 5, 'Alberto Arvelo Torrealba', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(55, 5, 'Andrés Eloy Blanco', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(56, 5, 'Antonio José de Sucre', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(57, 5, 'Arismendi', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(58, 5, 'Barinas', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(59, 5, 'Bolívar', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(60, 5, 'Cruz Paredes', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(61, 5, 'Ezequiel Zamora', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(62, 5, 'Obispos', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(63, 5, 'Pedraza', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(64, 5, 'Rojas', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(65, 5, 'Sosa', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(66, 6, 'Caroní', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(67, 6, 'Cedeño', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(68, 6, 'El Callao', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(69, 6, 'Gran Sabana', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(70, 6, 'Heres', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(71, 6, 'Piar', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(72, 6, 'Angostura (Raúl Leoni)', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(73, 6, 'Roscio', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(74, 6, 'Sifontes', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(75, 6, 'Sucre', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(76, 6, 'Padre Pedro Chien', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(77, 7, 'Bejuma', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(78, 7, 'Carlos Arvelo', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(79, 7, 'Diego Ibarra', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(80, 7, 'Guacara', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(81, 7, 'Juan José Mora', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(82, 7, 'Libertador', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(83, 7, 'Los Guayos', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(84, 7, 'Miranda', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(85, 7, 'Montalbán', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(86, 7, 'Naguanagua', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(87, 7, 'Puerto Cabello', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(88, 7, 'San Diego', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(89, 7, 'San Joaquín', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(90, 7, 'Valencia', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(91, 8, 'Anzoátegui', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(92, 8, 'Tinaquillo', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(93, 8, 'Girardot', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(94, 8, 'Lima Blanco', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(95, 8, 'Pao de San Juan Bautista', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(96, 8, 'Ricaurte', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(97, 8, 'Rómulo Gallegos', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(98, 8, 'San Carlos', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(99, 8, 'Tinaco', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(100, 9, 'Antonio Díaz', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(101, 9, 'Casacoima', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(102, 9, 'Pedernales', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(103, 9, 'Tucupita', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(104, 10, 'Acosta', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(105, 10, 'Bolívar', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(106, 10, 'Buchivacoa', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(107, 10, 'Cacique Manaure', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(108, 10, 'Carirubana', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(109, 10, 'Colina', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(110, 10, 'Dabajuro', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(111, 10, 'Democracia', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(112, 10, 'Falcón', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(113, 10, 'Federación', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(114, 10, 'Jacura', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(115, 10, 'José Laurencio Silva', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(116, 10, 'Los Taques', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(117, 10, 'Mauroa', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(118, 10, 'Miranda', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(119, 10, 'Monseñor Iturriza', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(120, 10, 'Palmasola', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(121, 10, 'Petit', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(122, 10, 'Píritu', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(123, 10, 'San Francisco', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(124, 10, 'Sucre', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(125, 10, 'Tocópero', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(126, 10, 'Unión', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(127, 10, 'Urumaco', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(128, 10, 'Zamora', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(129, 11, 'Camaguán', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(130, 11, 'Chaguaramas', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(131, 11, 'El Socorro', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(132, 11, 'José Félix Ribas', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(133, 11, 'José Tadeo Monagas', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(134, 11, 'Juan Germán Roscio', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(135, 11, 'Julián Mellado', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(136, 11, 'Las Mercedes', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(137, 11, 'Leonardo Infante', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(138, 11, 'Pedro Zaraza', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(139, 11, 'Ortíz', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(140, 11, 'San Gerónimo de Guayabal', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(141, 11, 'San José de Guaribe', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(142, 11, 'Santa María de Ipire', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(143, 11, 'Sebastián Francisco de Miranda', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(144, 12, 'Andrés Eloy Blanco', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(145, 12, 'Crespo', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(146, 12, 'Iribarren', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(147, 12, 'Jiménez', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(148, 12, 'Morán', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(149, 12, 'Palavecino', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(150, 12, 'Simón Planas', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(151, 12, 'Torres', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(152, 12, 'Urdaneta', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(153, 13, 'Alberto Adriani', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(154, 13, 'Andrés Bello', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(155, 13, 'Antonio Pinto Salinas', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(156, 13, 'Aricagua', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(157, 13, 'Arzobispo Chacón', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(158, 13, 'Campo Elías', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(159, 13, 'Caracciolo Parra Olmedo', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(160, 13, 'Cardenal Quintero', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(161, 13, 'Guaraque', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(162, 13, 'Julio César Salas', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(163, 13, 'Justo Briceño', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(164, 13, 'Libertador', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(165, 13, 'Miranda', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(166, 13, 'Obispo Ramos de Lora', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(167, 13, 'Padre Noguera', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(168, 13, 'Pueblo Llano', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(169, 13, 'Rangel', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(170, 13, 'Rivas Dávila', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(171, 13, 'Santos Marquina', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(172, 13, 'Sucre', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(173, 13, 'Tovar', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(174, 13, 'Tulio Febres Cordero', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(175, 13, 'Zea', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(176, 14, 'Acevedo', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(177, 14, 'Andrés Bello', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(178, 14, 'Baruta', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(179, 14, 'Brión', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(180, 14, 'Buroz', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(181, 14, 'Carrizal', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(182, 14, 'Chacao', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(183, 14, 'Cristóbal Rojas', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(184, 14, 'El Hatillo', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(185, 14, 'Guaicaipuro', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(186, 14, 'Independencia', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(187, 14, 'Lander', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(188, 14, 'Los Salias', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(189, 14, 'Páez', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(190, 14, 'Paz Castillo', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(191, 14, 'Pedro Gual', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(192, 14, 'Plaza', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(193, 14, 'Simón Bolívar', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(194, 14, 'Sucre', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(195, 14, 'Urdaneta', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(196, 14, 'Zamora', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(197, 15, 'Acosta', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(198, 15, 'Aguasay', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(199, 15, 'Bolívar', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(200, 15, 'Caripe', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(201, 15, 'Cedeño', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(202, 15, 'Ezequiel Zamora', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(203, 15, 'Libertador', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(204, 15, 'Maturín', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(205, 15, 'Piar', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(206, 15, 'Punceres', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(207, 15, 'Santa Bárbara', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(208, 15, 'Sotillo', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(209, 15, 'Uracoa', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(210, 16, 'Antolin del Campo', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(211, 16, 'Arismendi', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(212, 16, 'García', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(213, 16, 'Gómez', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(214, 16, 'Maneiro', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(215, 16, 'Marcano', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(216, 16, 'Mariño', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(217, 16, 'Península de Macanao', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(218, 16, 'Tubores', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(219, 16, 'Villalba', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(220, 16, 'Díaz', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(221, 17, 'Agua Blanca', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(222, 17, 'Araure', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(223, 17, 'Esteller', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(224, 17, 'Guanare', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(225, 17, 'Guanarito', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(226, 17, 'Monseñor José Vicente de Unda', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(227, 17, 'Ospino', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(228, 17, 'Páez', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(229, 17, 'Papelón', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(230, 17, 'San Genaro de Boconoíto', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(231, 17, 'San Rafael de Onoto', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(232, 17, 'Santa Rosalía', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(233, 17, 'Sucre', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(234, 17, 'Turén', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(235, 18, 'Andrés Eloy Blanco', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(236, 18, 'Andrés Mata', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(237, 18, 'Arismendi', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(238, 18, 'Benítez', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(239, 18, 'Bermúdez', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(240, 18, 'Bolívar', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(241, 18, 'Cajigal', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(242, 18, 'Cruz Salmerón Acosta', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(243, 18, 'Libertador', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(244, 18, 'Mariño', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(245, 18, 'Mejía', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(246, 18, 'Montes', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(247, 18, 'Ribero', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(248, 18, 'Sucre', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(249, 18, 'Valdéz', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(250, 19, 'Andrés Bello', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(251, 19, 'Antonio Rómulo Costa', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(252, 19, 'Ayacucho', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(253, 19, 'Bolívar', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(254, 19, 'Cárdenas', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(255, 19, 'Córdoba', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(256, 19, 'Fernández Feo', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(257, 19, 'Francisco de Miranda', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(258, 19, 'García de Hevia', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(259, 19, 'Guásimos', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(260, 19, 'Independencia', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(261, 19, 'Jáuregui', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(262, 19, 'José María Vargas', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(263, 19, 'Junín', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(264, 19, 'Libertad', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(265, 19, 'Libertador', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(266, 19, 'Lobatera', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(267, 19, 'Michelena', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(268, 19, 'Panamericano', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(269, 19, 'Pedro María Ureña', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(270, 19, 'Rafael Urdaneta', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(271, 19, 'Samuel Darío Maldonado', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(272, 19, 'San Cristóbal', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(273, 19, 'Seboruco', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(274, 19, 'Simón Rodríguez', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(275, 19, 'Sucre', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(276, 19, 'Torbes', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(277, 19, 'Uribante', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(278, 19, 'San Judas Tadeo', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(279, 20, 'Andrés Bello', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(280, 20, 'Boconó', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(281, 20, 'Bolívar', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(282, 20, 'Candelaria', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(283, 20, 'Carache', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(284, 20, 'Escuque', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(285, 20, 'José Felipe Márquez Cañizalez', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(286, 20, 'Juan Vicente Campos Elías', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(287, 20, 'La Ceiba', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(288, 20, 'Miranda', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(289, 20, 'Monte Carmelo', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(290, 20, 'Motatán', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(291, 20, 'Pampán', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(292, 20, 'Pampanito', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(293, 20, 'Rafael Rangel', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(294, 20, 'San Rafael de Carvajal', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(295, 20, 'Sucre', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(296, 20, 'Trujillo', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(297, 20, 'Urdaneta', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(298, 20, 'Valera', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(299, 21, 'Vargas', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(300, 22, 'Arístides Bastidas', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(301, 22, 'Bolívar', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(302, 22, 'Bruzual', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(303, 22, 'Cocorote', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(304, 22, 'Independencia', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(305, 22, 'José Antonio Páez', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(306, 22, 'La Trinidad', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(307, 22, 'Manuel Monge', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(308, 22, 'Nirgua', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(309, 22, 'Peña', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(310, 22, 'San Felipe', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(311, 22, 'Sucre', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(312, 22, 'Urachiche', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(313, 22, 'José Joaquín Veroes', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(314, 23, 'Almirante Padilla', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(315, 23, 'Baralt', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(316, 23, 'Cabimas', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(317, 23, 'Catatumbo', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(318, 23, 'Colón', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(319, 23, 'Francisco Javier Pulgar', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(320, 23, 'Páez', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(321, 23, 'Jesús Enrique Losada', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(322, 23, 'Jesús María Semprún', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(323, 23, 'La Cañada de Urdaneta', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(324, 23, 'Lagunillas', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(325, 23, 'Machiques de Perijá', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(326, 23, 'Mara', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(327, 23, 'Maracaibo', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(328, 23, 'Miranda', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(329, 23, 'Rosario de Perijá', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(330, 23, 'San Francisco', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(331, 23, 'Santa Rita', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(332, 23, 'Simón Bolívar', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(333, 23, 'Sucre', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(334, 23, 'Valmore Rodríguez', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(335, 24, 'Libertador', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `orders`
--

CREATE TABLE `orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `ord_prod_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_prod_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ord_address` bigint(20) UNSIGNED DEFAULT NULL,
  `ord_price_bs` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_price_usd` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ord_description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ord_status` bigint(191) DEFAULT NULL,
  `ord_extras` bigint(20) UNSIGNED DEFAULT NULL,
  `ord_rate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ord_dm_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ord_dm_rate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ord_payment_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `cl_id` bigint(20) NOT NULL,
  `bank_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `orders`
--

INSERT INTO `orders` (`id`, `ord_prod_name`, `ord_prod_id`, `ord_address`, `ord_price_bs`, `ord_price_usd`, `ord_description`, `ord_status`, `ord_extras`, `ord_rate`, `ord_dm_id`, `ord_dm_rate`, `ord_payment_id`, `created_at`, `updated_at`, `deleted_at`, `cl_id`, `bank_name`) VALUES
(1, 'aasda', 1, 1, '45', '52', 'asda', 4, 1, NULL, 1, NULL, 1, '2020-04-10 06:31:38', NULL, NULL, 0, NULL),
(6, 'asdasd', 1, 2, '1', NULL, 'las papas sin pollo.', NULL, NULL, NULL, NULL, NULL, NULL, '2020-05-20 03:21:34', '2020-05-20 03:21:34', NULL, 0, NULL),
(7, 'asdasd', NULL, 2, '1', NULL, 'las papas sin pollo.', NULL, NULL, NULL, NULL, NULL, 2, '2020-05-20 23:41:24', '2020-05-20 23:41:24', NULL, 0, NULL),
(8, 'asdasd', NULL, 2, '1', NULL, 'las papas sin pollo.', NULL, NULL, NULL, NULL, NULL, 3, '2020-05-20 23:54:12', '2020-05-20 23:54:12', NULL, 0, NULL),
(9, 'orden bien', NULL, 2, '1', NULL, 'las papas sin pollo.', NULL, NULL, NULL, NULL, NULL, 4, '2020-05-21 01:52:50', '2020-05-21 01:52:50', NULL, 0, NULL),
(10, 'orden bien', NULL, 2, '1', NULL, 'las papas sin pollo.', NULL, NULL, NULL, NULL, NULL, 5, '2020-05-30 11:40:18', '2020-05-30 11:40:18', NULL, 0, NULL),
(11, 'orden bien', NULL, 2, '1', NULL, 'las papas sin pollo.', NULL, NULL, NULL, NULL, NULL, 6, '2020-05-30 23:49:21', '2020-05-30 23:49:21', NULL, 0, NULL),
(12, 'Orden nueva', 25, 1, '5100', NULL, 'ord_description', 1, NULL, NULL, NULL, NULL, 7, '2020-06-02 03:04:33', '2020-06-02 03:04:33', NULL, 0, NULL),
(13, 'Orden nueva 2', 2, 1, '5100', NULL, 'ord_description', 1, NULL, NULL, NULL, NULL, 8, '2020-06-02 03:06:43', '2020-06-02 03:06:43', NULL, 0, NULL),
(14, 'Orden nueva 2', 16, 1, '5100', NULL, 'ord_description', 1, NULL, NULL, NULL, NULL, 9, '2020-06-02 03:09:02', '2020-06-02 03:09:02', NULL, 0, NULL),
(15, 'Orden nueva 2', NULL, 1, '5100', NULL, 'ord_description', 1, NULL, NULL, NULL, NULL, 10, '2020-06-02 03:10:27', '2020-06-02 03:10:27', NULL, 0, NULL),
(16, 'Orden nueva 2', NULL, 1, '5100', NULL, 'ord_description', 1, NULL, NULL, NULL, NULL, 11, '2020-06-02 03:11:46', '2020-06-02 03:11:46', NULL, 0, NULL),
(17, 'Orden nueva 2', NULL, 1, '5100', NULL, 'ord_description', NULL, NULL, NULL, NULL, NULL, 12, '2020-06-02 23:39:28', '2020-06-02 23:39:28', NULL, 0, NULL),
(18, 'Orden nueva 2', NULL, 1, '5100', NULL, 'ord_description', NULL, NULL, NULL, NULL, NULL, 13, '2020-06-02 23:45:53', '2020-06-02 23:45:53', NULL, 0, NULL),
(19, 'Orden nueva 2', 1, 1, '5100', NULL, 'ord_description', 1, NULL, NULL, NULL, NULL, 14, '2020-06-09 03:55:22', '2020-06-09 03:55:22', NULL, 0, NULL),
(20, 'Orden nuevaaaaaaaaaaa', 1, 1, '5100', NULL, 'ord_description', 2, NULL, NULL, NULL, NULL, 15, '2020-06-09 03:59:43', '2020-06-09 04:01:50', NULL, 0, NULL),
(21, 'Pasta carbonara', 11, 1, '5100', NULL, 'ord_description', 1, NULL, NULL, NULL, NULL, 20, '2020-06-10 04:06:10', '2020-06-10 04:06:10', NULL, 1, 'Mercantil'),
(22, 'Pasta carbonara', 11, 1, '5100', NULL, 'ord_description', 1, NULL, NULL, NULL, NULL, 21, '2020-06-10 07:32:26', '2020-06-10 07:32:26', NULL, 1, 'Mercantil'),
(23, 'Jessie Gleason', 1, 1, '5100', NULL, 'ord_description', 1, NULL, NULL, NULL, NULL, 22, '2020-06-11 03:25:49', '2020-06-11 03:25:49', NULL, 28, 'Mercantil'),
(24, 'Prof. Elian Braun', 3, 1, '5100', NULL, 'ord_description', 1, NULL, NULL, NULL, NULL, 23, '2020-06-11 07:33:22', '2020-06-11 07:33:22', NULL, 3, 'Mercantil');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `orders_status_type`
--

CREATE TABLE `orders_status_type` (
  `id` bigint(20) NOT NULL,
  `status_name` varchar(255) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `orders_status_type`
--

INSERT INTO `orders_status_type` (`id`, `status_name`) VALUES
(0, 'Entregada a repartidor'),
(1, 'Sin aprobar'),
(2, 'Aprobada,'),
(4, 'Entregada cliente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `partners`
--

CREATE TABLE `partners` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `p_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_user` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_phone_1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_phone_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_rif` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_rs_id` bigint(20) UNSIGNED DEFAULT NULL,
  `p_mun_id` bigint(20) UNSIGNED DEFAULT NULL,
  `p_adrress` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_cat_id` bigint(20) UNSIGNED DEFAULT NULL,
  `p_intents` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_blocked` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_pass_exp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `bank_account` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `zelle` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `p_open_time` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_close_time` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_rate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_shipping` bigint(20) DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `percent_amount` decimal(10,0) NOT NULL,
  `percent_up` varchar(11) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `profile_pic` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_dni` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_cat_id` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `partners`
--

INSERT INTO `partners` (`id`, `p_name`, `p_last_name`, `p_user`, `p_email`, `p_phone_1`, `p_phone_2`, `password`, `p_rif`, `p_rs_id`, `p_mun_id`, `p_adrress`, `p_cat_id`, `p_intents`, `p_blocked`, `p_pass_exp`, `bank_name`, `bank_account`, `zelle`, `p_open_time`, `p_close_time`, `p_rate`, `p_description`, `p_shipping`, `remember_token`, `created_at`, `updated_at`, `deleted_at`, `percent_amount`, `percent_up`, `profile_pic`, `p_dni`, `sub_cat_id`) VALUES
(1, 'Darrell Blick', 'Doyle', 'corrupti', 'margret.mccullough@roberts.com', '1-594-417-5606', '248.773.6312 x4634', '$2y$10$UrfXtTr0cbMXD4rhNbGFPuyE9R2CADma7QITAzik99eyVQBFk.sFi', '3', NULL, 2, '487 Koelpin Islands Apt. 274South Camilleberg, AL 14684', 5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '14:34', NULL, 'ASDASDDFS', NULL, NULL, NULL, '2020-04-20 05:16:29', NULL, 0, NULL, NULL, '', NULL),
(13, 'macdonals', 'last name mac', 'Macdonals', 'sdfsdfsdfs@gmail.com', '04143944752', '04166944549', '$2y$10$6v4kHxKAGafJgY.B3CKySOPF6H3eiYCwI7/QgA3Sz.SAJk4JSPnQ2', 'V266239854', NULL, 30, 'Caricuao, Caracas.', 2, NULL, NULL, NULL, 'bod', '12345678910111213141', 'gioan@gmail.com', '13:00', '00:59', NULL, 'fsdfdsfsdfsf', NULL, NULL, '2020-05-11 19:44:52', '2020-05-31 01:50:38', NULL, 0, NULL, '5ed2d52eb3fd15ebb51f3c9987logo rucula.png', '', NULL),
(15, 'sdfsfsdfasdadasd', 'sdfsdf', 'Wendys', 'sdfssdfsdfs@gmail.com', '04143944752', '04166944549', '$2y$10$N9E7U3o6Xp/iYZ4OwWyl.uJavVW2w3N01uFG53be9nIYZSvfVdN1e', 'V2662398545', NULL, 1, 'Caricuao, Caracas.', 1, NULL, NULL, NULL, 'bod', '12345678910111213141', 'gioan@gmail.com', '13:58', '12:59', NULL, 'sfsdfsdf', NULL, NULL, '2020-05-11 20:31:02', '2020-05-12 09:36:40', NULL, 5, NULL, '5eba35e8240d46063.jpg', '', NULL),
(16, 'javiers Bistro', 'andrade', 'Javiers Bistro', 'gioan@gmail.com', '04143944752', '04166944549', '$2y$12$4oPD6PBTyMVIyKiEw1d.hudBI1DYcDz68NcUF9w4SOjGQS.D91ZTq', 'V266239854', NULL, 2, 'Caricuao, Caracas.', 2, NULL, NULL, NULL, 'bod', '12345678910111213141', 'gioan@gmail.com', '14:00', '12:59', NULL, 'jghjg', NULL, NULL, '2020-05-11 22:34:32', '2020-05-30 10:29:57', NULL, 15, 'on', '5ed1fd656db88splash.png', '', NULL),
(44, 'javier', 'fdgfdgdf', 'Pizpa fun', 'gdfgdgdfgdfgdfgfd@hail.com', '04143944752', '04143944752', '$2y$10$pnt92iDkgRegW7d5YmowEeaubdVl0zVPDAs7B6VRZDoBwQ6LMaCne', 'V2146810872', NULL, 9, 'Caricuao, Caracas.', 5, NULL, NULL, NULL, '', '', NULL, '13:59', '01:00', NULL, 'sdfsdfsdf', NULL, NULL, '2020-05-12 12:07:14', '2020-05-12 12:07:14', NULL, 15, 'on', NULL, '25416060444', NULL),
(45, 'iiiiiiiiiiiiiii', 'iiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiiii', 'Pizza hunt', 'iiiiiiiiiiiiii@gmail.com', '04143944752', '04166944549', '$2y$10$oDQhL/.L2OOiEi7EaEC3L.LMdCXFH0pUo9I6JbOiTWAE0quBh0a1K', '4564545456456', NULL, 2, 'Caricuao, Caracas.', 1, NULL, NULL, NULL, '', '', NULL, '12:59', '12:59', NULL, 'sasdsadasdasd', NULL, NULL, '2020-05-12 12:11:04', '2020-05-30 09:52:01', NULL, 45, 'on', '5ed1f48159051splash (3).png', '254160600', NULL),
(46, 'Lorenzo', 'mendoza', 'Nestle', 'mendoza@gmail.com', '04143944752', '04166944549', '$2y$10$nqgarR9lC0k66.AhsMh3m.lexrdFPHtaLoEYiLj4hi2o5NYryuwBq', 'V266239854', NULL, 8, 'Caricuao, Caracas.', 2, NULL, NULL, NULL, '', '', NULL, '13:59', '13:59', NULL, NULL, NULL, NULL, '2020-05-12 12:15:56', '2020-06-01 08:24:41', NULL, 15, 'on', '5ed48309eefacsplash.png', '12345678', NULL),
(47, 'Jose', 'Rondon', 'Rucula Restaurant', 'rucularestaurant@gmail.com', '02432714381', '04243122090', '$2y$10$j4QQs9OpLwLaJ51OGrYwOeFwH/ENIOpcbXLWam479HtYbM2DGgc8W', '1234567', NULL, 36, 'Circulo Miliar Las Delicias, Local Nro 50.', 1, NULL, NULL, NULL, '', '', NULL, '08:00', '23:00', NULL, NULL, NULL, NULL, '2020-05-13 05:46:57', '2020-05-30 11:14:12', NULL, 15, 'on', '5ed207c49f7e55ebb51f3c9987logo rucula.png', '2525252525', NULL),
(49, 'Dominos', 'Rondon', 'Domino\'s pizza', 'dominos@gmail.com', '04143944752', '+584166944549', '$2y$10$rT4QUznoCBXpvsuREOqVQuxAynsOQh8dLdgloNdbCCpWJsouNrtVm', 'V266239859', NULL, 178, 'Caricuao, Caracas.', 3, NULL, NULL, NULL, '', '', NULL, '13:59', '01:59', NULL, 'Restaurante', NULL, NULL, '2020-05-27 05:02:12', '2020-05-30 10:50:54', NULL, 16, 'on', '5ed2024e8d780splash.png', '1842517814', 15),
(50, 'Fiorella', 'Gonzalez', 'Las Marquesas de Fiore', 'fioregonz@gmail.com', '04144572221', '04144572221', '$2y$10$YtMdp2L2YS1P.7Cb73n3S.c9kAY8qKS5qF0iRB1vcVCGG.0uIf7/G', '1234567', NULL, 36, 'urb calicanto, calle lopez aveledo, edif residencias calicanto PH-A', 1, NULL, NULL, NULL, '', '', NULL, '09:00', '23:00', NULL, 'Las Marquesas de Fiore, las mejores Marquesas de Maracay', NULL, NULL, '2020-06-16 22:53:53', '2020-06-16 22:53:53', NULL, 10, NULL, NULL, '9678964', 10);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `partner_accounts_partners`
--

CREATE TABLE `partner_accounts_partners` (
  `id` int(11) DEFAULT NULL,
  `bank_name` varchar(255) DEFAULT NULL,
  `bank_account` varchar(255) DEFAULT NULL,
  `partners_id` bigint(20) NOT NULL,
  `partner_accounts_id` varchar(20) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `partner_accounts_partners`
--

INSERT INTO `partner_accounts_partners` (`id`, `bank_name`, `bank_account`, `partners_id`, `partner_accounts_id`) VALUES
(NULL, NULL, NULL, 36, '45645645645645645645'),
(NULL, NULL, NULL, 36, '45656456456456454564'),
(NULL, NULL, NULL, 44, 'bod'),
(NULL, NULL, NULL, 44, 'bods'),
(NULL, NULL, NULL, 45, 'bodssss'),
(NULL, NULL, NULL, 45, 'bodsssss'),
(NULL, NULL, NULL, 46, '45645645645645645645'),
(NULL, NULL, NULL, 46, '44564645645645645645'),
(NULL, NULL, NULL, 47, '12345678912345678911'),
(NULL, NULL, NULL, 48, '44564645645645645645'),
(NULL, NULL, NULL, 49, '45645645645645645645'),
(NULL, NULL, NULL, 50, '01050190381190106388'),
(NULL, NULL, NULL, 50, '01340034200341059786');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `partner_payments`
--

CREATE TABLE `partner_payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `partner_id` bigint(20) UNSIGNED DEFAULT NULL,
  `payment_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `partner_payments`
--

INSERT INTO `partner_payments` (`id`, `partner_id`, `payment_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `payments`
--

CREATE TABLE `payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `pay_platform_id` bigint(20) NOT NULL,
  `pay_ref` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pay_type` bigint(20) NOT NULL,
  `pay_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `pay_amount` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `payments`
--

INSERT INTO `payments` (`id`, `pay_platform_id`, `pay_ref`, `pay_type`, `pay_description`, `pay_amount`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, '1012455', 1, 'pago por deuda mes 1', '1000', '2020-03-22 02:17:46', NULL, NULL),
(2, 1, '23424', 2, 'Pago por cliene', '1', '2020-05-20 23:41:24', '2020-05-20 23:41:24', NULL),
(3, 1, '23424', 2, 'Pago por cliene', '1', '2020-05-20 23:54:12', '2020-05-20 23:54:12', NULL),
(4, 1, '23424', 2, 'Pago por cliene', '1', '2020-05-21 01:52:50', '2020-05-21 01:52:50', NULL),
(5, 1, '23424', 2, 'Pago por cliene', '1', '2020-05-30 11:40:18', '2020-05-30 11:40:18', NULL),
(6, 1, '23424', 2, 'Pago por cliene', '1', '2020-05-30 23:49:21', '2020-05-30 23:49:21', NULL),
(7, 1, 'ASDASD', 2, 'Pago por cliene', '5100', '2020-06-02 03:04:33', '2020-06-02 03:04:33', NULL),
(8, 1, 'Aadsad', 2, 'Pago por cliene', '5100', '2020-06-02 03:06:43', '2020-06-02 03:06:43', NULL),
(9, 1, 'asdasdsfd', 2, 'Pago por cliene', '5100', '2020-06-02 03:09:02', '2020-06-02 03:09:02', NULL),
(10, 1, 'sdfsdf', 2, 'Pago por cliene', '5100', '2020-06-02 03:10:27', '2020-06-02 03:10:27', NULL),
(11, 1, 'asdfsfsf', 2, 'Pago por cliene', '5100', '2020-06-02 03:11:46', '2020-06-02 03:11:46', NULL),
(12, 1, '123324', 2, 'Pago por cliene', '5100', '2020-06-02 23:39:28', '2020-06-02 23:39:28', NULL),
(13, 1, '1234434', 2, 'Pago por cliene', '5100', '2020-06-02 23:45:53', '2020-06-02 23:45:53', NULL),
(14, 1, '5395', 2, 'Pago por cliene', '5100', '2020-06-09 03:55:22', '2020-06-09 03:55:22', NULL),
(15, 1, '517895', 2, 'Pago por cliene', '5100', '2020-06-09 03:59:43', '2020-06-09 03:59:43', NULL),
(16, 1, '589588', 2, 'Pago por cliene', '5100', '2020-06-10 03:41:35', '2020-06-10 03:41:35', NULL),
(17, 1, '94885788', 2, 'Pago por cliene', '5100', '2020-06-10 03:46:27', '2020-06-10 03:46:27', NULL),
(18, 1, '658655', 2, 'Pago por cliene', '5100', '2020-06-10 03:48:31', '2020-06-10 03:48:31', NULL),
(19, 1, '54955', 2, 'Pago por cliene', '5100', '2020-06-10 03:50:15', '2020-06-10 03:50:15', NULL),
(20, 1, '578578', 2, 'Pago por cliene', '5100', '2020-06-10 04:06:10', '2020-06-10 04:06:10', NULL),
(21, 1, '5855', 2, 'Pago por cliene', '5100', '2020-06-10 07:32:26', '2020-06-10 07:32:26', NULL),
(22, 1, '85', 2, 'Pago por cliene', '5100', '2020-06-11 03:25:49', '2020-06-11 03:25:49', NULL),
(23, 1, '5847884', 2, 'Pago por cliene', '5100', '2020-06-11 07:33:22', '2020-06-11 07:33:22', NULL),
(24, 1, '23424', 2, 'Pago por cliene', '1', '2020-06-11 22:19:49', '2020-06-11 22:19:49', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `payments_platforms`
--

CREATE TABLE `payments_platforms` (
  `id` bigint(20) NOT NULL,
  `platform_payment` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `payments_platforms`
--

INSERT INTO `payments_platforms` (`id`, `platform_payment`) VALUES
(1, 'transferencia bancaria'),
(2, 'zelle'),
(3, 'pago movil');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `payment_type`
--

CREATE TABLE `payment_type` (
  `id` bigint(10) NOT NULL,
  `pay_type` varchar(20) DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `payment_type`
--

INSERT INTO `payment_type` (`id`, `pay_type`) VALUES
(1, 'Pago a socio'),
(2, 'Pago a delivery'),
(3, 'Pago a cliente');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `prod_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prod_partner_id` bigint(20) UNSIGNED DEFAULT NULL,
  `prod_price_bs` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prod_price_usd` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prod_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `prod_category` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prod_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `products`
--

INSERT INTO `products` (`id`, `prod_name`, `prod_partner_id`, `prod_price_bs`, `prod_price_usd`, `prod_description`, `created_at`, `updated_at`, `deleted_at`, `prod_category`, `prod_image`) VALUES
(1, 'Jessie Gleason', 49, '9029', '9269', 'aut', '2020-04-11 07:53:35', '2020-05-11 20:09:58', '2020-05-11 20:09:58', NULL, NULL),
(2, 'Mr. Unique Blanda', 1, '6614', '1685', 'iusto', '2020-04-11 07:53:39', NULL, NULL, NULL, NULL),
(3, 'Prof. Elian Braun', 1, '2515', '8535', 'impedit', '2020-04-11 07:53:44', NULL, NULL, NULL, NULL),
(4, 'Nella Schulist', 1, '6972', '1747', 'dolorum', NULL, NULL, NULL, NULL, NULL),
(5, 'Eryn Keebler IV', 1, '8997', '3987', 'occaecati', '2020-04-11 07:53:47', NULL, NULL, NULL, NULL),
(6, 'Magdalen Bode', 1, '8064', '7980', 'odio', NULL, NULL, NULL, NULL, NULL),
(7, 'Kayla Bergstrom', 1, '7952', '4617', 'ea', NULL, NULL, NULL, NULL, NULL),
(8, 'Isadore Powlowski', 1, '485', '1631', 'dolores', NULL, NULL, NULL, NULL, NULL),
(9, 'Ms. Virginia Graham', 1, '4045', '4826', 'libero', NULL, NULL, NULL, NULL, NULL),
(10, 'Enrique Watsica', 1, '731', '2312', 'tenetur', NULL, NULL, NULL, NULL, NULL),
(11, 'Pasta carbonara', 16, '100', '2', 'zczxczxc', '2020-05-12 04:35:10', '2020-06-11 00:41:56', NULL, NULL, '5ed6d720574f3banner-arepa.jpg'),
(13, 'Pasta bologna', 16, '12', '123312.00', 'Pasta con carne molida', '2020-05-12 04:39:29', '2020-06-03 02:48:33', NULL, NULL, '5ed6d741dc519Harina-de-maiz-blanco-P.A.N.-1-Kg.jpg'),
(14, 'Pasta carbonara4', 46, '40000', '100.00', 'sdfdsfsdfsfs', '2020-05-12 12:25:22', '2020-05-12 13:15:21', '2020-05-12 13:15:21', 'sdfsdfsdfsdf', '5eba685d9a85f6063.jpg'),
(15, 'Pasta carbonara4', 16, '40', '123', 'sdfsdfsd', '2020-05-12 13:16:07', '2020-05-12 13:17:33', '2020-05-12 13:17:33', 'sdfsdfsdf', NULL),
(16, 'Pasta carbonara', 46, '4000000', '123123', 'asdasd', '2020-05-12 13:19:21', '2020-05-12 13:29:06', '2020-05-12 13:29:06', 'sdfsdfsdfsdf', NULL),
(17, 'Pasta carbonara4', 46, '450000', '123312.00', 'sdfsdfsd', '2020-05-12 13:22:08', '2020-05-12 13:28:40', '2020-05-12 13:28:40', 'dfgdfgdf', '5eba6b0b29eb16063.jpg'),
(20, 'Pasta carbonara', 46, '6452121', '123312.00', 'sdfdsf', '2020-05-12 13:35:35', '2020-06-01 09:25:36', NULL, 'sdfsdfsdf', '5ed49150b1f0cdescarga.jpg'),
(21, 'sdfsdfsdfsdf', 46, '55000000', '123123', 'sdfsdfds', '2020-05-12 13:36:02', '2020-05-13 20:43:48', NULL, 'dfgfdgdfg', '5ebc23c44b4efimages.jfif'),
(22, 'asdasdasdad', 46, '490000', '150', 'asdsad', '2020-05-12 13:47:33', '2020-05-12 13:47:33', NULL, 'sdsdf', NULL),
(23, 'Pasta carbonara4', 46, '48000', '123312.00', 'sdfdfgfg', '2020-05-12 13:54:18', '2020-05-12 13:54:18', NULL, 'dfgfdgfdg', NULL),
(24, 'Producto A', 45, '480000', '8', 'producto a descripcion', '2020-05-13 03:49:34', '2020-05-13 03:49:55', NULL, NULL, '5ebb362397bc7Café espresso gourmet Pilon 283 gr.jpeg'),
(25, 'Alitas BBQ', 47, '6900000', '6', 'Alitas de Pollo', '2020-05-13 06:00:57', '2020-05-13 06:01:57', NULL, NULL, '5ebb5515e8c7dalitas.jpg'),
(26, 'Pizza Margarita', 49, '50', '45', 'Pizza con queso mozarella y salsa,', '2020-05-30 11:20:11', '2020-05-31 03:28:29', NULL, NULL, '5ed2097163551descarga.jpg'),
(27, 'Producto A', 16, NULL, '50', 'descripcion nueva', '2020-06-03 02:49:13', '2020-06-03 02:49:13', NULL, NULL, NULL),
(28, 'Alitas BBQ', 47, NULL, '12', '1asasa', '2020-06-03 04:11:01', '2020-06-03 04:11:17', NULL, NULL, '5ed6eaa54c1b4banner-arepa.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `product_tags`
--

CREATE TABLE `product_tags` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `prod_extras`
--

CREATE TABLE `prod_extras` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `pe_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pe_price_bs` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pe_price_usd` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pe_partner_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `prod_extras`
--

INSERT INTO `prod_extras` (`id`, `pe_name`, `pe_price_bs`, `pe_price_usd`, `pe_partner_id`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'quesp', '50', '50', 1, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rates`
--

CREATE TABLE `rates` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `rt_value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `rate_list`
--

CREATE TABLE `rate_list` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `rate_order_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles_permissions`
--

CREATE TABLE `roles_permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles_users`
--

CREATE TABLE `roles_users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `rs_perms_id` bigint(20) UNSIGNED NOT NULL,
  `rs_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `states`
--

CREATE TABLE `states` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `st_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `st_iso` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `states`
--

INSERT INTO `states` (`id`, `st_name`, `st_iso`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Amazonas', 'VE-X', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(2, 'Anzoátegui', 'VE-B', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(3, 'Apure', 'VE-C', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(4, 'Aragua', 'VE-D', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(5, 'Barinas', 'VE-E', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(6, 'Bolívar', 'VE-F', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(7, 'Carabobo', 'VE-G', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(8, 'Cojedes', 'VE-H', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(9, 'Delta Amacuro', 'VE-Y', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(10, 'Falcón', 'VE-I', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(11, 'Guárico', 'VE-J', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(12, 'Lara', 'VE-K', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(13, 'Mérida', 'VE-L', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(14, 'Miranda', 'VE-M', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(15, 'Monagas', 'VE-N', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(16, 'Nueva Esparta', 'VE-O', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(17, 'Portuguesa', 'VE-P', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(18, 'Sucre', 'VE-R', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(19, 'Táchira', 'VE-S', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(20, 'Trujillo', 'VE-T', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(21, 'Vargas', 'VE-W', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(22, 'Yaracuy', 'VE-U', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(23, 'Zulia', 'VE-V', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(24, 'Distrito Capital', 'VE-A', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL),
(25, 'Dependencias Federales', 'VE-Z', '2020-03-13 07:40:18', '2020-03-13 07:40:18', NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `subcategory`
--

CREATE TABLE `subcategory` (
  `id` int(11) NOT NULL,
  `sub_cat_name` varchar(255) DEFAULT NULL,
  `cat_id` bigint(20) NOT NULL,
  `created_at` varchar(255) DEFAULT NULL,
  `deleted_at` varchar(255) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `subcategory`
--

INSERT INTO `subcategory` (`id`, `sub_cat_name`, `cat_id`, `created_at`, `deleted_at`, `updated_at`) VALUES
(0, 'China', 1, NULL, NULL, NULL),
(1, 'Japonesa', 1, NULL, NULL, NULL),
(3, 'italiana', 1, NULL, NULL, NULL),
(4, 'Mexicana', 1, NULL, NULL, NULL),
(5, 'Venezolana', 1, NULL, NULL, NULL),
(6, 'Comida Rapida', 1, NULL, NULL, NULL),
(7, 'Pizzas', 1, NULL, NULL, NULL),
(8, 'Hamburguesas', 1, NULL, NULL, NULL),
(9, 'Sushi', 1, NULL, NULL, NULL),
(10, 'Postres', 1, NULL, NULL, NULL),
(11, 'Helados', 1, NULL, NULL, NULL),
(12, 'Cafe', 1, NULL, NULL, NULL),
(13, 'Panadería', 1, NULL, NULL, NULL),
(14, 'Parrilla', 1, NULL, NULL, NULL),
(15, 'Calzado', 3, NULL, NULL, NULL),
(16, 'Electronica', 3, NULL, NULL, NULL),
(17, 'Informatica', 3, NULL, NULL, NULL),
(18, 'Ropa', 3, NULL, NULL, NULL),
(19, 'Niños', 3, NULL, NULL, NULL),
(20, 'Electrodomesticos', 3, NULL, NULL, NULL),
(21, 'Ferreteria', 3, NULL, NULL, NULL),
(22, 'Vehiculos', 3, NULL, NULL, NULL),
(23, 'Muebles', 3, NULL, NULL, NULL),
(24, 'Mascotas', 3, NULL, NULL, NULL),
(25, 'Popular', 2, NULL, NULL, NULL),
(26, 'Farmarket', 2, NULL, NULL, NULL),
(27, 'Fruteria', 4, NULL, NULL, NULL),
(28, 'Charcuteria', 4, NULL, NULL, NULL),
(29, 'Carniceria', 4, NULL, NULL, NULL),
(30, 'Mini Mercado', 4, NULL, NULL, NULL),
(31, 'Super Mercado', 4, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `transactions_history`
--

CREATE TABLE `transactions_history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'gioanfranco', 'gioan2908@gmail.com', NULL, '$2y$10$lw7KXG/P0lbNFmcpN6wIJuC1QmqFvlUkL.O3CvtCaXzU2XQugRnEC', NULL, NULL, NULL, NULL),
(4, 'arthuro', 'arthuroblanco@gmail.com', NULL, '$2y$10$b6AncoKn.MRUl8pR1NEvheDUhV8I4sHNquUax9GeovCxaQnAULwuO', NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `working_status`
--

CREATE TABLE `working_status` (
  `id` varchar(255) NOT NULL,
  `status` varchar(1) NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `working_status`
--

INSERT INTO `working_status` (`id`, `status`, `updated_at`, `deleted_at`, `created_at`) VALUES
('1', '1', '2020-05-27 01:42:28', NULL, NULL);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `address`
--
ALTER TABLE `address`
  ADD PRIMARY KEY (`id`),
  ADD KEY `address_st_id_foreign` (`st_id`),
  ADD KEY `address_mun_id_foreign` (`mun_id`);

--
-- Indices de la tabla `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_ad_email_unique` (`ad_email`),
  ADD UNIQUE KEY `admins_ad_user_name_unique` (`ad_user_name`),
  ADD KEY `admins_ad_rs_id_foreign` (`ad_rs_id`);

--
-- Indices de la tabla `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `clients_cl_user_unique` (`cl_user`),
  ADD UNIQUE KEY `clients_cl_email_unique` (`cl_email`),
  ADD KEY `clients_cl_rs_id_foreign` (`cl_rs_id`);

--
-- Indices de la tabla `clients_address`
--
ALTER TABLE `clients_address`
  ADD PRIMARY KEY (`id`),
  ADD KEY `clients_address_ca_cl_id_foreign` (`ca_cl_id`),
  ADD KEY `clients_address_ca_address_id_foreign` (`ca_address_id`);

--
-- Indices de la tabla `curriencies`
--
ALTER TABLE `curriencies`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `delivery_man`
--
ALTER TABLE `delivery_man`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `delivery_man_dm_user_unique` (`dm_user`),
  ADD UNIQUE KEY `delivery_man_dm_email_unique` (`dm_email`),
  ADD KEY `delivery_man_dm_rs_id_foreign` (`dm_rs_id`);

--
-- Indices de la tabla `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `municipios`
--
ALTER TABLE `municipios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `municipios_states_id_foreign` (`states_id`);

--
-- Indices de la tabla `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `orders_ord_prod_id_foreign` (`ord_prod_id`),
  ADD KEY `orders_ord_address_foreign` (`ord_address`),
  ADD KEY `orders_ord_extras_foreign` (`ord_extras`),
  ADD KEY `orders_ord_dm_id_foreign` (`ord_dm_id`),
  ADD KEY `orders_ord_payment_id_foreign` (`ord_payment_id`),
  ADD KEY `orders_ord_status_foreign` (`ord_status`);

--
-- Indices de la tabla `orders_status_type`
--
ALTER TABLE `orders_status_type`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `partners`
--
ALTER TABLE `partners`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `partners_p_user_unique` (`p_user`),
  ADD UNIQUE KEY `partners_p_email_unique` (`p_email`),
  ADD KEY `partners_p_rs_id_foreign` (`p_rs_id`),
  ADD KEY `partners_p_mun_id_foreign` (`p_mun_id`),
  ADD KEY `partners_p_cat_id_foreign` (`p_cat_id`);

--
-- Indices de la tabla `partner_payments`
--
ALTER TABLE `partner_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `partner_payments_partner_id_foreign` (`partner_id`),
  ADD KEY `partner_payments_payment_id_foreign` (`payment_id`);

--
-- Indices de la tabla `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indices de la tabla `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payment_type_id_fk` (`pay_type`),
  ADD KEY `payment_platform_id_fk` (`pay_platform_id`);

--
-- Indices de la tabla `payments_platforms`
--
ALTER TABLE `payments_platforms`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `payment_type`
--
ALTER TABLE `payment_type`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indices de la tabla `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_prod_partner_id_foreign` (`prod_partner_id`);

--
-- Indices de la tabla `product_tags`
--
ALTER TABLE `product_tags`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `prod_extras`
--
ALTER TABLE `prod_extras`
  ADD PRIMARY KEY (`id`),
  ADD KEY `prod_extras_pe_partner_id_foreign` (`pe_partner_id`);

--
-- Indices de la tabla `rates`
--
ALTER TABLE `rates`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `rate_list`
--
ALTER TABLE `rate_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rate_list_rate_order_id_foreign` (`rate_order_id`);

--
-- Indices de la tabla `roles_permissions`
--
ALTER TABLE `roles_permissions`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `roles_users`
--
ALTER TABLE `roles_users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `roles_users_rs_perms_id_foreign` (`rs_perms_id`);

--
-- Indices de la tabla `states`
--
ALTER TABLE `states`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `subcategory`
--
ALTER TABLE `subcategory`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `transactions_history`
--
ALTER TABLE `transactions_history`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- Indices de la tabla `working_status`
--
ALTER TABLE `working_status`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `address`
--
ALTER TABLE `address`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de la tabla `clients`
--
ALTER TABLE `clients`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=118;

--
-- AUTO_INCREMENT de la tabla `clients_address`
--
ALTER TABLE `clients_address`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `curriencies`
--
ALTER TABLE `curriencies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `delivery_man`
--
ALTER TABLE `delivery_man`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT de la tabla `municipios`
--
ALTER TABLE `municipios`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=336;

--
-- AUTO_INCREMENT de la tabla `orders`
--
ALTER TABLE `orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT de la tabla `partners`
--
ALTER TABLE `partners`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT de la tabla `partner_payments`
--
ALTER TABLE `partner_payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `payments`
--
ALTER TABLE `payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT de la tabla `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT de la tabla `product_tags`
--
ALTER TABLE `product_tags`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `prod_extras`
--
ALTER TABLE `prod_extras`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `rates`
--
ALTER TABLE `rates`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `rate_list`
--
ALTER TABLE `rate_list`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `roles_permissions`
--
ALTER TABLE `roles_permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `roles_users`
--
ALTER TABLE `roles_users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `states`
--
ALTER TABLE `states`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de la tabla `transactions_history`
--
ALTER TABLE `transactions_history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `address`
--
ALTER TABLE `address`
  ADD CONSTRAINT `address_mun_id_foreign` FOREIGN KEY (`mun_id`) REFERENCES `municipios` (`id`),
  ADD CONSTRAINT `address_st_id_foreign` FOREIGN KEY (`st_id`) REFERENCES `states` (`id`);

--
-- Filtros para la tabla `admins`
--
ALTER TABLE `admins`
  ADD CONSTRAINT `admins_ad_rs_id_foreign` FOREIGN KEY (`ad_rs_id`) REFERENCES `roles_users` (`id`);

--
-- Filtros para la tabla `clients`
--
ALTER TABLE `clients`
  ADD CONSTRAINT `clients_cl_rs_id_foreign` FOREIGN KEY (`cl_rs_id`) REFERENCES `roles_users` (`id`);

--
-- Filtros para la tabla `clients_address`
--
ALTER TABLE `clients_address`
  ADD CONSTRAINT `clients_address_ca_address_id_foreign` FOREIGN KEY (`ca_address_id`) REFERENCES `address` (`id`),
  ADD CONSTRAINT `clients_address_ca_cl_id_foreign` FOREIGN KEY (`ca_cl_id`) REFERENCES `clients` (`id`);

--
-- Filtros para la tabla `delivery_man`
--
ALTER TABLE `delivery_man`
  ADD CONSTRAINT `delivery_man_dm_rs_id_foreign` FOREIGN KEY (`dm_rs_id`) REFERENCES `roles_users` (`id`);

--
-- Filtros para la tabla `municipios`
--
ALTER TABLE `municipios`
  ADD CONSTRAINT `municipios_states_id_foreign` FOREIGN KEY (`states_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ord_address_foreign` FOREIGN KEY (`ord_address`) REFERENCES `clients_address` (`id`),
  ADD CONSTRAINT `orders_ord_dm_id_foreign` FOREIGN KEY (`ord_dm_id`) REFERENCES `delivery_man` (`id`),
  ADD CONSTRAINT `orders_ord_extras_foreign` FOREIGN KEY (`ord_extras`) REFERENCES `prod_extras` (`id`),
  ADD CONSTRAINT `orders_ord_payment_id_foreign` FOREIGN KEY (`ord_payment_id`) REFERENCES `payments` (`id`),
  ADD CONSTRAINT `orders_ord_prod_id_foreign` FOREIGN KEY (`ord_prod_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `orders_ord_status_foreign` FOREIGN KEY (`ord_status`) REFERENCES `orders_status_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `partners`
--
ALTER TABLE `partners`
  ADD CONSTRAINT `partners_p_cat_id_foreign` FOREIGN KEY (`p_cat_id`) REFERENCES `categories` (`id`),
  ADD CONSTRAINT `partners_p_mun_id_foreign` FOREIGN KEY (`p_mun_id`) REFERENCES `municipios` (`id`),
  ADD CONSTRAINT `partners_p_rs_id_foreign` FOREIGN KEY (`p_rs_id`) REFERENCES `roles_users` (`id`);

--
-- Filtros para la tabla `partner_payments`
--
ALTER TABLE `partner_payments`
  ADD CONSTRAINT `partner_payments_partner_id_foreign` FOREIGN KEY (`partner_id`) REFERENCES `partners` (`id`),
  ADD CONSTRAINT `partner_payments_payment_id_foreign` FOREIGN KEY (`payment_id`) REFERENCES `payments` (`id`);

--
-- Filtros para la tabla `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payment_platform_id_fk` FOREIGN KEY (`pay_platform_id`) REFERENCES `payments_platforms` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `payment_type_id_fk` FOREIGN KEY (`pay_type`) REFERENCES `payment_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Filtros para la tabla `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_prod_partner_id_foreign` FOREIGN KEY (`prod_partner_id`) REFERENCES `partners` (`id`);

--
-- Filtros para la tabla `prod_extras`
--
ALTER TABLE `prod_extras`
  ADD CONSTRAINT `prod_extras_pe_partner_id_foreign` FOREIGN KEY (`pe_partner_id`) REFERENCES `partners` (`id`);

--
-- Filtros para la tabla `rate_list`
--
ALTER TABLE `rate_list`
  ADD CONSTRAINT `rate_list_rate_order_id_foreign` FOREIGN KEY (`rate_order_id`) REFERENCES `orders` (`id`);

--
-- Filtros para la tabla `roles_users`
--
ALTER TABLE `roles_users`
  ADD CONSTRAINT `roles_users_rs_perms_id_foreign` FOREIGN KEY (`rs_perms_id`) REFERENCES `roles_permissions` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

/*
Navicat MySQL Data Transfer

Source Server         : local_host
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : its_on_the_way

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2020-04-10 02:30:54
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ord_prod_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_prod_id` bigint(20) unsigned DEFAULT NULL,
  `ord_address` bigint(20) unsigned DEFAULT NULL,
  `ord_price_bs` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_price_usd` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_status` bigint(191) NOT NULL,
  `ord_extras` bigint(20) unsigned DEFAULT NULL,
  `ord_rate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ord_dm_id` bigint(20) unsigned DEFAULT NULL,
  `ord_dm_rate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ord_payment_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_ord_prod_id_foreign` (`ord_prod_id`),
  KEY `orders_ord_address_foreign` (`ord_address`),
  KEY `orders_ord_extras_foreign` (`ord_extras`),
  KEY `orders_ord_dm_id_foreign` (`ord_dm_id`),
  KEY `orders_ord_payment_id_foreign` (`ord_payment_id`),
  KEY `orders_ord_status_foreign` (`ord_status`),
  CONSTRAINT `orders_ord_address_foreign` FOREIGN KEY (`ord_address`) REFERENCES `clients_address` (`id`),
  CONSTRAINT `orders_ord_dm_id_foreign` FOREIGN KEY (`ord_dm_id`) REFERENCES `delivery_man` (`id`),
  CONSTRAINT `orders_ord_extras_foreign` FOREIGN KEY (`ord_extras`) REFERENCES `prod_extras` (`id`),
  CONSTRAINT `orders_ord_payment_id_foreign` FOREIGN KEY (`ord_payment_id`) REFERENCES `payments` (`id`),
  CONSTRAINT `orders_ord_prod_id_foreign` FOREIGN KEY (`ord_prod_id`) REFERENCES `products` (`id`),
  CONSTRAINT `orders_ord_status_foreign` FOREIGN KEY (`ord_status`) REFERENCES `orders_status_type` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

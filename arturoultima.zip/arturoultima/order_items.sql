/*
Navicat MySQL Data Transfer

Source Server         : local
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : itsonthe_way_test

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2020-06-22 21:47:47
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for order_items
-- ----------------------------
DROP TABLE IF EXISTS `order_items`;
CREATE TABLE `order_items` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ord_id` bigint(20) unsigned DEFAULT NULL,
  `prod_id` bigint(20) unsigned DEFAULT NULL,
  `extra_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_items_ord_id_foreign` (`ord_id`),
  KEY `order_items_prod_id_foreign` (`prod_id`),
  KEY `order_items_extra_id_foreign` (`extra_id`),
  CONSTRAINT `order_items_extra_id_foreign` FOREIGN KEY (`extra_id`) REFERENCES `prod_extras` (`id`),
  CONSTRAINT `order_items_ord_id_foreign` FOREIGN KEY (`ord_id`) REFERENCES `orders` (`id`),
  CONSTRAINT `order_items_prod_id_foreign` FOREIGN KEY (`prod_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of order_items
-- ----------------------------
INSERT INTO `order_items` VALUES ('1', '1', '1', '1', null, null, null);
INSERT INTO `order_items` VALUES ('2', '1', '3', '3', null, null, null);
INSERT INTO `order_items` VALUES ('3', '1', '4', '4', null, null, null);
INSERT INTO `order_items` VALUES ('4', '8', '5', '7', null, null, null);
INSERT INTO `order_items` VALUES ('5', '8', '6', '6', null, null, null);
INSERT INTO `order_items` VALUES ('6', '8', '7', '7', null, null, null);
INSERT INTO `order_items` VALUES ('7', '11', '3', '7', null, null, null);
INSERT INTO `order_items` VALUES ('8', '11', '8', '7', null, null, null);

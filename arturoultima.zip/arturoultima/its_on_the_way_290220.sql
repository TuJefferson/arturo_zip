/*
Navicat MySQL Data Transfer

Source Server         : local_host
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : its_on_the_way

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2020-02-29 15:46:39
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for address
-- ----------------------------
DROP TABLE IF EXISTS `address`;
CREATE TABLE `address` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `st_id` bigint(20) unsigned DEFAULT NULL,
  `mun_id` bigint(20) unsigned DEFAULT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `address_st_id_foreign` (`st_id`),
  KEY `address_mun_id_foreign` (`mun_id`),
  CONSTRAINT `address_mun_id_foreign` FOREIGN KEY (`mun_id`) REFERENCES `municipios` (`id`),
  CONSTRAINT `address_st_id_foreign` FOREIGN KEY (`st_id`) REFERENCES `states` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of address
-- ----------------------------
INSERT INTO `address` VALUES ('1', '3', '3', 'chachao', null, null, null);

-- ----------------------------
-- Table structure for admins
-- ----------------------------
DROP TABLE IF EXISTS `admins`;
CREATE TABLE `admins` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ad_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ad_last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ad_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ad_user_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ad_rs_id` bigint(20) unsigned DEFAULT NULL,
  `ad_intents` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ad_blocked` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ad_pass_exp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admins_ad_email_unique` (`ad_email`),
  UNIQUE KEY `admins_ad_user_name_unique` (`ad_user_name`),
  KEY `admins_ad_rs_id_foreign` (`ad_rs_id`),
  CONSTRAINT `admins_ad_rs_id_foreign` FOREIGN KEY (`ad_rs_id`) REFERENCES `roles_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of admins
-- ----------------------------
INSERT INTO `admins` VALUES ('1', 'gioan', 'robles', 'gioan2908@gmail.com', 'gioan', 'giomaris', null, null, null, null, null, null, null);

-- ----------------------------
-- Table structure for categories
-- ----------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of categories
-- ----------------------------
INSERT INTO `categories` VALUES ('1', 'bistro', null, null, null);
INSERT INTO `categories` VALUES ('2', 'restaurante', null, null, null);
INSERT INTO `categories` VALUES ('3', 'discoteta', null, null, null);

-- ----------------------------
-- Table structure for clients
-- ----------------------------
DROP TABLE IF EXISTS `clients`;
CREATE TABLE `clients` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cl_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_user` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_dni` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_phone_1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_phone_2` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_rs_id` bigint(20) unsigned DEFAULT NULL,
  `cl_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_verified` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_intents` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_blocked` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cl_pass_exp` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `clients_cl_user_unique` (`cl_user`),
  UNIQUE KEY `clients_cl_email_unique` (`cl_email`),
  KEY `clients_cl_rs_id_foreign` (`cl_rs_id`),
  CONSTRAINT `clients_cl_rs_id_foreign` FOREIGN KEY (`cl_rs_id`) REFERENCES `roles_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of clients
-- ----------------------------
INSERT INTO `clients` VALUES ('1', 'jose ', 'rob les', 'jorserb', 'V25416060', '0414394445', '02856312829', '3', 'gioan9080@gmail.com', '', 'giomaris', '', '', '', null, null, null, null);

-- ----------------------------
-- Table structure for clients_address
-- ----------------------------
DROP TABLE IF EXISTS `clients_address`;
CREATE TABLE `clients_address` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ca_cl_id` bigint(20) unsigned DEFAULT NULL,
  `ca_address_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `clients_address_ca_cl_id_foreign` (`ca_cl_id`),
  KEY `clients_address_ca_address_id_foreign` (`ca_address_id`),
  CONSTRAINT `clients_address_ca_address_id_foreign` FOREIGN KEY (`ca_address_id`) REFERENCES `address` (`id`),
  CONSTRAINT `clients_address_ca_cl_id_foreign` FOREIGN KEY (`ca_cl_id`) REFERENCES `clients` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of clients_address
-- ----------------------------
INSERT INTO `clients_address` VALUES ('1', '1', '1', null, null, null);

-- ----------------------------
-- Table structure for curriencies
-- ----------------------------
DROP TABLE IF EXISTS `curriencies`;
CREATE TABLE `curriencies` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `cur_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cur_value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of curriencies
-- ----------------------------

-- ----------------------------
-- Table structure for delivery_man
-- ----------------------------
DROP TABLE IF EXISTS `delivery_man`;
CREATE TABLE `delivery_man` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `dm_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_user` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_phone_1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_phone_2` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dm_rs_id` bigint(20) unsigned DEFAULT NULL,
  `dm_partner_id` bigint(20) unsigned DEFAULT NULL,
  `dm_rate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dm_intents` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dm_blocked` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `dm_pass_exp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `delivery_man_dm_user_unique` (`dm_user`),
  UNIQUE KEY `delivery_man_dm_email_unique` (`dm_email`),
  KEY `delivery_man_dm_rs_id_foreign` (`dm_rs_id`),
  KEY `delivery_man_dm_partner_id_foreign` (`dm_partner_id`),
  CONSTRAINT `delivery_man_dm_partner_id_foreign` FOREIGN KEY (`dm_partner_id`) REFERENCES `partners` (`id`),
  CONSTRAINT `delivery_man_dm_rs_id_foreign` FOREIGN KEY (`dm_rs_id`) REFERENCES `roles_users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of delivery_man
-- ----------------------------
INSERT INTO `delivery_man` VALUES ('1', 'Holly Ramirez', 'Cummings', 'Cupiditate sint iur', 'cazyjilufe@mailinator.net', '$2y$10$mCXES.PB8udeaQ6tXN554.hXnx29wmzJCdK6cHjb3vqsXJQuq6T0S', '+1 (819) 958-9115', '+1 (535) 426-1781', null, '1', null, null, null, null, null, '2020-02-28 18:42:27', '2020-02-28 18:42:27', null);

-- ----------------------------
-- Table structure for migrations
-- ----------------------------
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of migrations
-- ----------------------------
INSERT INTO `migrations` VALUES ('1', '2010_02_15_173332_roles_permissions', '1');
INSERT INTO `migrations` VALUES ('2', '2010_03_15_173530_roles_users', '1');
INSERT INTO `migrations` VALUES ('3', '2010_12_14_152344_states', '1');
INSERT INTO `migrations` VALUES ('4', '2010_12_14_152345_municipios', '1');
INSERT INTO `migrations` VALUES ('5', '2010_12_14_152346_address', '1');
INSERT INTO `migrations` VALUES ('6', '2010_12_14_153708_admins', '1');
INSERT INTO `migrations` VALUES ('7', '2010_12_15_155728_categories', '1');
INSERT INTO `migrations` VALUES ('8', '2010_12_15_160800_currencies', '1');
INSERT INTO `migrations` VALUES ('9', '2013_02_14_152612_partners', '1');
INSERT INTO `migrations` VALUES ('10', '2013_02_14_152637_delivery_man', '1');
INSERT INTO `migrations` VALUES ('11', '2014_10_12_000000_create_clients_table', '1');
INSERT INTO `migrations` VALUES ('12', '2014_10_12_000000_create_users_table', '1');
INSERT INTO `migrations` VALUES ('13', '2014_10_12_100000_create_password_resets_table', '1');
INSERT INTO `migrations` VALUES ('14', '2015_01_14_152445_clients_address', '1');
INSERT INTO `migrations` VALUES ('15', '2020_02_14_152501_products', '1');
INSERT INTO `migrations` VALUES ('16', '2020_02_14_152652_prod_extras', '1');
INSERT INTO `migrations` VALUES ('17', '2020_02_14_152653_rates', '1');
INSERT INTO `migrations` VALUES ('18', '2020_02_14_152716_orders', '1');
INSERT INTO `migrations` VALUES ('19', '2020_02_14_152804_rate_list', '1');

-- ----------------------------
-- Table structure for municipios
-- ----------------------------
DROP TABLE IF EXISTS `municipios`;
CREATE TABLE `municipios` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `states_id` bigint(20) unsigned NOT NULL,
  `mun_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `municipios_states_id_foreign` (`states_id`),
  CONSTRAINT `municipios_states_id_foreign` FOREIGN KEY (`states_id`) REFERENCES `states` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=683 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of municipios
-- ----------------------------
INSERT INTO `municipios` VALUES ('3', '1', 'Alto Orinoco', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('4', '1', 'Atabapo', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('5', '1', 'Atures', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('6', '1', 'Autana', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('7', '1', 'Manapiare', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('8', '1', 'Maroa', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('9', '1', 'Río Negro', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('10', '2', 'Anaco', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('11', '2', 'Aragua', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('12', '2', 'Manuel Ezequiel Bruzual', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('13', '2', 'Diego Bautista Urbaneja', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('14', '2', 'Fernando Peñalver', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('15', '2', 'Francisco Del Carmen Carvajal', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('16', '2', 'General Sir Arthur McGregor', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('17', '2', 'Guanta', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('18', '2', 'Independencia', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('19', '2', 'José Gregorio Monagas', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('20', '2', 'Juan Antonio Sotillo', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('21', '2', 'Juan Manuel Cajigal', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('22', '2', 'Libertad', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('23', '2', 'Francisco de Miranda', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('24', '2', 'Pedro María Freites', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('25', '2', 'Píritu', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('26', '2', 'San José de Guanipa', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('27', '2', 'San Juan de Capistrano', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('28', '2', 'Santa Ana', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('29', '2', 'Simón Bolívar', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('30', '2', 'Simón Rodríguez', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('31', '3', 'Achaguas', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('32', '3', 'Biruaca', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('33', '3', 'Muñóz', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('34', '3', 'Páez', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('35', '3', 'Pedro Camejo', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('36', '3', 'Rómulo Gallegos', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('37', '3', 'San Fernando', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('38', '4', 'Atanasio Girardot', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('39', '4', 'Bolívar', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('40', '4', 'Camatagua', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('41', '4', 'Francisco Linares Alcántara', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('42', '4', 'José Ángel Lamas', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('43', '4', 'José Félix Ribas', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('44', '4', 'José Rafael Revenga', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('45', '4', 'Libertador', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('46', '4', 'Mario Briceño Iragorry', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('47', '4', 'Ocumare de la Costa de Oro', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('48', '4', 'San Casimiro', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('49', '4', 'San Sebastián', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('50', '4', 'Santiago Mariño', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('51', '4', 'Santos Michelena', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('52', '4', 'Sucre', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('53', '4', 'Tovar', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('54', '4', 'Urdaneta', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('55', '4', 'Zamora', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('56', '5', 'Alberto Arvelo Torrealba', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('57', '5', 'Andrés Eloy Blanco', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('58', '5', 'Antonio José de Sucre', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('59', '5', 'Arismendi', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('60', '5', 'Barinas', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('61', '5', 'Bolívar', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('62', '5', 'Cruz Paredes', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('63', '5', 'Ezequiel Zamora', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('64', '5', 'Obispos', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('65', '5', 'Pedraza', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('66', '5', 'Rojas', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('67', '5', 'Sosa', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('68', '6', 'Caroní', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('69', '6', 'Cedeño', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('70', '6', 'El Callao', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('71', '6', 'Gran Sabana', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('72', '6', 'Heres', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('73', '6', 'Piar', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('74', '6', 'Angostura (Raúl Leoni)', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('75', '6', 'Roscio', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('76', '6', 'Sifontes', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('77', '6', 'Sucre', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('78', '6', 'Padre Pedro Chien', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('79', '7', 'Bejuma', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('80', '7', 'Carlos Arvelo', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('81', '7', 'Diego Ibarra', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('82', '7', 'Guacara', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('83', '7', 'Juan José Mora', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('84', '7', 'Libertador', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('85', '7', 'Los Guayos', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('86', '7', 'Miranda', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('87', '7', 'Montalbán', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('88', '7', 'Naguanagua', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('89', '7', 'Puerto Cabello', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('90', '7', 'San Diego', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('91', '7', 'San Joaquín', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('92', '7', 'Valencia', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('93', '8', 'Anzoátegui', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('94', '8', 'Tinaquillo', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('95', '8', 'Girardot', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('96', '8', 'Lima Blanco', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('97', '8', 'Pao de San Juan Bautista', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('98', '8', 'Ricaurte', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('99', '8', 'Rómulo Gallegos', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('100', '8', 'San Carlos', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('101', '8', 'Tinaco', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('102', '9', 'Antonio Díaz', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('103', '9', 'Casacoima', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('104', '9', 'Pedernales', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('105', '9', 'Tucupita', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('106', '10', 'Acosta', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('107', '10', 'Bolívar', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('108', '10', 'Buchivacoa', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('109', '10', 'Cacique Manaure', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('110', '10', 'Carirubana', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('111', '10', 'Colina', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('112', '10', 'Dabajuro', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('113', '10', 'Democracia', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('114', '10', 'Falcón', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('115', '10', 'Federación', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('116', '10', 'Jacura', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('117', '10', 'José Laurencio Silva', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('118', '10', 'Los Taques', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('119', '10', 'Mauroa', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('120', '10', 'Miranda', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('121', '10', 'Monseñor Iturriza', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('122', '10', 'Palmasola', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('123', '10', 'Petit', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('124', '10', 'Píritu', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('125', '10', 'San Francisco', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('126', '10', 'Sucre', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('127', '10', 'Tocópero', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('128', '10', 'Unión', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('129', '10', 'Urumaco', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('130', '10', 'Zamora', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('131', '11', 'Camaguán', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('132', '11', 'Chaguaramas', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('133', '11', 'El Socorro', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('134', '11', 'José Félix Ribas', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('135', '11', 'José Tadeo Monagas', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('136', '11', 'Juan Germán Roscio', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('137', '11', 'Julián Mellado', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('138', '11', 'Las Mercedes', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('139', '11', 'Leonardo Infante', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('140', '11', 'Pedro Zaraza', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('141', '11', 'Ortíz', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('142', '11', 'San Gerónimo de Guayabal', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('143', '11', 'San José de Guaribe', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('144', '11', 'Santa María de Ipire', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('145', '11', 'Sebastián Francisco de Miranda', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('146', '12', 'Andrés Eloy Blanco', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('147', '12', 'Crespo', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('148', '12', 'Iribarren', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('149', '12', 'Jiménez', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('150', '12', 'Morán', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('151', '12', 'Palavecino', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('152', '12', 'Simón Planas', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('153', '12', 'Torres', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('154', '12', 'Urdaneta', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('155', '13', 'Alberto Adriani', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('156', '13', 'Andrés Bello', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('157', '13', 'Antonio Pinto Salinas', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('158', '13', 'Aricagua', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('159', '13', 'Arzobispo Chacón', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('160', '13', 'Campo Elías', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('161', '13', 'Caracciolo Parra Olmedo', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('162', '13', 'Cardenal Quintero', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('163', '13', 'Guaraque', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('164', '13', 'Julio César Salas', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('165', '13', 'Justo Briceño', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('166', '13', 'Libertador', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('167', '13', 'Miranda', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('168', '13', 'Obispo Ramos de Lora', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('169', '13', 'Padre Noguera', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('170', '13', 'Pueblo Llano', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('171', '13', 'Rangel', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('172', '13', 'Rivas Dávila', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('173', '13', 'Santos Marquina', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('174', '13', 'Sucre', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('175', '13', 'Tovar', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('176', '13', 'Tulio Febres Cordero', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('177', '13', 'Zea', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('178', '14', 'Acevedo', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('179', '14', 'Andrés Bello', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('180', '14', 'Baruta', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('181', '14', 'Brión', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('182', '14', 'Buroz', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('183', '14', 'Carrizal', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('184', '14', 'Chacao', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('185', '14', 'Cristóbal Rojas', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('186', '14', 'El Hatillo', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('187', '14', 'Guaicaipuro', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('188', '14', 'Independencia', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('189', '14', 'Lander', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('190', '14', 'Los Salias', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('191', '14', 'Páez', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('192', '14', 'Paz Castillo', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('193', '14', 'Pedro Gual', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('194', '14', 'Plaza', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('195', '14', 'Simón Bolívar', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('196', '14', 'Sucre', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('197', '14', 'Urdaneta', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('198', '14', 'Zamora', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('199', '15', 'Acosta', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('200', '15', 'Aguasay', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('201', '15', 'Bolívar', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('202', '15', 'Caripe', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('203', '15', 'Cedeño', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('204', '15', 'Ezequiel Zamora', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('205', '15', 'Libertador', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('206', '15', 'Maturín', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('207', '15', 'Piar', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('208', '15', 'Punceres', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('209', '15', 'Santa Bárbara', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('210', '15', 'Sotillo', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('211', '15', 'Uracoa', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('212', '16', 'Antolin del Campo', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('213', '16', 'Arismendi', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('214', '16', 'García', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('215', '16', 'Gómez', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('216', '16', 'Maneiro', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('217', '16', 'Marcano', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('218', '16', 'Mariño', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('219', '16', 'Península de Macanao', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('220', '16', 'Tubores', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('221', '16', 'Villalba', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('222', '16', 'Díaz', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('223', '17', 'Agua Blanca', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('224', '17', 'Araure', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('225', '17', 'Esteller', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('226', '17', 'Guanare', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('227', '17', 'Guanarito', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('228', '17', 'Monseñor José Vicente de Unda', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('229', '17', 'Ospino', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('230', '17', 'Páez', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('231', '17', 'Papelón', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('232', '17', 'San Genaro de Boconoíto', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('233', '17', 'San Rafael de Onoto', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('234', '17', 'Santa Rosalía', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('235', '17', 'Sucre', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('236', '17', 'Turén', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('237', '18', 'Andrés Eloy Blanco', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('238', '18', 'Andrés Mata', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('239', '18', 'Arismendi', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('240', '18', 'Benítez', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('241', '18', 'Bermúdez', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('242', '18', 'Bolívar', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('243', '18', 'Cajigal', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('244', '18', 'Cruz Salmerón Acosta', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('245', '18', 'Libertador', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('246', '18', 'Mariño', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('247', '18', 'Mejía', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('248', '18', 'Montes', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('249', '18', 'Ribero', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('250', '18', 'Sucre', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('251', '18', 'Valdéz', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('252', '19', 'Andrés Bello', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('253', '19', 'Antonio Rómulo Costa', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('254', '19', 'Ayacucho', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('255', '19', 'Bolívar', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('256', '19', 'Cárdenas', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('257', '19', 'Córdoba', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('258', '19', 'Fernández Feo', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('259', '19', 'Francisco de Miranda', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('260', '19', 'García de Hevia', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('261', '19', 'Guásimos', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('262', '19', 'Independencia', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('263', '19', 'Jáuregui', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('264', '19', 'José María Vargas', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('265', '19', 'Junín', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('266', '19', 'Libertad', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('267', '19', 'Libertador', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('268', '19', 'Lobatera', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('269', '19', 'Michelena', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('270', '19', 'Panamericano', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('271', '19', 'Pedro María Ureña', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('272', '19', 'Rafael Urdaneta', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('273', '19', 'Samuel Darío Maldonado', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('274', '19', 'San Cristóbal', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('275', '19', 'Seboruco', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('276', '19', 'Simón Rodríguez', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('277', '19', 'Sucre', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('278', '19', 'Torbes', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('279', '19', 'Uribante', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('280', '19', 'San Judas Tadeo', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('281', '20', 'Andrés Bello', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('282', '20', 'Boconó', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('283', '20', 'Bolívar', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('284', '20', 'Candelaria', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('285', '20', 'Carache', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('286', '20', 'Escuque', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('287', '20', 'José Felipe Márquez Cañizalez', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('288', '20', 'Juan Vicente Campos Elías', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('289', '20', 'La Ceiba', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('290', '20', 'Miranda', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('291', '20', 'Monte Carmelo', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('292', '20', 'Motatán', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('293', '20', 'Pampán', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('294', '20', 'Pampanito', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('295', '20', 'Rafael Rangel', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('296', '20', 'San Rafael de Carvajal', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('297', '20', 'Sucre', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('298', '20', 'Trujillo', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('299', '20', 'Urdaneta', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('300', '20', 'Valera', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('301', '21', 'Vargas', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('302', '22', 'Arístides Bastidas', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('303', '22', 'Bolívar', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('304', '22', 'Bruzual', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('305', '22', 'Cocorote', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('306', '22', 'Independencia', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('307', '22', 'José Antonio Páez', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('308', '22', 'La Trinidad', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('309', '22', 'Manuel Monge', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('310', '22', 'Nirgua', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('311', '22', 'Peña', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('312', '22', 'San Felipe', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('313', '22', 'Sucre', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('314', '22', 'Urachiche', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('315', '22', 'José Joaquín Veroes', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('316', '23', 'Almirante Padilla', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('317', '23', 'Baralt', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('318', '23', 'Cabimas', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('319', '23', 'Catatumbo', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('320', '23', 'Colón', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('321', '23', 'Francisco Javier Pulgar', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('322', '23', 'Páez', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('323', '23', 'Jesús Enrique Losada', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('324', '23', 'Jesús María Semprún', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('325', '23', 'La Cañada de Urdaneta', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('326', '23', 'Lagunillas', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('327', '23', 'Machiques de Perijá', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('328', '23', 'Mara', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('329', '23', 'Maracaibo', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('330', '23', 'Miranda', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('331', '23', 'Rosario de Perijá', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('332', '23', 'San Francisco', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('333', '23', 'Santa Rita', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('334', '23', 'Simón Bolívar', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('335', '23', 'Sucre', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('336', '23', 'Valmore Rodríguez', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('337', '24', 'Libertador', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `municipios` VALUES ('338', '1', 'Alto Orinoco', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('339', '1', 'Atabapo', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('340', '1', 'Atures', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('341', '1', 'Autana', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('342', '1', 'Manapiare', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('343', '1', 'Maroa', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('344', '1', 'Río Negro', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('345', '2', 'Anaco', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('346', '2', 'Aragua', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('347', '2', 'Manuel Ezequiel Bruzual', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('348', '2', 'Diego Bautista Urbaneja', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('349', '2', 'Fernando Peñalver', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('350', '2', 'Francisco Del Carmen Carvajal', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('351', '2', 'General Sir Arthur McGregor', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('352', '2', 'Guanta', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('353', '2', 'Independencia', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('354', '2', 'José Gregorio Monagas', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('355', '2', 'Juan Antonio Sotillo', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('356', '2', 'Juan Manuel Cajigal', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('357', '2', 'Libertad', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('358', '2', 'Francisco de Miranda', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('359', '2', 'Pedro María Freites', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('360', '2', 'Píritu', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('361', '2', 'San José de Guanipa', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('362', '2', 'San Juan de Capistrano', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('363', '2', 'Santa Ana', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('364', '2', 'Simón Bolívar', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('365', '2', 'Simón Rodríguez', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('366', '3', 'Achaguas', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('367', '3', 'Biruaca', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('368', '3', 'Muñóz', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('369', '3', 'Páez', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('370', '3', 'Pedro Camejo', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('371', '3', 'Rómulo Gallegos', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('372', '3', 'San Fernando', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('373', '4', 'Atanasio Girardot', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('374', '4', 'Bolívar', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('375', '4', 'Camatagua', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('376', '4', 'Francisco Linares Alcántara', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('377', '4', 'José Ángel Lamas', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('378', '4', 'José Félix Ribas', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('379', '4', 'José Rafael Revenga', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('380', '4', 'Libertador', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('381', '4', 'Mario Briceño Iragorry', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('382', '4', 'Ocumare de la Costa de Oro', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('383', '4', 'San Casimiro', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('384', '4', 'San Sebastián', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('385', '4', 'Santiago Mariño', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('386', '4', 'Santos Michelena', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('387', '4', 'Sucre', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('388', '4', 'Tovar', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('389', '4', 'Urdaneta', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('390', '4', 'Zamora', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('391', '5', 'Alberto Arvelo Torrealba', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('392', '5', 'Andrés Eloy Blanco', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('393', '5', 'Antonio José de Sucre', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('394', '5', 'Arismendi', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('395', '5', 'Barinas', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('396', '5', 'Bolívar', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('397', '5', 'Cruz Paredes', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('398', '5', 'Ezequiel Zamora', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('399', '5', 'Obispos', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('400', '5', 'Pedraza', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('401', '5', 'Rojas', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('402', '5', 'Sosa', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('403', '6', 'Caroní', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('404', '6', 'Cedeño', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('405', '6', 'El Callao', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('406', '6', 'Gran Sabana', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('407', '6', 'Heres', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('408', '6', 'Piar', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('409', '6', 'Angostura (Raúl Leoni)', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('410', '6', 'Roscio', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('411', '6', 'Sifontes', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('412', '6', 'Sucre', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('413', '6', 'Padre Pedro Chien', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('414', '7', 'Bejuma', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('415', '7', 'Carlos Arvelo', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('416', '7', 'Diego Ibarra', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('417', '7', 'Guacara', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('418', '7', 'Juan José Mora', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('419', '7', 'Libertador', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('420', '7', 'Los Guayos', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('421', '7', 'Miranda', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('422', '7', 'Montalbán', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('423', '7', 'Naguanagua', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('424', '7', 'Puerto Cabello', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('425', '7', 'San Diego', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('426', '7', 'San Joaquín', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('427', '7', 'Valencia', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('428', '8', 'Anzoátegui', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('429', '8', 'Tinaquillo', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('430', '8', 'Girardot', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('431', '8', 'Lima Blanco', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('432', '8', 'Pao de San Juan Bautista', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('433', '8', 'Ricaurte', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('434', '8', 'Rómulo Gallegos', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('435', '8', 'San Carlos', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('436', '8', 'Tinaco', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('437', '9', 'Antonio Díaz', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('438', '9', 'Casacoima', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('439', '9', 'Pedernales', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('440', '9', 'Tucupita', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('441', '10', 'Acosta', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('442', '10', 'Bolívar', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('443', '10', 'Buchivacoa', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('444', '10', 'Cacique Manaure', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('445', '10', 'Carirubana', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('446', '10', 'Colina', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('447', '10', 'Dabajuro', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('448', '10', 'Democracia', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('449', '10', 'Falcón', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('450', '10', 'Federación', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('451', '10', 'Jacura', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('452', '10', 'José Laurencio Silva', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('453', '10', 'Los Taques', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('454', '10', 'Mauroa', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('455', '10', 'Miranda', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('456', '10', 'Monseñor Iturriza', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('457', '10', 'Palmasola', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('458', '10', 'Petit', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('459', '10', 'Píritu', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('460', '10', 'San Francisco', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('461', '10', 'Sucre', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('462', '10', 'Tocópero', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('463', '10', 'Unión', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('464', '10', 'Urumaco', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('465', '10', 'Zamora', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('466', '11', 'Camaguán', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('467', '11', 'Chaguaramas', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('468', '11', 'El Socorro', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('469', '11', 'José Félix Ribas', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('470', '11', 'José Tadeo Monagas', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('471', '11', 'Juan Germán Roscio', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('472', '11', 'Julián Mellado', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('473', '11', 'Las Mercedes', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('474', '11', 'Leonardo Infante', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('475', '11', 'Pedro Zaraza', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('476', '11', 'Ortíz', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('477', '11', 'San Gerónimo de Guayabal', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('478', '11', 'San José de Guaribe', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('479', '11', 'Santa María de Ipire', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('480', '11', 'Sebastián Francisco de Miranda', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('481', '12', 'Andrés Eloy Blanco', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('482', '12', 'Crespo', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('483', '12', 'Iribarren', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('484', '12', 'Jiménez', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('485', '12', 'Morán', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('486', '12', 'Palavecino', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('487', '12', 'Simón Planas', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('488', '12', 'Torres', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('489', '12', 'Urdaneta', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('490', '13', 'Alberto Adriani', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('491', '13', 'Andrés Bello', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('492', '13', 'Antonio Pinto Salinas', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('493', '13', 'Aricagua', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('494', '13', 'Arzobispo Chacón', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('495', '13', 'Campo Elías', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('496', '13', 'Caracciolo Parra Olmedo', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('497', '13', 'Cardenal Quintero', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('498', '13', 'Guaraque', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('499', '13', 'Julio César Salas', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('500', '13', 'Justo Briceño', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('501', '13', 'Libertador', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('502', '13', 'Miranda', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('503', '13', 'Obispo Ramos de Lora', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('504', '13', 'Padre Noguera', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('505', '13', 'Pueblo Llano', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('506', '13', 'Rangel', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('507', '13', 'Rivas Dávila', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('508', '13', 'Santos Marquina', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('509', '13', 'Sucre', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('510', '13', 'Tovar', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('511', '13', 'Tulio Febres Cordero', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('512', '13', 'Zea', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('513', '14', 'Acevedo', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('514', '14', 'Andrés Bello', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('515', '14', 'Baruta', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('516', '14', 'Brión', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('517', '14', 'Buroz', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('518', '14', 'Carrizal', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('519', '14', 'Chacao', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('520', '14', 'Cristóbal Rojas', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('521', '14', 'El Hatillo', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('522', '14', 'Guaicaipuro', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('523', '14', 'Independencia', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('524', '14', 'Lander', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('525', '14', 'Los Salias', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('526', '14', 'Páez', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('527', '14', 'Paz Castillo', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('528', '14', 'Pedro Gual', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('529', '14', 'Plaza', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('530', '14', 'Simón Bolívar', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('531', '14', 'Sucre', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('532', '14', 'Urdaneta', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('533', '14', 'Zamora', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('534', '15', 'Acosta', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('535', '15', 'Aguasay', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('536', '15', 'Bolívar', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('537', '15', 'Caripe', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('538', '15', 'Cedeño', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('539', '15', 'Ezequiel Zamora', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('540', '15', 'Libertador', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('541', '15', 'Maturín', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('542', '15', 'Piar', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('543', '15', 'Punceres', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('544', '15', 'Santa Bárbara', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('545', '15', 'Sotillo', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('546', '15', 'Uracoa', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('547', '16', 'Antolin del Campo', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('548', '16', 'Arismendi', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('549', '16', 'García', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('550', '16', 'Gómez', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('551', '16', 'Maneiro', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('552', '16', 'Marcano', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('553', '16', 'Mariño', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('554', '16', 'Península de Macanao', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('555', '16', 'Tubores', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('556', '16', 'Villalba', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('557', '16', 'Díaz', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('558', '17', 'Agua Blanca', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('559', '17', 'Araure', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('560', '17', 'Esteller', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('561', '17', 'Guanare', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('562', '17', 'Guanarito', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('563', '17', 'Monseñor José Vicente de Unda', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('564', '17', 'Ospino', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('565', '17', 'Páez', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('566', '17', 'Papelón', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('567', '17', 'San Genaro de Boconoíto', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('568', '17', 'San Rafael de Onoto', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('569', '17', 'Santa Rosalía', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('570', '17', 'Sucre', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('571', '17', 'Turén', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('572', '18', 'Andrés Eloy Blanco', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('573', '18', 'Andrés Mata', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('574', '18', 'Arismendi', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('575', '18', 'Benítez', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('576', '18', 'Bermúdez', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('577', '18', 'Bolívar', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('578', '18', 'Cajigal', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('579', '18', 'Cruz Salmerón Acosta', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('580', '18', 'Libertador', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('581', '18', 'Mariño', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('582', '18', 'Mejía', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('583', '18', 'Montes', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('584', '18', 'Ribero', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('585', '18', 'Sucre', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('586', '18', 'Valdéz', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('587', '19', 'Andrés Bello', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('588', '19', 'Antonio Rómulo Costa', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('589', '19', 'Ayacucho', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('590', '19', 'Bolívar', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('591', '19', 'Cárdenas', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('592', '19', 'Córdoba', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('593', '19', 'Fernández Feo', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('594', '19', 'Francisco de Miranda', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('595', '19', 'García de Hevia', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('596', '19', 'Guásimos', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('597', '19', 'Independencia', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('598', '19', 'Jáuregui', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('599', '19', 'José María Vargas', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('600', '19', 'Junín', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('601', '19', 'Libertad', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('602', '19', 'Libertador', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('603', '19', 'Lobatera', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('604', '19', 'Michelena', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('605', '19', 'Panamericano', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('606', '19', 'Pedro María Ureña', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('607', '19', 'Rafael Urdaneta', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('608', '19', 'Samuel Darío Maldonado', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('609', '19', 'San Cristóbal', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('610', '19', 'Seboruco', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('611', '19', 'Simón Rodríguez', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('612', '19', 'Sucre', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('613', '19', 'Torbes', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('614', '19', 'Uribante', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('615', '19', 'San Judas Tadeo', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('616', '20', 'Andrés Bello', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('617', '20', 'Boconó', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('618', '20', 'Bolívar', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('619', '20', 'Candelaria', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('620', '20', 'Carache', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('621', '20', 'Escuque', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('622', '20', 'José Felipe Márquez Cañizalez', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('623', '20', 'Juan Vicente Campos Elías', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('624', '20', 'La Ceiba', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('625', '20', 'Miranda', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('626', '20', 'Monte Carmelo', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('627', '20', 'Motatán', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('628', '20', 'Pampán', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('629', '20', 'Pampanito', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('630', '20', 'Rafael Rangel', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('631', '20', 'San Rafael de Carvajal', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('632', '20', 'Sucre', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('633', '20', 'Trujillo', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('634', '20', 'Urdaneta', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('635', '20', 'Valera', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('636', '21', 'Vargas', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('637', '22', 'Arístides Bastidas', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('638', '22', 'Bolívar', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('639', '22', 'Bruzual', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('640', '22', 'Cocorote', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('641', '22', 'Independencia', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('642', '22', 'José Antonio Páez', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('643', '22', 'La Trinidad', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('644', '22', 'Manuel Monge', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('645', '22', 'Nirgua', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('646', '22', 'Peña', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('647', '22', 'San Felipe', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('648', '22', 'Sucre', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('649', '22', 'Urachiche', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('650', '22', 'José Joaquín Veroes', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('651', '23', 'Almirante Padilla', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('652', '23', 'Baralt', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('653', '23', 'Cabimas', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('654', '23', 'Catatumbo', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('655', '23', 'Colón', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('656', '23', 'Francisco Javier Pulgar', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('657', '23', 'Páez', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('658', '23', 'Jesús Enrique Losada', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('659', '23', 'Jesús María Semprún', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('660', '23', 'La Cañada de Urdaneta', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('661', '23', 'Lagunillas', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('662', '23', 'Machiques de Perijá', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('663', '23', 'Mara', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('664', '23', 'Maracaibo', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('665', '23', 'Miranda', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('666', '23', 'Rosario de Perijá', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('667', '23', 'San Francisco', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('668', '23', 'Santa Rita', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('669', '23', 'Simón Bolívar', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('670', '23', 'Sucre', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('671', '23', 'Valmore Rodríguez', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `municipios` VALUES ('672', '24', 'Libertador', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ord_prod_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_prod_id` bigint(20) unsigned DEFAULT NULL,
  `ord_address` bigint(20) unsigned DEFAULT NULL,
  `ord_price_bs` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_price_usd` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_extras` bigint(20) unsigned DEFAULT NULL,
  `ord_dm_id` bigint(20) DEFAULT NULL,
  `ord_rate` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ord_dm_rate` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orders_ord_prod_id_foreign` (`ord_prod_id`),
  KEY `orders_ord_address_foreign` (`ord_address`),
  KEY `orders_ord_extras_foreign` (`ord_extras`),
  CONSTRAINT `orders_ord_address_foreign` FOREIGN KEY (`ord_address`) REFERENCES `clients_address` (`id`),
  CONSTRAINT `orders_ord_extras_foreign` FOREIGN KEY (`ord_extras`) REFERENCES `prod_extras` (`id`),
  CONSTRAINT `orders_ord_prod_id_foreign` FOREIGN KEY (`ord_prod_id`) REFERENCES `products` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES ('1', 'asdasd', '1', '1', '54', '524', 'asdfasdasd', 'a', '1', '1', '', '', null, null, null);

-- ----------------------------
-- Table structure for partners
-- ----------------------------
DROP TABLE IF EXISTS `partners`;
CREATE TABLE `partners` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `p_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_user` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_phone_1` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_phone_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_rs_id` bigint(20) unsigned DEFAULT NULL,
  `p_st_id` bigint(20) unsigned DEFAULT NULL,
  `p_adrress` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `p_cat_id` bigint(20) unsigned DEFAULT NULL,
  `p_intents` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_blocked` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_pass_exp` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_rate` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `p_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `p_mun_id` bigint(20) DEFAULT NULL,
  `p_open_time` time DEFAULT NULL,
  `p_close_time` time DEFAULT NULL,
  `p_shipping` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `partners_p_user_unique` (`p_user`),
  UNIQUE KEY `partners_p_email_unique` (`p_email`),
  KEY `partners_p_rs_id_foreign` (`p_rs_id`),
  KEY `partners_p_st_id_foreign` (`p_st_id`),
  KEY `partners_p_cat_id_foreign` (`p_cat_id`),
  CONSTRAINT `partners_p_cat_id_foreign` FOREIGN KEY (`p_cat_id`) REFERENCES `categories` (`id`),
  CONSTRAINT `partners_p_rs_id_foreign` FOREIGN KEY (`p_rs_id`) REFERENCES `roles_users` (`id`),
  CONSTRAINT `partners_p_st_id_foreign` FOREIGN KEY (`p_st_id`) REFERENCES `states` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of partners
-- ----------------------------
INSERT INTO `partners` VALUES ('1', 'Jerry Gomez', 'Harrison', 'Optio officiis eos', 'wypytojavi@mailinator.com', '+1 (613) 978-4408', '+1 (587) 285-8257', '$2y$10$qkEw6jLh2a5blKm58N/p/u/o1VFALe9N26UHl6j/C3UVFV3vyCUEi', '2', '11', 'Cum ut cupiditate an', '2', null, null, null, null, 'Non quas voluptatum asdasdasdsad', null, '2020-02-28 17:17:47', '2020-02-28 17:17:47', null, '1', '02:04:00', '14:18:00', null);
INSERT INTO `partners` VALUES ('2', 'asdadsa', 'asdasd', 'gggg', 'asdasd@gmail.com', '4143944752', '4143944752', 'giomaris', '3', '9', 'asdasd', '3', null, null, null, null, 'asdadasdasdasd', null, null, null, null, '1', '02:04:00', '21:08:00', null);

-- ----------------------------
-- Table structure for password_resets
-- ----------------------------
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of password_resets
-- ----------------------------

-- ----------------------------
-- Table structure for products
-- ----------------------------
DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `prod_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prod_partner_id` bigint(20) unsigned DEFAULT NULL,
  `prod_price_bs` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prod_price_usd` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `prod_description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `products_prod_partner_id_foreign` (`prod_partner_id`),
  CONSTRAINT `products_prod_partner_id_foreign` FOREIGN KEY (`prod_partner_id`) REFERENCES `partners` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of products
-- ----------------------------
INSERT INTO `products` VALUES ('1', 'pizza', '1', '80', '2', 'pizza riquisima', null, null, null);
INSERT INTO `products` VALUES ('2', 'perros', '1', '45', '45', 'perros brutales', null, null, null);
INSERT INTO `products` VALUES ('3', 'pasta', '2', '11', '1', 'ástraaasd', null, null, null);

-- ----------------------------
-- Table structure for prod_extras
-- ----------------------------
DROP TABLE IF EXISTS `prod_extras`;
CREATE TABLE `prod_extras` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `pe_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pe_price_bs` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pe_price_usd` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pe_partner_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prod_extras_pe_partner_id_foreign` (`pe_partner_id`),
  CONSTRAINT `prod_extras_pe_partner_id_foreign` FOREIGN KEY (`pe_partner_id`) REFERENCES `partners` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of prod_extras
-- ----------------------------
INSERT INTO `prod_extras` VALUES ('1', 'queso', '20', '1', '1', null, null, null);

-- ----------------------------
-- Table structure for rates
-- ----------------------------
DROP TABLE IF EXISTS `rates`;
CREATE TABLE `rates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rt_value` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of rates
-- ----------------------------

-- ----------------------------
-- Table structure for rate_list
-- ----------------------------
DROP TABLE IF EXISTS `rate_list`;
CREATE TABLE `rate_list` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rate_order_id` bigint(20) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rate_list_rate_order_id_foreign` (`rate_order_id`),
  CONSTRAINT `rate_list_rate_order_id_foreign` FOREIGN KEY (`rate_order_id`) REFERENCES `orders` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of rate_list
-- ----------------------------

-- ----------------------------
-- Table structure for roles_permissions
-- ----------------------------
DROP TABLE IF EXISTS `roles_permissions`;
CREATE TABLE `roles_permissions` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of roles_permissions
-- ----------------------------
INSERT INTO `roles_permissions` VALUES ('1', 'all', null, null, null);
INSERT INTO `roles_permissions` VALUES ('2', 'mid', null, null, null);
INSERT INTO `roles_permissions` VALUES ('3', 'nothing', null, null, null);

-- ----------------------------
-- Table structure for roles_users
-- ----------------------------
DROP TABLE IF EXISTS `roles_users`;
CREATE TABLE `roles_users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `rs_perms_id` bigint(20) unsigned NOT NULL,
  `rs_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `roles_users_rs_perms_id_foreign` (`rs_perms_id`),
  CONSTRAINT `roles_users_rs_perms_id_foreign` FOREIGN KEY (`rs_perms_id`) REFERENCES `roles_permissions` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of roles_users
-- ----------------------------
INSERT INTO `roles_users` VALUES ('1', '1', 'admin', null, null, null);
INSERT INTO `roles_users` VALUES ('2', '2', 'socio', null, null, null);
INSERT INTO `roles_users` VALUES ('3', '3', 'repartidor', null, null, null);

-- ----------------------------
-- Table structure for states
-- ----------------------------
DROP TABLE IF EXISTS `states`;
CREATE TABLE `states` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `st_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `st_iso` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of states
-- ----------------------------
INSERT INTO `states` VALUES ('1', 'Amazonas', 'VE-X', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('2', 'Anzoátegui', 'VE-B', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('3', 'Apure', 'VE-C', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('4', 'Aragua', 'VE-D', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('5', 'Barinas', 'VE-E', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('6', 'Bolívar', 'VE-F', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('7', 'Carabobo', 'VE-G', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('8', 'Cojedes', 'VE-H', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('9', 'Delta Amacuro', 'VE-Y', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('10', 'Falcón', 'VE-I', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('11', 'Guárico', 'VE-J', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('12', 'Lara', 'VE-K', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('13', 'Mérida', 'VE-L', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('14', 'Miranda', 'VE-M', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('15', 'Monagas', 'VE-N', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('16', 'Nueva Esparta', 'VE-O', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('17', 'Portuguesa', 'VE-P', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('18', 'Sucre', 'VE-R', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('19', 'Táchira', 'VE-S', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('20', 'Trujillo', 'VE-T', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('21', 'Vargas', 'VE-W', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('22', 'Yaracuy', 'VE-U', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('23', 'Zulia', 'VE-V', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('24', 'Distrito Capital', 'VE-A', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('25', 'Dependencias Federales', 'VE-Z', '2020-02-28 17:02:11', '2020-02-28 17:02:11', null);
INSERT INTO `states` VALUES ('26', 'Amazonas', 'VE-X', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `states` VALUES ('27', 'Anzoátegui', 'VE-B', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);
INSERT INTO `states` VALUES ('28', 'Apure', 'VE-C', '2020-02-29 16:53:22', '2020-02-29 16:53:22', null);

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES ('2', 'gioanfranco', 'gioan2908@gmail.com', null, '$2y$10$uqz14UjowP1Lvqm4LyJVmOSagJoJKND35333uNmJR.JhL5VV6R/Z6', null, null, null);
